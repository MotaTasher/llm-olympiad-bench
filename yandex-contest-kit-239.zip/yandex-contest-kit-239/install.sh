#!/bin/bash
# Установка кита: .venv, зависимости, регистрация MCP-сервера для Claude.
#
#   ./install.sh             # .venv + .mcp.json (Claude Code, эта папка)
#   ./install.sh --desktop   # плюс запись сервера в конфиг Claude Desktop
#
# Ничего вне этой папки не трогает, кроме (по --desktop) конфига Claude Desktop,
# и туда только дописывает свой сервер, не меняя чужие.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

say()  { printf '\033[1m%s\033[0m\n' "$*"; }
fail() { printf '\033[31m!! %s\033[0m\n' "$*" >&2; exit 1; }

# --- python ------------------------------------------------------------------
PY="${PYTHON:-python3}"
command -v "$PY" >/dev/null || fail "нет python3: поставь Python 3.10+ (python.org или brew install python)"
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' \
    || fail "нужен Python 3.10+, а у тебя $("$PY" --version)"

say "1/4 виртуальное окружение .venv"
[ -d .venv ] || "$PY" -m venv .venv
.venv/bin/pip install --quiet --upgrade pip
.venv/bin/pip install --quiet -e ".[all]"

say "2/4 браузер для входа"
if [ -d "/Applications/Google Chrome.app" ] || command -v google-chrome >/dev/null 2>&1; then
    echo "   системный Chrome есть — ничего качать не надо"
else
    echo "   системного Chrome нет — ставлю Chromium от Playwright (~150 МБ)"
    .venv/bin/playwright install chromium
fi

# --- MCP для Claude Code: проектный .mcp.json ----------------------------------
say "3/4 сервер для Claude Code → .mcp.json"
MCP_BIN="$ROOT/.venv/bin/contest-mcp"
[ -x "$MCP_BIN" ] || fail "не появился $MCP_BIN — установка пакета не удалась"
cat > .mcp.json <<EOF
{
  "mcpServers": {
    "yandex-contest": {
      "command": "$MCP_BIN",
      "args": []
    }
  }
}
EOF
echo "   $ROOT/.mcp.json"

# --- Claude Desktop (по флагу) ---------------------------------------------------
if [ "${1:-}" = "--desktop" ]; then
    say "4/4 сервер для Claude Desktop"
    case "$(uname -s)" in
        Darwin) CFG="$HOME/Library/Application Support/Claude/claude_desktop_config.json" ;;
        *)      CFG="${APPDATA:-$HOME/.config}/Claude/claude_desktop_config.json" ;;
    esac
    mkdir -p "$(dirname "$CFG")"
    .venv/bin/python - "$CFG" "$MCP_BIN" <<'PY'
import json, sys, pathlib
cfg_path, mcp_bin = pathlib.Path(sys.argv[1]), sys.argv[2]
cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() and cfg_path.read_text().strip() else {}
cfg.setdefault("mcpServers", {})["yandex-contest"] = {"command": mcp_bin, "args": []}
cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n")
print(f"   {cfg_path}")
PY
    echo "   перезапусти Claude Desktop целиком (Cmd-Q), чтобы он подхватил сервер"
else
    say "4/4 Claude Desktop — пропущено (./install.sh --desktop, если нужно)"
fi

cat <<EOF

Готово. Дальше:

  .venv/bin/contest auth login --browser    # войти в Контест один раз
  .venv/bin/contest auth status             # «Сессия: жива»
  claude                                    # Claude Code в этой папке — он прочитает CLAUDE.md

Проверка сервера в Claude Code: /mcp → yandex-contest → connected.
EOF
