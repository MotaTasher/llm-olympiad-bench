"""
Таксономия ошибок.

Главный потребитель CLI — LLM-агент, который на ошибку не «читает и думает»,
а пытается починиться следующим вызовом. Поэтому ошибка здесь — не текст, а
структура: код (стабильный, машиночитаемый), человеческое объяснение, подсказка
что именно не так, и по возможности готовая следующая команда.

Реестр HINTS ниже — это же и есть черновик docs/QUIRKS.md (в ките для
преподавателей — docs/PLATFORM.md, раздел 7): каждая запись
описывает неочевидное поведение площадки, на которое мы наткнулись вживую.
"""

from dataclasses import dataclass, field


@dataclass
class ContestError(Exception):
    """Базовая ошибка. Всё, что ловит CLI, приводится к ней."""

    code: str
    message: str
    hint: str | None = None
    next_command: str | None = None
    details: dict = field(default_factory=dict)

    def __post_init__(self):
        super().__init__(self.message)

    def to_dict(self):
        out = {"error": {"code": self.code, "message": self.message}}
        if self.hint:
            out["error"]["hint"] = self.hint
        if self.next_command:
            out["error"]["next_command"] = self.next_command
        if self.details:
            out["error"]["details"] = self.details
        return out

    def render(self):
        """Человеко/агенто-читаемый текст для stderr."""
        lines = [f"[{self.code}] {self.message}"]
        if self.hint:
            lines.append(f"  причина: {self.hint}")
        if self.next_command:
            lines.append(f"  дальше:  {self.next_command}")
        return "\n".join(lines)


# --- реестр подсказок ------------------------------------------------------
#
# Ключ — код ошибки. Значение — что агент должен понять и что сделать.
# Тексты здесь намеренно конкретные: «сделай X», а не «что-то пошло не так».

HINTS = {
    "AUTH_MISSING": (
        "Не найдены учётные данные ни в переменных окружения, ни в конфиге, "
        "ни в браузере.",
        "contest auth login --browser",
    ),
    "SESSION_EXPIRED": (
        "Площадка вернула HTML страницы логина вместо JSON — сессионная кука "
        "протухла. Это не баг команды.",
        "contest auth login --browser",
    ),
    "CSRF_MISSING": (
        "Для POST/PATCH/DELETE нужен CSRF-токен; он лежит в теге "
        '<meta name="secretkey"> на любой странице админки.',
        "contest auth refresh",
    ),
    "REFERER_REQUIRED": (
        "PATCH настроек задачи требует Referer с той же страницы, с которой это "
        "правится в вебе: с Referer .../files запись настроек падает 403, хотя "
        "заливка файла с тем же Referer проходит.",
        None,
    ),
    "RESOURCE_LOCKED": (
        "423 Locked: площадка блокирует задачу на время предыдущей операции с "
        "деревом файлов. Параллельные заливки/удаления не работают в принципе — "
        "только последовательно и с паузой.",
        None,
    ),
    "FIELD_NOT_PATCHABLE": (
        "Это поле площадка не даёт переустанавливать явно (наблюдалось на "
        "details -> 400 и allowHugeSubmissions -> 403). PATCH шлётся только по "
        "top-level ключу правимого пути, иначе ловим 403 на соседних полях.",
        None,
    ),
    "SILENT_NOOP": (
        "Площадка приняла запрос (200/204), но ничего не сохранила. Известный "
        "случай — PATCH testSets.*: нужен отдельный testset-эндпоинт, тот же, "
        'что дёргает кнопка "Обновить тесты".',
        None,
    ),
    "BAD_REF": (
        "Не смог разобрать ссылку/идентификатор.",
        None,
    ),
    "LOCAL_FILE_MISSING": (
        "Локального файла нет — до сети дело не дошло.",
        None,
    ),
    "NOT_FOUND": (
        "Объект не найден на площадке.",
        None,
    ),
    "ARCHIVE_AMBIGUOUS": (
        "Площадка распаковывает .zip прямо при заливке — вместо файла в дереве "
        "появляется его содержимое. Для дерева тестов это то, что нужно; для "
        "вложения к условию это ломает ссылку. Угадывать нельзя, скажи явно: "
        "archive='unpack' (развернуть) или archive='keep' (оставить архивом).",
        None,
    ),
    "ARCHIVE_UNEXPECTED": (
        "После заливки дерево задачи выглядит не так, как предполагало "
        "намерение. Распаковка — поведение сервера, у нас нет способа её "
        "запретить, поэтому результат всегда сверяется с деревом.",
        "contest files list",
    ),
    "GHOST_FILE": (
        "Путь числится в списке файлов стадии, но физически отсутствует в дереве "
        "задачи. Сервер это не валидирует — пайплайн упадёт уже на прогоне, "
        "пытаясь скопировать несуществующий файл.",
        "contest problem check",
    ),
    "HTTP_ERROR": (None, None),
}


class SessionExpired(ContestError):
    """Кука протухла — все дальнейшие вызовы бессмысленны до перелогина."""


class ResourceLocked(ContestError):
    """423 Locked — единственная ошибка, которую осмысленно ретраить самим."""


# Коды, под которые есть отдельный класс: чтобы вызывающий код мог их
# отлавливать точечно (ретрай на 423, ранний выход на протухшей сессии).
_CLASSES = {
    "SESSION_EXPIRED": SessionExpired,
    "RESOURCE_LOCKED": ResourceLocked,
}


def make(code, message, next_command=None, **details):
    """Собрать ошибку, подтянув подсказку из реестра по коду."""
    hint, default_next = HINTS.get(code, (None, None))
    cls = _CLASSES.get(code, ContestError)
    return cls(
        code=code,
        message=message,
        hint=hint,
        next_command=next_command or default_next,
        details=details,
    )
