"""
Политика обращения с архивами при заливке.

Проверено вживую 25.07.2026: площадка **разворачивает любой залитый архив** в
отдельные файлы, а сам архив в дереве не сохраняет. Причём:

  * распознаётся по содержимому, а не по имени и не по Content-Type — zip,
    переименованный в .dat, и zip с `application/octet-stream` распаковываются
    так же;
  * .tar.gz тоже распаковывается и вдобавок насыпает служебные `PaxHeader/*`;
  * распаковка **не рекурсивная** — вложенный архив остаётся файлом.

Отсюда два следствия, на которых держится весь модуль:

1. Дерево из сотен тестов заливается одним архивом вместо сотни запросов под
   локом. Это снимает основную боль (`423 Locked`).
2. Архив, который должен остаться архивом (данные к условию, которые участник
   скачивает одним файлом), заливается **внутри внешнего архива**: внешний
   развернётся, внутренний уцелеет. Другого способа нет — запретить распаковку
   нельзя.

Поэтому намерение для архива указывается явно, а результат сверяется с деревом.
"""

import os
import zipfile

from . import errors

# Распознавание по имени — эвристика для наших решений; сервер смотрит внутрь
# файла, поэтому список намеренно широкий.
ARCHIVE_SUFFIXES = (
    ".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2",
    ".gz", ".bz2", ".xz", ".7z", ".rar",
)

UNPACK = "unpack"   # хочу, чтобы развернулось в файлы дерева
KEEP = "keep"       # хочу, чтобы в дереве остался сам архив
PLAIN = "plain"     # не архив, вопрос не стоит


def is_archive(name):
    return os.path.basename(name).lower().endswith(ARCHIVE_SUFFIXES)


def decide(local_name, intent=None):
    """
    Что делаем с файлом: PLAIN, UNPACK или KEEP.

    Для архива без явного намерения — ошибка. Угадывать нельзя: развернувшийся
    архив обратно не собрать, а ссылка на него в условии к этому моменту уже
    ведёт в никуда.
    """
    if not is_archive(local_name):
        return PLAIN
    if intent in (UNPACK, KEEP):
        return intent
    if intent is not None:
        raise errors.make("BAD_REF", f"Неизвестное намерение для архива: {intent!r}")
    raise errors.make(
        "ARCHIVE_AMBIGUOUS",
        f"{os.path.basename(local_name)} — архив, а площадка распаковывает архивы "
        "при заливке. Укажи явно, что нужно.",
        file=os.path.basename(local_name),
    )


def members(zip_path):
    """Пути файлов внутри zip, без каталогов."""
    with zipfile.ZipFile(zip_path) as z:
        return sorted(
            info.filename.replace(os.sep, "/")
            for info in z.infolist()
            if not info.is_dir()
        )


def expected_after_unpack(zip_path, target_path):
    """
    Что должно появиться в дереве, если архив развернётся: содержимое ложится
    в тот каталог, где лежал бы сам архив, с сохранением внутренних путей.
    """
    parent = os.path.dirname(target_path.strip("/"))
    return [f"{parent}/{m}" if parent else m for m in members(zip_path)]


def wrap_to_survive(local_path, target_path, workdir):
    """
    Упаковать файл во внешний zip так, чтобы после распаковки на площадке он
    оказался в дереве по пути target_path целым.

    Имя внешнего архива роли не играет — важно имя файла внутри него: именно
    оно становится именем в дереве. Сжатие не нужно (архив уже сжат), поэтому
    ZIP_STORED — это ещё и быстрее.
    """
    outer = os.path.join(workdir, "outer.zip")
    with zipfile.ZipFile(outer, "w", zipfile.ZIP_STORED) as z:
        z.write(local_path, arcname=os.path.basename(target_path))
    return outer


def outer_target_for(target_path):
    """Путь, по которому регистрируется внешний архив-обёртка."""
    parent = os.path.dirname(target_path.strip("/"))
    return f"{parent}/outer.zip" if parent else "outer.zip"


def pack_files(files, zip_path, strip=0):
    """
    Собрать архив из отобранного списка файлов.

    Именно из списка, а не из папки целиком: иначе внутрь попадёт всё, что
    отфильтровал scan_local (.DS_Store, __pycache__), и сервер развернёт этот
    мусор прямо в дерево задачи.
    """
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f.local_path, arcname=f.path[strip:])
    return zip_path


def verify(decision, target_path, expected, tree_paths):
    """
    Сверить намерение с тем, что реально появилось в дереве.

    Возвращает отчёт; считать ли расхождение ошибкой, решает вызывающий.
    """
    tree = set(tree_paths)
    target_present = target_path in tree
    found = [p for p in expected if p in tree]
    missing = [p for p in expected if p not in tree]

    if decision == UNPACK:
        return {
            "decision": decision,
            "unpacked": bool(found),
            "ok": not missing,
            "target_present": target_present,
            "found": found,
            "missing": missing,
        }
    # KEEP: успех — это ровно наличие самого файла по целевому пути.
    return {
        "decision": decision,
        "unpacked": not target_present,
        "ok": target_present,
        "target_present": target_present,
        "found": [target_path] if target_present else [],
        "missing": [] if target_present else [target_path],
    }
