"""
Дерево файлов задачи: чтение, заливка, удаление.

Заливка — три шага: presigned-ссылка от админки, прямой POST в S3 (без куки),
регистрация пути в дереве задачи. Мутации дерева идут под общим локом и с
ретраями: параллельные операции ловят `423 Locked`.

Всё, что касается архивов, вынесено в archives.py — там же объяснено, почему
zip нельзя залить «как есть» и почему папку, наоборот, выгодно заливать архивом.
"""

import mimetypes
import os
import tempfile

import requests

from .. import archives, errors, tree
from ..refs import encode_file_path, problem_id_encoded

# Начиная с этого числа файлов один архив выгоднее поштучной заливки: каждый
# файл — отдельный запрос под локом.
ZIP_THRESHOLD = 5


def _referer(enc):
    return f"/problems/{enc}/files"


def list_tree(client, problem):
    """Плоский список файлов задачи."""
    enc = problem_id_encoded(problem)
    data = client.json("GET", f"/api/admin/problem/{enc}/file", referer=_referer(enc))
    return tree.flatten(data or {})


def list_paths(client, problem):
    return [f.path for f in list_tree(client, problem)]


def delete_file(client, problem, path):
    enc = problem_id_encoded(problem)
    client.request(
        "DELETE",
        f"/api/admin/problem/{enc}/file/{encode_file_path(path)}",
        referer=_referer(enc),
        serialize=True,
        )
    return path


def upload_file(client, problem, local_path, target_path, *, archive=None, verify=None):
    """
    Залить один файл по пути target_path.

    archive — только для архивов: 'unpack' (пусть развернётся в дерево) или
    'keep' (пусть в дереве останется сам архив; для этого он заливается внутри
    внешнего архива, иначе площадка его развернёт). Без явного значения для
    архива бросается ARCHIVE_AMBIGUOUS.

    verify — сверять ли результат с деревом. По умолчанию сверяются только
    архивы: для обычного файла это лишний запрос на каждую заливку, а риска нет.
    """
    if not os.path.isfile(local_path):
        raise errors.make(
            "LOCAL_FILE_MISSING", f"Нет локального файла: {local_path}", path=local_path
        )

    decision = archives.decide(local_path, archive)

    if decision == archives.KEEP:
        with tempfile.TemporaryDirectory() as tmp:
            outer = archives.wrap_to_survive(local_path, target_path, tmp)
            _put(client, problem, outer, archives.outer_target_for(target_path))
        expected = [target_path]
    else:
        _put(client, problem, local_path, target_path)
        expected = (
            archives.expected_after_unpack(local_path, target_path)
            if decision == archives.UNPACK
            else []
        )

    if verify is None:
        verify = decision != archives.PLAIN
    if not verify:
        return {"path": target_path, "decision": decision, "verified": False}

    report = archives.verify(decision, target_path, expected, list_paths(client, problem))
    report["verified"] = True
    report["path"] = target_path
    if not report["ok"]:
        raise errors.make("ARCHIVE_UNEXPECTED", _describe_mismatch(target_path, report), **report)
    return report


def upload_folder(client, problem, local_root, prefix="", *, mode="auto", exclude=None):
    """
    Залить папку целиком.

    mode:
      'files' — по одному файлу (предсказуемо, но каждый файл — запрос под локом);
      'zip'   — одним архивом, с расчётом на распаковку на стороне сервера;
      'auto'  — 'zip', если файлов много ИЛИ среди них есть архивы, иначе 'files'.

    Быстрый путь всегда сверяется с деревом: чего не хватило — дозаливается
    поштучно. Поэтому 'auto' безопасен, худший случай вырождается в обычную
    поштучную заливку.
    """
    files = tree.scan_local(local_root, prefix=prefix, exclude=exclude)
    if not files:
        return {"mode": "files", "uploaded": [], "count": 0}

    if mode == "auto":
        mode = "zip" if _prefer_zip(files) else "files"
    if mode == "zip":
        return _upload_folder_zipped(client, problem, prefix, files)
    if mode != "files":
        raise errors.make("BAD_REF", f"Неизвестный режим заливки: {mode!r}")

    return {"mode": "files", "uploaded": _upload_each(client, problem, files),
            "count": len(files)}


def _prefer_zip(files):
    """
    Когда быстрый путь лучше.

    Вложенные архивы — не противопоказание, а наоборот главный довод: распаковка
    не рекурсивная, поэтому внутри общего архива они доедут до дерева целыми.
    Поштучно тот же файл площадка развернула бы.
    """
    if any(archives.is_archive(f.path) for f in files):
        return True
    return len(files) >= ZIP_THRESHOLD


def _upload_each(client, problem, files):
    """Поштучная заливка: архивы среди файлов заливаются с сохранением."""
    for f in files:
        intent = archives.KEEP if archives.is_archive(f.path) else None
        upload_file(client, problem, f.local_path, f.path, archive=intent, verify=False)
    return [f.path for f in files]


def _upload_folder_zipped(client, problem, prefix, files):
    """Один архив вместо N запросов; чего не хватило — дозаливается поштучно."""
    with tempfile.TemporaryDirectory() as tmp:
        strip = len(prefix.rstrip("/")) + 1 if prefix else 0
        zip_path = archives.pack_files(files, os.path.join(tmp, "payload.zip"), strip)
        target = f"{prefix.rstrip('/')}/payload.zip" if prefix else "payload.zip"
        _put(client, problem, zip_path, target)

    expected = [f.path for f in files]
    report = archives.verify(archives.UNPACK, target, expected, list_paths(client, problem))

    result = {
        "mode": "zip",
        "uploaded": report["found"],
        "count": len(report["found"]),
    }

    if report["missing"]:
        by_path = {f.path: f for f in files}
        _upload_each(client, problem, [by_path[p] for p in report["missing"]])
        result["mode"] = "zip+files" if report["found"] else "files"
        result["fallback"] = report["missing"]
        result["uploaded"] = expected
        result["count"] = len(files)

    # Обычно площадка сама не оставляет архив в дереве; если оставила —
    # распаковки не случилось, и транспортный файл в задаче не нужен.
    if report["target_present"]:
        delete_file(client, problem, target)

    return result


# --- внутреннее ------------------------------------------------------------


def _put(client, problem, local_path, target_path):
    """
    Три шага заливки: presign -> S3 -> регистрация пути в дереве.

    Content-Type здесь ни на что не влияет: распаковку площадка решает по
    содержимому файла, а не по типу и не по имени (проверено). Отправляем
    честно угаданный тип просто чтобы не врать серверу.
    """
    enc = problem_id_encoded(problem)
    filename = os.path.basename(local_path)
    content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

    presign = client.json(
        "GET",
        "/api/admin/upload-file",
        referer=_referer(enc),
        params={"contentType": content_type, "fileName": filename},
    )
    url, fields, s3_id = presign["url"], presign["fields"], presign["key"]

    with open(local_path, "rb") as f:
        # Прямой запрос в S3: подпись уже в fields, кука и CSRF здесь не нужны.
        s3 = requests.post(url, data=fields, files={"file": (filename, f, content_type)})
    if s3.status_code >= 400:
        raise errors.make(
            "HTTP_ERROR",
            f"S3 отклонил загрузку {filename}: {s3.status_code}",
            status=s3.status_code,
            body=s3.text[:400],
        )

    client.request(
        "POST",
        f"/api/admin/problems/{enc}/files",
        referer=_referer(enc),
        serialize=True,
        json={"path": target_path, "s3Id": s3_id},
    )
    return s3_id


def _describe_mismatch(target_path, report):
    if report["decision"] == archives.KEEP:
        return (
            f"{target_path} просили оставить архивом, но в дереве его нет: "
            "внешний архив, похоже, развернулся не так, как ожидалось"
        )
    if not report["unpacked"]:
        return (
            f"{target_path} просили развернуть, но содержимое в дереве не "
            "появилось: архив, судя по всему, остался файлом"
        )
    total = len(report["missing"]) + len(report["found"])
    return f"{target_path} развернулся частично: не хватает {len(report['missing'])} из {total} файлов"
