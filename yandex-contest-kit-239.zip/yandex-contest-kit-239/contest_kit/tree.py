"""
Дерево файлов задачи: разбор ответа площадки и сверка с локальной папкой.

Папок как самостоятельных объектов на площадке нет — они появляются при
регистрации первого файла в них и исчезают, когда файлов не остаётся.
"""

import fnmatch
import os
from typing import NamedTuple


class RemoteFile(NamedTuple):
    path: str
    size: int | None
    content_type: str | None


class LocalFile(NamedTuple):
    path: str          # путь в задаче
    local_path: str    # путь на диске
    size: int


def flatten(node, prefix=""):
    """Ответ GET .../problem/{id}/file -> плоский список файлов."""
    out = []
    for item in node.get("items", []) or []:
        path = f"{prefix}{item['name']}"
        if item.get("directory"):
            out.extend(flatten(item, prefix=path + "/"))
        else:
            ctype = (item.get("contentType") or {}).get("type")
            out.append(RemoteFile(path, item.get("size"), ctype))
    return out


DEFAULT_EXCLUDE = ["*.pyc", "__pycache__/*", ".DS_Store", "*/.DS_Store", ".git/*"]


def scan_local(root, prefix="", exclude=None):
    """Локальная папка -> список файлов с путями, как они лягут в задаче."""
    exclude = DEFAULT_EXCLUDE if exclude is None else exclude
    root = os.path.abspath(root)
    out = []
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in sorted(filenames):
            local_path = os.path.join(dirpath, name)
            rel = os.path.relpath(local_path, root).replace(os.sep, "/")
            if is_excluded(rel, exclude):
                continue
            path = f"{prefix.rstrip('/')}/{rel}" if prefix else rel
            out.append(LocalFile(path, local_path, os.path.getsize(local_path)))
    return sorted(out)


def is_excluded(rel_path, patterns):
    for pat in patterns:
        if fnmatch.fnmatch(rel_path, pat) or fnmatch.fnmatch(os.path.basename(rel_path), pat):
            return True
    return False


def diff(local, remote):
    """
    Что надо сделать, чтобы дерево задачи совпало с локальной папкой.

    Сравниваем по размеру: хеша содержимого площадка не отдаёт, а размер
    у неё уже есть — этого достаточно, чтобы не перезаливать неизменившееся
    (ровно та же логика, что в идемпотентном download).

    Возвращает (to_upload, unchanged, extra_on_remote) — удаление лишнего
    остаётся решением вызывающего, сами ничего не выкидываем.
    """
    remote_by_path = {f.path: f for f in remote}
    to_upload, unchanged = [], []
    for f in local:
        r = remote_by_path.get(f.path)
        if r is not None and r.size == f.size:
            unchanged.append(f)
        else:
            to_upload.append(f)
    local_paths = {f.path for f in local}
    extra = [r for r in remote if r.path not in local_paths]
    return to_upload, unchanged, extra
