"""
Учётные данные. В исходниках их нет и быть не может.

Порядок разрешения (первый сработавший выигрывает):

  1. переменные окружения CONTEST_KIT_COOKIE / CONTEST_KIT_CSRF
  2. ~/.config/contest-kit/auth.json — профили, файл с правами 600
  3. browser_cookie3 — куки из локального профиля Chrome

CSRF-токен руками вводить не надо: он лежит на любой странице админки —
раньше в <meta name="secretkey">, с лета 2026 в JSON конфигурации страницы
("secretkey":"…"), — клиент забирает его сам (см. http.Client.refresh_csrf).
В скопированном curl он тоже есть, заголовком x-csrf-token: берём оттуда первым.

Три способа получить куку, от самого удобного к самому ручному:

  * `contest auth login --browser` — открывается Chrome со своим профилем,
    человек логинится, куки забираются из браузера напрямую (Playwright).
    Через терминал, буфер обмена и уж тем более через контекст LLM-агента кука
    не проходит;
  * `--from-curl` — «Copy as cURL» из DevTools, вставить, Ctrl-D;
  * `--cookie` — строка целиком (осядет в истории шелла, лучше не надо).
"""

import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path

from . import errors

ENV_COOKIE = "CONTEST_KIT_COOKIE"
ENV_CSRF = "CONTEST_KIT_CSRF"
ENV_PROFILE = "CONTEST_KIT_PROFILE"

CONFIG_DIR = Path(os.environ.get("CONTEST_KIT_CONFIG_DIR", Path.home() / ".config" / "contest-kit"))
AUTH_FILE = CONFIG_DIR / "auth.json"

# Куки, без которых сессия админки не живёт. Нужны для внятной диагностики
# «кука есть, но не та» — иначе площадка молча отдаёт страницу логина.
REQUIRED_COOKIES = ("Session_id", "sessionid2")


@dataclass
class Credentials:
    cookie: str
    csrf: str | None = None
    login: str | None = None
    profile: str = "default"
    source: str = "unknown"

    def missing_cookies(self):
        names = {c.split("=", 1)[0].strip() for c in self.cookie.split(";") if "=" in c}
        return [n for n in REQUIRED_COOKIES if n not in names]


# --- чистые парсеры (тестируются без сети и без файлов) --------------------

_CURL_COOKIE_PATTERNS = [
    r"-b\s+'([^']+)'",
    r'-b\s+"([^"]+)"',
    r"--cookie\s+'([^']+)'",
    r'--cookie\s+"([^"]+)"',
    r"-H\s+'[Cc]ookie:\s*([^']+)'",
    r'-H\s+"[Cc]ookie:\s*([^"]+)"',
]


def cookie_from_curl(curl_text):
    """Вытащить строку куки из вставленного 'Copy as cURL'."""
    for pat in _CURL_COOKIE_PATTERNS:
        m = re.search(pat, curl_text)
        if m:
            return m.group(1).strip()
    return None


def csrf_from_html(html):
    """
    Токен со страницы админки. Два места, потому что площадка переехала:
    до лета 2026 — <meta name="secretkey" content="...">, с 31.07.2026 тега нет,
    и токен лежит в JSON конфигурации страницы: ..."secretkey":"u3ef2..."...
    Смотрим оба, meta первым — он однозначнее.
    """
    m = re.search(
        r'<meta[^>]+name=["\']secretkey["\'][^>]+content=["\']([^"\']+)["\']', html
    )
    if m:
        return m.group(1)
    m = re.search(
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']secretkey["\']', html
    )
    if m:
        return m.group(1)
    m = re.search(r'"secretkey"\s*:\s*"([^"]+)"', html)
    return m.group(1) if m else None


_CURL_CSRF_PATTERNS = [
    r"-H\s+'(?i:x-csrf-token):\s*([^']+)'",
    r'-H\s+"(?i:x-csrf-token):\s*([^"]+)"',
]


def csrf_from_curl(curl_text):
    """Заголовок x-csrf-token из 'Copy as cURL' — есть у любого XHR админки."""
    for pat in _CURL_CSRF_PATTERNS:
        m = re.search(pat, curl_text)
        if m:
            return m.group(1).strip()
    return None


def login_from_cookie(cookie):
    m = re.search(r"(?:^|;)\s*yandex_login=([^;]+)", cookie)
    return m.group(1).strip() if m else None


def redact(text):
    """Вырезать значения кук из любого текста перед логом/выводом."""
    if not text:
        return text
    return re.sub(
        r"(?:^|(?<=[;\s]))(Session_id|sessionid2|sessar|_yasc|yandexuid|L|ys|pi|i)"
        r"=([^;\s\"']+)",
        lambda m: f"{m.group(1)}=<{len(m.group(2))} символов>",
        text,
    )


def cookie_fingerprint(cookie):
    """Короткий стабильный отпечаток куки для логов — без самой куки."""
    import hashlib

    return hashlib.sha256(cookie.encode()).hexdigest()[:12]


# --- хранилище -------------------------------------------------------------


def load_config():
    if not AUTH_FILE.exists():
        return {"default_profile": None, "profiles": {}}
    with AUTH_FILE.open(encoding="utf-8") as f:
        return json.load(f)


def save_credentials(creds):
    """Записать профиль в auth.json с правами 600 (и 700 на каталог)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(CONFIG_DIR, stat.S_IRWXU)
    cfg = load_config()
    cfg.setdefault("profiles", {})[creds.profile] = {
        "cookie": creds.cookie,
        "csrf": creds.csrf,
        "login": creds.login,
    }
    # Профилем по умолчанию становится первый сохранённый; последующие его не
    # перетирают — иначе добавление второго аккаунта молча уводит все команды
    # не на тот профиль.
    if not cfg.get("default_profile"):
        cfg["default_profile"] = creds.profile
    tmp = AUTH_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    tmp.replace(AUTH_FILE)
    return AUTH_FILE


def resolve(profile=None):
    """Учётные данные по описанному в шапке порядку. Бросает AUTH_MISSING."""
    env_cookie = os.environ.get(ENV_COOKIE, "").strip()
    if env_cookie:
        return Credentials(
            cookie=env_cookie,
            csrf=os.environ.get(ENV_CSRF) or None,
            login=login_from_cookie(env_cookie),
            profile="env",
            source=f"${ENV_COOKIE}",
        )

    cfg = load_config()
    name = profile or os.environ.get(ENV_PROFILE) or cfg.get("default_profile") or "default"
    entry = (cfg.get("profiles") or {}).get(name)
    if entry and entry.get("cookie"):
        return Credentials(
            cookie=entry["cookie"],
            csrf=entry.get("csrf"),
            login=entry.get("login") or login_from_cookie(entry["cookie"]),
            profile=name,
            source=str(AUTH_FILE),
        )

    cookie = _cookie_from_browser()
    if cookie:
        return Credentials(
            cookie=cookie,
            login=login_from_cookie(cookie),
            profile="browser",
            source="browser_cookie3",
        )

    raise errors.make(
        "AUTH_MISSING",
        "Нет учётных данных для admin.contest.yandex.ru",
        tried=[f"${ENV_COOKIE}", str(AUTH_FILE), "browser_cookie3"],
    )


def _cookie_from_browser():
    try:
        import browser_cookie3
    except ImportError:
        return None
    try:
        jar = browser_cookie3.chrome(domain_name="yandex.ru")
    except Exception:
        return None
    pairs = [f"{c.name}={c.value}" for c in jar]
    return "; ".join(pairs) if pairs else None


# --- вход через браузер ----------------------------------------------------

BROWSER_PROFILE_DIR = CONFIG_DIR / "browser-profile"
ADMIN_URL = "https://admin.contest.yandex.ru/problems"


def browser_login(url=ADMIN_URL, profile_dir=None, timeout=600, headless=False,
                  channel="chrome", required=REQUIRED_COOKIES, notify=None):
    """
    Открыть браузер, дать человеку залогиниться и забрать куки самим.

    Окно — Chrome (channel="chrome": системный, ничего качать не надо; если его
    нет — Chromium от Playwright) со своим профилем в ~/.config/contest-kit:
    основной профиль пользователя не трогаем, и логин в этом окне переживает
    перезапуск. Ждём, пока у страницы админки появятся обязательные куки и она
    перестанет быть страницей паспорта, дальше снимаем куки и CSRF из HTML.

    Кука при этом не проходит ни через буфер обмена, ни через stdin, ни через
    контекст агента, который эту команду запустил, — единственная причина, по
    которой этот путь существует рядом с --from-curl.

    Возвращает (cookie, csrf). CSRF может быть None — тогда его доберёт
    http.Client.refresh_csrf.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise errors.make(
            "AUTH_MISSING",
            "Для входа через браузер нужен playwright: pip install playwright",
            next_command="pip install playwright && contest auth login --browser",
        )
    import time

    profile_dir = Path(profile_dir or BROWSER_PROFILE_DIR)
    profile_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(profile_dir, stat.S_IRWXU)
    say = notify or (lambda msg: None)

    with sync_playwright() as pw:
        try:
            ctx = pw.chromium.launch_persistent_context(
                str(profile_dir), channel=channel, headless=headless,
            )
        except Exception:
            # Системного Chrome нет — берём Chromium Playwright (playwright install chromium).
            ctx = pw.chromium.launch_persistent_context(str(profile_dir), headless=headless)
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(url, wait_until="domcontentloaded")
            say("Залогинься в открывшемся окне. Жду, пока админка откроется…")
            deadline = time.time() + timeout
            while True:
                cookies = ctx.cookies([url])
                names = {c["name"] for c in cookies}
                on_admin = page.url.startswith(url.split("/", 3)[0] + "//" + url.split("/", 3)[2])
                if all(n in names for n in required) and on_admin and not _is_passport(page):
                    break
                if time.time() > deadline:
                    raise errors.make(
                        "AUTH_MISSING",
                        f"За {timeout} с логин в браузере не появился",
                        next_command="contest auth login --browser",
                    )
                time.sleep(1)
            # Страница могла загрузиться ещё до логина — перечитываем, чтобы CSRF был свежий.
            page.goto(url, wait_until="domcontentloaded")
            cookies = ctx.cookies([url])
            cookie = "; ".join(f"{c['name']}={c['value']}" for c in cookies)
            csrf = csrf_from_html(page.content())
        finally:
            ctx.close()
    return cookie, csrf


def _is_passport(page):
    """Страница паспорта — ещё не вход. Смотрим на URL и на заголовок."""
    if "passport." in page.url:
        return True
    try:
        title = (page.title() or "").lower()
    except Exception:
        return False
    return "log in" in title or "авторизация" in title
