"""
HTTP-клиент к админке.

Здесь живут все повторяющиеся грабли площадки, чтобы выше по стеку о них никто
не думал:

  * Referer. Запись настроек задачи требует Referer с той страницы, с которой
    это правится в вебе. С Referer .../files PATCH настроек падает 403, хотя
    POST файла с тем же Referer проходит. Поэтому Referer — обязательный
    аргумент запроса, а не глобальная настройка сессии.
  * 423 Locked. Площадка блокирует задачу на время предыдущей операции с
    деревом файлов. Ретраим сами, а мутирующие файловые операции внутри
    процесса ещё и сериализуем — параллелить их бессмысленно.
  * Протухшая кука. GET начинает отдавать HTML страницы логина со статусом 200.
    Ловим это явно, иначе наверх уезжает «не JSON» в самом неожиданном месте.
  * CSRF. Отдельной ручки нет, токен лежит в <meta name="secretkey"> — забираем
    его сами и обновляем при 403.
"""

import threading
import time

import requests

from . import auth, errors
from .refs import BASE

# Мутации дерева файлов сериализуются: две одновременные операции над одной
# задачей гарантированно дают 423 у одной из них.
_FILE_LOCK = threading.Lock()

LOCKED_ATTEMPTS = 5
LOCKED_BACKOFF = 4.0    # секунды, как в проверенном на практике upload.sh
TIMEOUT = 60


def looks_like_login_page(resp):
    ctype = resp.headers.get("Content-Type", "")
    if "json" in ctype:
        return False
    body = resp.text[:2000].lower()
    return "<title>log in" in body or "passport.yandex" in body


class Client:
    """Тонкий слой над requests: заголовки, ретраи, классификация ошибок."""

    def __init__(self, creds, record=None, base=BASE):
        self.creds = creds
        self.record = record
        self.base = base
        self.s = requests.Session()
        self.s.headers.update({
            "User-Agent": "contest-kit",
            "Accept": "application/json, text/plain, */*",
            "Cookie": creds.cookie,
            "Origin": base,
        })
        if creds.csrf:
            self.s.headers["x-csrf-token"] = creds.csrf

    # --- низкий уровень ----------------------------------------------------

    def request(self, method, path, *, referer, serialize=False, **kwargs):
        """
        referer — путь после домена ("/problems/{enc}/settings"), обязателен:
        без него мутирующие запросы ловят 403.
        serialize — операция меняет дерево файлов, идёт под общим локом.
        """
        url = path if path.startswith("http") else f"{self.base}{path}"
        headers = dict(kwargs.pop("headers", {}))
        headers["Referer"] = f"{self.base}{referer}"
        kwargs.setdefault("timeout", TIMEOUT)

        lock = _FILE_LOCK if serialize else _NullLock()
        with lock:
            return self._with_locked_retry(method, url, headers, **kwargs)

    def _with_locked_retry(self, method, url, headers, **kwargs):
        retried = 0
        for attempt in range(1, LOCKED_ATTEMPTS + 1):
            resp = self.s.request(method, url, headers=headers, **kwargs)
            if resp.status_code != 423:
                if self.record:
                    self.record.http_call(retried_locked=retried)
                self._classify(resp, method, url)
                return resp
            retried += 1
            if attempt < LOCKED_ATTEMPTS:
                time.sleep(LOCKED_BACKOFF)
        if self.record:
            self.record.http_call(retried_locked=retried)
        raise errors.make(
            "RESOURCE_LOCKED",
            f"Задача заблокирована площадкой: {LOCKED_ATTEMPTS} попыток по "
            f"{LOCKED_BACKOFF:g}с не помогли ({method} {url})",
            attempts=LOCKED_ATTEMPTS,
        )

    def _classify(self, resp, method, url):
        if looks_like_login_page(resp):
            raise errors.make(
                "SESSION_EXPIRED",
                f"Вместо ответа пришла страница логина ({method} {url})",
                profile=self.creds.profile,
                source=self.creds.source,
            )
        if resp.status_code < 400:
            return
        if resp.status_code == 403:
            raise errors.make(
                "REFERER_REQUIRED" if method in ("PATCH", "POST") else "HTTP_ERROR",
                f"403 Forbidden: {method} {url}",
                status=403,
                referer=resp.request.headers.get("Referer"),
                body=auth.redact(resp.text[:400]),
            )
        if resp.status_code == 404:
            raise errors.make("NOT_FOUND", f"404: {method} {url}", status=404)
        if resp.status_code == 400:
            raise errors.make(
                "FIELD_NOT_PATCHABLE" if method == "PATCH" else "HTTP_ERROR",
                f"400 Bad Request: {method} {url}",
                status=400,
                body=auth.redact(resp.text[:400]),
            )
        raise errors.make(
            "HTTP_ERROR",
            f"{resp.status_code}: {method} {url}",
            status=resp.status_code,
            body=auth.redact(resp.text[:400]),
        )

    def json(self, method, path, *, referer, **kwargs):
        resp = self.request(method, path, referer=referer, **kwargs)
        if not resp.content:
            return None
        try:
            return resp.json()
        except ValueError:
            raise errors.make(
                "HTTP_ERROR",
                f"Ответ не JSON ({method} {path})",
                body=auth.redact(resp.text[:400]),
            ) from None

    # --- сессия ------------------------------------------------------------

    def refresh_csrf(self, referer="/problems"):
        """Забрать CSRF-токен из <meta name="secretkey"> страницы админки."""
        resp = self.s.get(f"{self.base}{referer}", timeout=TIMEOUT)
        # Страница логина приезжает со статусом 200 — проверять надо содержимое,
        # а не код ответа.
        if looks_like_login_page(resp):
            raise errors.make(
                "SESSION_EXPIRED",
                f"Вместо страницы админки пришла страница логина ({referer})",
            )
        token = auth.csrf_from_html(resp.text)
        if not token:
            raise errors.make(
                "CSRF_MISSING",
                f"На странице {referer} нет тега secretkey",
            )
        self.creds.csrf = token
        self.s.headers["x-csrf-token"] = token
        return token

    def status(self):
        """
        Жива ли сессия. Пробник — GET /api/admin/compilers: дешёвый, требует
        авторизации, ничего не меняет и не привязан к конкретной задаче.
        Ручки «кто я» в этом API мы не нашли, логин берём из куки.
        """
        resp = self.s.get(f"{self.base}/api/admin/compilers", timeout=TIMEOUT)
        login_page = looks_like_login_page(resp)
        alive = not login_page and resp.status_code < 400
        if alive:
            reason = None
        elif login_page:
            # Самый частый случай: кука есть, но она не даёт доступа к админке —
            # площадка отвечает страницей логина, причём со статусом 200.
            reason = "площадка вернула страницу логина: кука недействительна для админки"
        else:
            reason = f"проба вернула HTTP {resp.status_code}"
        return {
            "alive": alive,
            "reason": reason,
            "profile": self.creds.profile,
            "source": self.creds.source,
            "login": self.creds.login,
            "has_csrf": bool(self.creds.csrf),
            "cookie_fingerprint": auth.cookie_fingerprint(self.creds.cookie),
            "missing_cookies": self.creds.missing_cookies(),
            "probe_status": resp.status_code,
        }


class _NullLock:
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False
