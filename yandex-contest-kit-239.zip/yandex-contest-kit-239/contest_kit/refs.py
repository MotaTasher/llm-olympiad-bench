"""
Разбор ссылок и идентификаторов площадки. Чистые функции, без сети.

Три вида идентификаторов, которые легко перепутать:

  problem_id  «плоский»    123456/2026_07_24/aB1cD2eF3g
  problem_id  «кодированный» 123456%2F2026_07_24%2FaB1cD2eF3g  — так он в URL
  contest_id                12345                               — просто число

Плоский вид нужен в теле запросов (список задач контеста хранит id со слэшами),
кодированный — в пути URL. Путаница между ними даёт 404 без объяснений, поэтому
на входе принимаем что угодно, а наружу отдаём явно названный вид.
"""

import re

from . import errors

BASE = "https://admin.contest.yandex.ru"


def parse_problem_id(ref):
    """Из любой ссылки на задачу — кодированный ID (как он лежит в URL)."""
    m = re.search(r"/problems/([^/?#]+)", ref)
    if not m:
        raise errors.make("BAD_REF", f"Не смог найти ID задачи в ссылке: {ref}")
    return m.group(1)


def parse_contest_id(ref):
    """Числовой ID контеста из голого числа или из ссылки .../contests/{id}/..."""
    ref = ref.strip()
    if ref.isdigit():
        return ref
    m = re.search(r"/contests?/(\d+)", ref)
    if not m:
        raise errors.make("BAD_REF", f"Не смог найти ID контеста в: {ref}")
    return m.group(1)


def parse_submission_id(ref):
    """Числовой ID посылки из голого числа или из ссылки .../submissions/{id}."""
    ref = ref.strip()
    if ref.isdigit():
        return ref
    m = re.search(r"/submissions?/(\d+)", ref)
    if not m:
        raise errors.make("BAD_REF", f"Не смог найти ID посылки в: {ref}")
    return m.group(1)


def problem_id_plain(ref):
    """Любой вид ссылки/ID -> плоский ID со слэшами."""
    enc = parse_problem_id(ref) if "/problems/" in ref else ref.strip()
    return enc.replace("%2F", "/").replace("%2f", "/")


def problem_id_encoded(ref):
    """Любой вид ссылки/ID -> кодированный ID для подстановки в URL."""
    return problem_id_plain(ref).replace("/", "%2F")


def encode_file_path(path):
    """Путь файла внутри задачи кодируется через %7C, а не через %2F."""
    return path.replace("/", "%7C")


def problem_url(ref, page="settings"):
    return f"{BASE}/problems/{problem_id_encoded(ref)}/{page}"


def contest_url(ref, page="settings"):
    return f"{BASE}/contests/{parse_contest_id(ref)}/{page}"
