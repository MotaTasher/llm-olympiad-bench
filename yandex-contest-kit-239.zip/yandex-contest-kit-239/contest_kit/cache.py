"""
Кеш редко меняющихся справочников на диске.

Пока единственный клиент — список компиляторов/окружений: он нужен почти в
каждом сценарии (id вида python3_13 / gcc14_cpp23 / python-lyceum),
но меняется в лучшем случае раз в месяц. Правило: если с последнего успешного
запроса прошло меньше суток — не ходим в сеть; при любой ошибке, связанной с
неизвестным компилятором, кеш сбрасывается принудительно.
"""

import json
import os
import time
from pathlib import Path

CACHE_DIR = Path(os.environ.get("CONTEST_KIT_CACHE_DIR", Path.home() / ".cache" / "contest-kit"))

COMPILERS = "compilers"
COMPILERS_TTL = 24 * 3600


def _path(name):
    return CACHE_DIR / f"{name}.json"


def get(name, ttl):
    """Значение из кеша или None, если протухло/нет/битое."""
    p = _path(name)
    try:
        with p.open(encoding="utf-8") as f:
            blob = json.load(f)
    except (OSError, ValueError):
        return None
    if time.time() - blob.get("stored_at", 0) > ttl:
        return None
    return blob.get("value")


def put(name, value):
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with _path(name).open("w", encoding="utf-8") as f:
            json.dump({"stored_at": time.time(), "value": value}, f, ensure_ascii=False)
    except OSError:
        pass  # кеш — оптимизация, его отсутствие не ошибка
    return value


def invalidate(name):
    try:
        _path(name).unlink()
    except OSError:
        pass


def age(name):
    """Сколько секунд назад записано, или None."""
    try:
        with _path(name).open(encoding="utf-8") as f:
            return time.time() - json.load(f).get("stored_at", 0)
    except (OSError, ValueError):
        return None
