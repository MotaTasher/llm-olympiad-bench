"""
Лог вызовов — одна JSONL-строка на запуск команды.

Два адресата. Первый — мы: видеть, что реально гоняется, где чаще всего ловятся
ретраи и ошибки. Второй — продуктовая команда Контеста: обезличенный экспорт
этого лога показывает, какие операции с админкой люди делают на самом деле и
в каком порядке.

Секреты сюда не попадают ни при каких условиях: куки редактятся, содержимое
файлов не пишется, от куки остаётся только отпечаток.
"""

import json
import os
import time
from pathlib import Path

from . import auth

STATE_DIR = Path(os.environ.get("CONTEST_KIT_STATE_DIR", Path.home() / ".local" / "state" / "contest-kit"))
LOG_FILE = STATE_DIR / "commands.jsonl"

# Аргументы, значение которых само по себе секрет.
_SECRET_ARGS = {"--cookie", "--csrf", "--from-curl"}


def scrub_argv(argv):
    out, skip = [], False
    for arg in argv:
        if skip:
            out.append("<скрыто>")
            skip = False
            continue
        if arg in _SECRET_ARGS:
            out.append(arg)
            skip = True
            continue
        out.append(auth.redact(arg))
    return out


class Record:
    """Накапливает факты о запуске; пишется одной строкой в конце."""

    def __init__(self, argv, enabled=True):
        self.enabled = enabled and os.environ.get("CONTEST_KIT_NO_LOG") != "1"
        self.started = time.time()
        self.data = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "argv": scrub_argv(list(argv)),
            "cwd": os.getcwd(),
            "http": {"calls": 0, "retries_423": 0, "bytes_up": 0},
        }

    def note(self, **fields):
        self.data.update(fields)

    def http_call(self, retried_locked=0, bytes_up=0):
        h = self.data["http"]
        h["calls"] += 1
        h["retries_423"] += retried_locked
        h["bytes_up"] += bytes_up

    def finish(self, exit_code=0, error=None):
        self.data["dur_ms"] = int((time.time() - self.started) * 1000)
        self.data["exit"] = exit_code
        if error is not None:
            self.data["error"] = {"code": error.code, "message": auth.redact(error.message)}
        self.write()

    def write(self):
        if not self.enabled:
            return
        try:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            with LOG_FILE.open("a", encoding="utf-8") as f:
                f.write(json.dumps(self.data, ensure_ascii=False) + "\n")
        except OSError:
            pass  # лог не должен ронять команду
