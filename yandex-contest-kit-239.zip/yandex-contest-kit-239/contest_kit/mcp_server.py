"""
MCP-сервер над contest-kit: те же операции с Яндекс.Контестом, но как
инструменты для Claude (Desktop, Code — любого клиента MCP).

Сервер тонкий и намеренно глупый: каждый инструмент запускает CLI отдельным
процессом и отдаёт его вывод. Логика площадки живёт в одном месте
(`legacy/contest_cli.py` и пакет `contest_kit`), и что бы ни починили там,
здесь чинить не придётся. Цена — ~0.3 с на запуск питона, для заливки задачи
это ничто.

Три правила, которые сервер держит сам, чтобы агенту не приходилось помнить:

  * файлы заливаются строго по одному, с ретраями — площадка отвечает 423 на
    параллельные операции (`upload_folder`);
  * значения кук в вывод не попадают — всё проходит через `auth.redact`;
  * массового удаления (`clear`) здесь нет: это команда для человека в
    терминале, с подтверждением.

Запуск: `contest-mcp` (stdio). Регистрация в клиентах — docs/CLAUDE-SETUP.md.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from . import auth

try:  # mcp >= 2.0
    from mcp.server.mcpserver import MCPServer as _Server
except ImportError:  # mcp 1.x
    from mcp.server.fastmcp import FastMCP as _Server

ROOT = Path(__file__).resolve().parent.parent
LEGACY_CLI = ROOT / "legacy" / "contest_cli.py"
TEMPLATE_DIR = ROOT / "templates" / "csv-problem"
DOCS_DIR = ROOT / "docs"

UPLOAD_ATTEMPTS = 5
UPLOAD_BACKOFF = 4.0   # секунды между попытками, как в проверенном upload.sh
SKIP_NAMES = {".DS_Store", "__pycache__", ".git", "Thumbs.db"}

INSTRUCTIONS = """\
Инструменты для заливки и проверки задач в Яндекс.Контесте (admin.contest.yandex.ru).

Порядок работы над задачей: auth_status → (recon по контесту) → создать или
клонировать задачу → залить файлы (upload_folder) → условие (statement_set_all)
→ чекер (checker_compile) → набор тестов (testset_set_pattern) → списки файлов
стадий (stage_files) → check_files → контрольная посылка (submit → submission_get).
Полный протокол с проверками на каждом шаге — ресурс contest://help/protocol,
устройство площадки и грабли — contest://help/platform, условие —
contest://help/statements, разведка (контест, Google Drive, DevTools) —
contest://help/recon, все команды CLI — contest://help/cli.

Ссылка на задачу подойдёт любая (…/problems/<id>/settings, /files и т.д.),
контест — число или ссылка с /contests/<id>/.
"""

server = _Server(
    "yandex-contest",
    instructions=INSTRUCTIONS,
)


# --- запуск CLI ---------------------------------------------------------------


def _run(args: list[str], timeout: int = 900, cwd: str | None = None) -> str:
    """Запустить legacy CLI и вернуть вывод текстом. Код возврата — в первой строке,
    если он ненулевой; куки из вывода вырезаются всегда."""
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
    try:
        proc = subprocess.run(
            [sys.executable, str(LEGACY_CLI), *args],
            capture_output=True, text=True, timeout=timeout, env=env, cwd=cwd,
        )
    except subprocess.TimeoutExpired:
        return f"[timeout] команда не завершилась за {timeout} с: {' '.join(args[:2])}"
    out = proc.stdout
    if proc.stderr.strip():
        out += "\n[stderr]\n" + proc.stderr
    out = auth.redact(out).strip()
    if proc.returncode != 0:
        out = f"[exit {proc.returncode}]\n{out}"
    return out or "(команда ничего не напечатала)"


def _contest(args: list[str]) -> str:
    """То же для нового CLI (`contest …`) — пока это только группа auth."""
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    proc = subprocess.run(
        [sys.executable, "-m", "contest_kit.cli.main", *args],
        capture_output=True, text=True, timeout=120, env=env, cwd=str(ROOT),
    )
    out = (proc.stdout + ("\n" + proc.stderr if proc.stderr.strip() else "")).strip()
    return auth.redact(out) or f"[exit {proc.returncode}]"


def _local(path: str) -> Path:
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"Локального файла нет: {p}")
    return p


# --- доступ -------------------------------------------------------------------


@server.tool()
def auth_status() -> str:
    """Жива ли сессия админки. Запускать ДО любой другой команды: мёртвая кука
    в остальных инструментах выглядит как невнятная ошибка разбора JSON.
    Если «НЕ РАБОТАЕТ» — попросить человека выполнить в терминале
    `contest auth login --browser` (откроется Chrome, он залогинится) и ждать."""
    return _contest(["auth", "status"])


# --- задача: настройки и файлы ----------------------------------------------


@server.tool()
def problem_settings(problem: str) -> str:
    """Настройки задачи: тип чекера, скомпилированный чекер и его компилятор,
    списки файлов по стадиям (compile/runtime/checker/postproc), окружение
    постпроцессора, лимиты. `problem` — любая ссылка на задачу в админке."""
    return _run(["settings", problem])


@server.tool()
def problem_files(problem: str) -> str:
    """Дерево файлов задачи на площадке (путь, размер, тип) — без скачивания.
    Смотреть после каждой заливки: архивы площадка разворачивает молча."""
    return _run(["list", problem])


@server.tool()
def problem_get(problem: str, path: str) -> str:
    """Прочитать одно поле объекта задачи по пути через точку:
    name, shortName, metaInfo.maxScore, fileSettings.maxSourceSize,
    runtimeLimit.common.timeLimit, checkerSettings.details.scoring, testSets …"""
    return _run(["get", problem, path])


@server.tool()
def problem_set(problem: str, path: str, value: str) -> str:
    """Записать одно поле объекта задачи (GET → правка → PATCH целиком).
    `value` разбирается как JSON, если получится (true/false/числа/"строка"),
    иначе кладётся строкой. Наборы тестов так править НЕЛЬЗЯ — только
    testset_set_pattern: сервер молча принимает PATCH и ничего не сохраняет."""
    return _run(["set", problem, path, value])


@server.tool()
def upload_file(problem: str, local_path: str, target_path: str) -> str:
    """Залить один файл по пути внутри задачи (например `checkers/checker.cpp`).
    Архивы (.zip/.tar.gz) площадка разворачивает и сам архив не сохраняет —
    чтобы отдать участнику архив целиком, заверни его во внешний архив."""
    _local(local_path)
    return _run(["upload", problem, local_path, target_path])


@server.tool()
def upload_folder(problem: str, local_dir: str, target_prefix: str = "") -> str:
    """Залить папку целиком, СТРОГО ПО ОДНОМУ файлу с ретраями (параллельные
    операции ловят 423 Locked). Структура подпапок сохраняется; `target_prefix`
    кладёт всё под указанный путь в задаче. Служебный мусор (.DS_Store,
    __pycache__) пропускается. Возвращает отчёт по каждому файлу."""
    root = _local(local_dir)
    if not root.is_dir():
        return f"[ошибка] не папка: {root}"
    files = sorted(
        p for p in root.rglob("*")
        if p.is_file() and not (set(p.relative_to(root).parts) & SKIP_NAMES)
        and not p.name.startswith("._")
    )
    if not files:
        return f"В {root} нет файлов"
    report, failed = [], []
    for p in files:
        rel = p.relative_to(root).as_posix()
        target = f"{target_prefix.rstrip('/')}/{rel}" if target_prefix else rel
        out = ""
        for attempt in range(1, UPLOAD_ATTEMPTS + 1):
            out = _run(["upload", problem, str(p), target])
            if "OK:" in out:
                report.append(f"OK  {target}")
                break
            if attempt < UPLOAD_ATTEMPTS:
                time.sleep(UPLOAD_BACKOFF)
        else:
            failed.append(target)
            report.append(f"FAIL {target}\n      {out.splitlines()[-1] if out else ''}")
    summary = f"Залито {len(files) - len(failed)} из {len(files)}"
    if failed:
        summary += f"; НЕ ЗАЛИТО: {', '.join(failed)}"
    return summary + "\n" + "\n".join(report)


@server.tool()
def delete_file(problem: str, path: str) -> str:
    """Удалить один файл из дерева задачи. Массового удаления здесь нет
    намеренно — это `contest_cli.py clear` руками, с подтверждением."""
    return _run(["delete", problem, path])


@server.tool()
def download_problem(problem: str, out_dir: str) -> str:
    """Скачать всё дерево файлов задачи в локальную папку (идемпотентно:
    совпадающие по размеру файлы пропускаются). Так берётся образец с уже
    работающей задачи."""
    return _run(["download", problem, out_dir])


# --- условие -------------------------------------------------------------------


@server.tool()
def statement_list(problem: str) -> str:
    """Какие языки условия есть и сколько символов в каждой секции
    (legend, input-format, output-format, interaction, scoring, notes)."""
    return _run(["statement-list", problem])


@server.tool()
def statement_get(problem: str, locale: str = "ru", section: str = "legend") -> str:
    """Прочитать одну секцию условия. section: legend | input-format |
    output-format | interaction | scoring | notes."""
    return _run(["statement-get", problem, locale, section])


@server.tool()
def statement_set(problem: str, locale: str, section: str, local_file: str) -> str:
    """Залить одну секцию условия из markdown-файла (файл целиком становится
    секцией). Пустой файл очищает секцию — так убирают наследство донора
    после клонирования."""
    _local(local_file)
    return _run(["statement-set", problem, locale, section, local_file])


@server.tool()
def statement_set_all(problem: str, locale: str, local_dir: str) -> str:
    """Залить условие по секциям из папки одним запросом: берутся файлы
    legend.md, input-format.md, output-format.md, interaction.md, scoring.md,
    notes.md — какие найдутся. Locale создаётся, если его нет.
    Секции, которых у задачи быть не должно, потом очистить statement_set
    с пустым файлом: у клона остаются секции донора."""
    _local(local_dir)
    return _run(["statement-set-all", problem, locale, local_dir])


@server.tool()
def upload_statement(problem: str, local_file: str, locale: str = "ru",
                     section: str = "legend") -> str:
    """Весь текст условия одним файлом в одну секцию (по умолчанию ru/legend).
    Вложения (данные, baseline) участник видит ТОЛЬКО если на них есть
    markdown-ссылка в тексте: [data.zip](statements/data/data.zip)."""
    _local(local_file)
    return _run(["upload-statement", problem, local_file, locale, section])


# --- чекер, стадии, тесты -----------------------------------------------------


@server.tool()
def compilers(problem: str, query: str = "") -> str:
    """Список компиляторов/окружений площадки (id, название, язык), с фильтром
    по подстроке. Нужна ссылка на любую задачу — площадка требует Referer."""
    args = ["compilers", problem] + ([query] if query else [])
    return _run(args)


@server.tool()
def checker_compile(problem: str, source_path: str, compiler_id: str = "gcc14_cpp23",
                    checker_type: str = "TESTLIB_EXITCODE_CHECKER") -> str:
    """Скомпилировать чекер из файла, УЖЕ залитого в дерево задачи (путь внутри
    задачи, например checkers/checker.cpp). Ждёт результата.
    Для задач с баллами — только TESTLIB_EXITCODE_CHECKER: EJUDGE берёт из
    stdout первый токен и молча ставит 0 баллов при OK."""
    return _run(["checker-compile", problem, source_path, compiler_id, checker_type], timeout=600)


@server.tool()
def checker_scoring(problem: str, on: bool = True) -> str:
    """«Чекер выставляет баллы» — да/нет. Для датасетных задач — да."""
    return _run(["checker-scoring", problem, "on" if on else "off"])


@server.tool()
def stage_files(problem: str, stage: str, action: str, path: str,
                target_path: str = "") -> str:
    """Списки файлов по стадиям проверки. stage: compile-files | runtime-files |
    checker-files | postproc-files. action: add | remove — путь, уже лежащий в
    дереве; upload — залить локальный файл `path` в `target_path` (по умолчанию
    имя файла в корне) И сразу вписать в список.
    add без реального файла создаёт путь-призрак — ловится check_files."""
    if stage not in {"compile-files", "runtime-files", "checker-files", "postproc-files"}:
        return "[ошибка] stage: compile-files | runtime-files | checker-files | postproc-files"
    if action == "upload":
        _local(path)
        return _run([stage, problem, "upload", path] + ([target_path] if target_path else []))
    if action not in {"add", "remove"}:
        return "[ошибка] action: add | remove | upload"
    return _run([stage, problem, action, path])


@server.tool()
def postproc_env(problem: str, compiler_id: str = "python3_13") -> str:
    """Окружение постпроцессора (id из compilers) или `none`, чтобы снять."""
    return _run(["postproc-env", problem, compiler_id])


@server.tool()
def check_files(problem: str) -> str:
    """Сверить списки файлов всех стадий с реальным деревом: напечатать
    призраки — пути, вписанные в настройки, но отсутствующие в дереве.
    Запускать перед контрольной посылкой."""
    return _run(["check-files", problem])


@server.tool()
def testset_get(problem: str, index: int = 0) -> str:
    """Набор тестов: паттерны входа/ответа, сколько тестов нашлось."""
    return _run(["testset-get", problem, str(index)])


@server.tool()
def testset_set_pattern(problem: str, input_pattern: str, output_pattern: str,
                        index: int = 0) -> str:
    """Задать паттерны набора тестов и пересканировать дерево (то же, что кнопка
    «Обновить тесты»). Паттерн — ТОЧНОЕ имя файла в дереве, не glob:
    tests/public и tests/public.a. Единственный рабочий способ править тесты."""
    return _run(["testset-set-pattern", problem, str(index), input_pattern, output_pattern])


@server.tool()
def set_name(problem: str, name: str, locale: str = "ru") -> str:
    """Название задачи."""
    return _run(["set-name", problem, name, locale])


# --- создание ---------------------------------------------------------------


@server.tool()
def create_problem(name: str) -> str:
    """Создать пустую задачу в банке. Печатает id и ссылку на настройки.
    Чаще лучше clone_problem: у клона уже правильный профиль."""
    return _run(["create-problem", name])


@server.tool()
def clone_problem(problem: str) -> str:
    """Клонировать задачу целиком (файлы, чекер, тесты, настройки, условие).
    После клона: заменить файлы, залить своё условие, ОЧИСТИТЬ секции условия
    донора и удалить его лишние файлы."""
    return _run(["clone-problem", problem])


# --- контест ------------------------------------------------------------------


@server.tool()
def contest_settings(contest: str) -> str:
    """Ключевые настройки контеста: время, компиляторы, лимит размера посылки
    (дефолт 256 КБ режет zip с ноутбуком!), монитор, повторные посылки."""
    return _run(["contest-settings", contest])


@server.tool()
def contest_get(contest: str, path: str) -> str:
    """Поле объекта контеста: compilers, sourceSizeLimit, startTime, duration,
    monitorPlugin, duplicateSubmissionsAllowed …"""
    return _run(["contest-get", contest, path])


@server.tool()
def contest_set(contest: str, path: str, value: str) -> str:
    """Записать поле контеста. Пример: sourceSizeLimit 41451520.
    Осторожно с монитором: если настройки лидерборда делали руками на стороне
    Яндекса, PATCH их перетрёт."""
    return _run(["contest-set", contest, path, value])


@server.tool()
def contest_problems(contest: str) -> str:
    """Задачи контеста: буква, название, id."""
    return _run(["contest-problems", contest])


@server.tool()
def contest_add_problem(contest: str, problem: str, letter: str = "") -> str:
    """Привязать существующую задачу к контесту буквой (по умолчанию первая
    свободная). Идемпотентно. Привязывается тот же объект, не копия: правка
    файлов задачи видна во всех контестах, куда она привязана."""
    return _run(["contest-add-problem", contest, problem] + ([letter] if letter else []))


@server.tool()
def contest_remove_problem(contest: str, problem: str) -> str:
    """Отвязать задачу от контеста (саму задачу не удаляет)."""
    return _run(["contest-remove-problem", contest, problem])


# --- посылки ------------------------------------------------------------------


@server.tool()
def submit(contest: str, problem: str, local_file: str, compiler_id: str) -> str:
    """Отправить решение — всегда от имени залогиненного админа как участника.
    Так проверяется задача боем: эталон должен получить ожидаемый балл,
    заведомо плохое решение — низкий. Повтор того же файла байт-в-байт даёт
    400 Duplicate, если в контесте не разрешены повторы."""
    _local(local_file)
    return _run(["submit", contest, problem, local_file, compiler_id])


@server.tool()
def submission_get(submission: str) -> str:
    """Отчёт по посылке: вердикт, баллы, компилятор, начало лога компиляции.
    Вердикт приходит не сразу — если статус не FINISHED, подождать и повторить."""
    return _run(["submission-get", submission])


@server.tool()
def submission_json(submission: str) -> str:
    """Полный JSON посылки: postProcessorMessage (текст ошибки упавшей посылки),
    tests[] (время, память, вердикт по тестам), compileLog, publicLog (лог
    инвокера, там «Problem extracted at …»). Для разбора «почему ноль»:
    краткий submission_get этого не печатает."""
    return _run(["submission-json", submission])


@server.tool()
def submissions(contest: str, problem: str = "", limit: str = "20") -> str:
    """Список посылок контеста (id, задача, участник, вердикт, балл).
    `limit` — число или `all`; площадка отдаёт не больше 100 за раз, `all`
    ходит страницами."""
    args = ["submissions", contest, "--limit", limit]
    if problem:
        args += ["--problem", problem]
    return _run(args)


@server.tool()
def submission_stat(contest: str) -> str:
    """Сводка по посылкам контеста: всего, по вердиктам, по статусам."""
    return _run(["submission-stat", contest])


@server.tool()
def download_submission(submission: str, out_file: str) -> str:
    """Скачать файл посылки как есть (и текст, и zip) — чтобы прогнать локально
    через simulate.sh и отличить «участник ошибся» от «чекер врёт»."""
    return _run(["download-submission", submission, out_file])


@server.tool()
def rejudge(contest: str, submission_ids: list[str]) -> str:
    """Перетестировать посылки. Обязательно после правки файлов задачи: воркеры
    держат старую распаковку и часть посылок продолжает считаться старым score.py."""
    return _run(["rejudge", contest, *submission_ids])


# --- разведка -----------------------------------------------------------------


@server.tool()
def recon(contest: str, with_files: bool = False) -> str:
    """Разведка контеста одним вызовом: настройки, список задач, сводка по
    посылкам и по каждой задаче — настройки, языки условия, при with_files —
    дерево файлов. Только чтение. С этого начинается любая работа с чужим или
    забытым контестом: видно, что уже настроено и на что похожи рабочие задачи."""
    parts = [f"# Контест {contest}\n", "## Настройки\n", _run(["contest-settings", contest]),
             "\n## Задачи\n"]
    problems_out = _run(["contest-problems", contest])
    parts.append(problems_out)
    parts.append("\n## Посылки\n" + _run(["submission-stat", contest]))
    refs = _problem_refs(problems_out)
    for letter, ref in refs:
        url = f"https://admin.contest.yandex.ru/problems/{ref.replace('/', '%2F')}/settings"
        parts.append(f"\n## Задача {letter} — {url}\n")
        parts.append(_run(["settings", url]))
        parts.append("\n" + _run(["statement-list", url]))
        parts.append("\n" + _run(["testset-get", url, "0"]))
        if with_files:
            parts.append("\n" + _run(["list", url]))
    return "\n".join(parts)


def _problem_refs(problems_out: str) -> list[tuple[str, str]]:
    """Из вывода contest-problems достать пары (буква, плоский id задачи)."""
    import re

    # Строка вида «  A: Название задачи  (123456/2026_09_01/aB1cD2eF3g)»
    refs = []
    for line in problems_out.splitlines():
        m = re.match(r"\s*([^:\s]+):\s.*\((\d+/\d{4}_\d{2}_\d{2}/[^)\s]+)\)\s*$", line)
        if m:
            refs.append((m.group(1), m.group(2)))
    return refs


# --- локальный кит -------------------------------------------------------------


@server.tool()
def kit_new(dest_dir: str, name: str = "") -> str:
    """Развернуть шаблон датасетной задачи (final/ с конвейером, simulate.sh,
    upload.sh, raw/, subm/) в новую папку. Дальше правятся только файлы,
    помеченные TODO: score.py (метрика), ytest.csv, tests/, statements/."""
    if not TEMPLATE_DIR.is_dir():
        return f"[ошибка] шаблона нет: {TEMPLATE_DIR}"
    dest = Path(dest_dir).expanduser()
    if dest.exists() and any(dest.iterdir()):
        return f"[ошибка] папка уже не пустая: {dest}"
    shutil.copytree(TEMPLATE_DIR, dest, dirs_exist_ok=True)
    readme = dest / "README.md"
    listing = "\n".join(
        f"  {p.relative_to(dest).as_posix()}" for p in sorted(dest.rglob("*")) if p.is_file()
    )
    return (f"Шаблон развёрнут в {dest}" + (f" для задачи «{name}»" if name else "")
            + f"\nЧек-лист — {readme}\n{listing}")


@server.tool()
def kit_simulate(problem_dir: str, submission: str) -> str:
    """Прогнать все четыре стадии площадки локально на файле посылки
    (`<problem_dir>/simulate.sh <submission>`). Единственный надёжный способ
    отличить «участник ошибся» от «чекер врёт». Делать ДО заливки: эталон должен
    давать ~100, заведомо плохая посылка — ~0."""
    pdir = _local(problem_dir)
    sim = pdir / "simulate.sh"
    if not sim.exists():
        return f"[ошибка] нет {sim}"
    sub = _local(submission)
    proc = subprocess.run(
        ["bash", str(sim), str(sub)], capture_output=True, text=True, timeout=600, cwd=str(pdir),
    )
    out = proc.stdout + ("\n[stderr]\n" + proc.stderr if proc.stderr.strip() else "")
    return (f"[exit {proc.returncode}]\n" if proc.returncode else "") + out.strip()


# --- запасной выход ------------------------------------------------------------


@server.tool()
def contest_cli(args: list[str]) -> str:
    """Любая команда legacy CLI, которой нет среди инструментов: аргументы
    списком, как в терминале (например ["visibility", "<url>", "samples", "on"]).
    Справка по всем командам — ресурс contest://help/cli.
    `clear` (массовое удаление) отсюда недоступен."""
    if not args:
        return "[ошибка] пустая команда"
    if args[0] == "clear":
        return "[отказ] массовое удаление — только руками в терминале: contest_cli.py clear …"
    return _run(args)


# --- справка ресурсами ------------------------------------------------------------


@server.resource("contest://help/cli", name="Все команды CLI", mime_type="text/plain")
def help_cli() -> str:
    """Docstring legacy CLI: каждая команда с аргументами и примерами."""
    import ast

    tree = ast.parse(LEGACY_CLI.read_text(encoding="utf-8"))
    return ast.get_docstring(tree) or "(нет справки)"


def _doc(name: str) -> str:
    p = DOCS_DIR / name
    return p.read_text(encoding="utf-8") if p.exists() else f"(нет файла {p})"


@server.resource("contest://help/protocol", name="Протокол заливки задачи", mime_type="text/markdown")
def help_protocol() -> str:
    """Пошаговый протокол заливки с проверками на каждом шаге."""
    return _doc("UPLOAD-PROTOCOL.md")


@server.resource("contest://help/platform", name="Как устроена площадка", mime_type="text/markdown")
def help_platform() -> str:
    """Три сущности задачи, четыре стадии, контракт answers.json, компиляторы, грабли."""
    return _doc("PLATFORM.md")


@server.resource("contest://help/statements", name="Условие: секции и формулировки", mime_type="text/markdown")
def help_statements() -> str:
    """Как разложить условие по секциям и какими словами его писать."""
    return _doc("STATEMENTS.md")


@server.resource("contest://help/recon", name="Разведка: контест и Google Drive", mime_type="text/markdown")
def help_recon() -> str:
    """Как осмотреться перед работой: контест, задачи-образцы, материалы на Диске."""
    return _doc("RECON.md")


def main():
    server.run()


if __name__ == "__main__":
    main()
