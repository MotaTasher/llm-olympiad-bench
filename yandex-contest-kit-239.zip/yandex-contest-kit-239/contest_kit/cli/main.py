"""
Точка входа CLI.

Пока здесь только группа `auth` — то, с чего начинается работа с площадкой и
без чего не запускается ничего остального. Команды над задачами переезжают из
монолита (`legacy/contest_cli.py`, команда `ycontest`) следующей фазой.

Соглашения, одинаковые для всех будущих команд:
  * `--json` печатает машиночитаемый результат в stdout;
  * ошибка уходит в stderr структурой с кодом, причиной и следующей командой;
  * коды возврата: 0 — успех, 1 — ошибка площадки/окружения, 2 — ошибка вызова.
"""

import argparse
import json
import sys

from .. import audit, auth, errors
from ..http import Client


def build_parser():
    p = argparse.ArgumentParser(
        prog="contest",
        description="Загрузчик задач в Яндекс.Контест. Начни с `contest auth login`.",
    )
    p.add_argument("--json", action="store_true", help="машиночитаемый вывод")
    p.add_argument("--profile", help="имя профиля учётных данных")
    sub = p.add_subparsers(dest="group", required=True)

    a = sub.add_parser("auth", help="учётные данные и состояние сессии").add_subparsers(
        dest="cmd", required=True
    )

    login = a.add_parser("login", help="сохранить куки в профиль")
    src = login.add_mutually_exclusive_group()
    src.add_argument(
        "--from-curl",
        nargs="?",
        const="-",
        metavar="ФАЙЛ",
        help="взять куки из команды curl: путь к файлу или '-' для stdin (по умолчанию stdin)",
    )
    src.add_argument("--cookie", help="строка куки целиком (осторожно: попадёт в историю шелла)")
    src.add_argument(
        "--browser",
        action="store_true",
        help="открыть Chrome, залогиниться в нём, куки заберутся сами (нужен playwright)",
    )
    login.add_argument("--no-csrf", action="store_true", help="не забирать CSRF-токен сразу")
    login.add_argument(
        "--headless", action="store_true", help=argparse.SUPPRESS,  # для тестов --browser
    )
    login.add_argument("--url", help=argparse.SUPPRESS)               # для тестов --browser

    a.add_parser("status", help="жива ли сессия")
    a.add_parser("refresh", help="обновить CSRF-токен в профиле")
    return p


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    parser = build_parser()
    args = parser.parse_args(argv)
    record = audit.Record(argv)

    try:
        result = _dispatch(args)
    except errors.ContestError as e:
        record.finish(1, e)
        if args.json:
            print(json.dumps(e.to_dict(), ensure_ascii=False, indent=2), file=sys.stderr)
        else:
            print(e.render(), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        record.finish(130)
        return 130

    # Мёртвая сессия — не «успешно выполненная проверка», а состояние, из
    # которого нельзя работать дальше: отдаём ненулевой код, чтобы вызывающий
    # (агент или скрипт) сразу это увидел, не разбирая текст.
    code = 1 if isinstance(result, dict) and result.get("alive") is False else 0
    record.finish(code)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        _print_human(args, result)
    return code


def _dispatch(args):
    if args.group == "auth":
        if args.cmd == "login":
            return cmd_auth_login(args)
        if args.cmd == "status":
            return cmd_auth_status(args)
        if args.cmd == "refresh":
            return cmd_auth_refresh(args)
    raise errors.make("BAD_REF", f"Неизвестная команда: {args.group} {args.cmd}")


# --- команды ---------------------------------------------------------------


def cmd_auth_login(args):
    cookie, csrf = _read_cookie(args)
    creds = auth.Credentials(
        cookie=cookie,
        csrf=csrf,
        login=auth.login_from_cookie(cookie),
        profile=args.profile or "default",
        source="contest auth login",
    )
    missing = creds.missing_cookies()
    if missing:
        raise errors.make(
            "AUTH_MISSING",
            f"В куке нет обязательных полей: {', '.join(missing)}",
            next_command="contest auth login --browser",
            missing=missing,
        )

    # Сначала сохранить, потом добирать CSRF: иначе неудача с токеном (площадка
    # перекладывала его с места на место уже однажды) теряла и валидную куку.
    path = auth.save_credentials(creds)
    client = Client(creds)
    if not creds.csrf and not args.no_csrf:
        creds.csrf = client.refresh_csrf()
        auth.save_credentials(creds)

    status = client.status()
    status["saved_to"] = str(path)
    return status


def cmd_auth_status(args):
    return Client(auth.resolve(args.profile)).status()


def cmd_auth_refresh(args):
    creds = auth.resolve(args.profile)
    client = Client(creds)
    creds.csrf = client.refresh_csrf()
    auth.save_credentials(creds)
    return client.status()


# --- ввод/вывод ------------------------------------------------------------


def _read_cookie(args):
    """-> (cookie, csrf | None). CSRF из curl/браузера экономит один GET и
    не зависит от того, где площадка сегодня держит токен."""
    if args.cookie:
        return args.cookie.strip(), None

    if getattr(args, "browser", False):
        return auth.browser_login(
            url=args.url or auth.ADMIN_URL,
            headless=args.headless,
            notify=lambda msg: print(msg, file=sys.stderr),
        )

    source = args.from_curl or "-"
    if source == "-":
        if sys.stdin.isatty():
            print(
                "Вставь сюда команду curl (DevTools -> Network -> правый клик -> "
                "Copy as cURL), затем Ctrl-D:",
                file=sys.stderr,
            )
        blob = sys.stdin.read()
    else:
        with open(source, encoding="utf-8") as f:
            blob = f.read()

    cookie = auth.cookie_from_curl(blob)
    if not cookie:
        raise errors.make(
            "AUTH_MISSING",
            "В переданном тексте не нашлось куки (ожидается флаг -b/--cookie "
            "или заголовок Cookie в команде curl)",
            next_command="contest auth login --from-curl",
        )
    return cookie, auth.csrf_from_curl(blob)


def _print_human(args, result):
    if args.group != "auth":
        print(result)
        return

    mark = "жива" if result.get("alive") else "НЕ РАБОТАЕТ"
    print(f"Сессия: {mark}")
    print(f"  профиль:  {result.get('profile')}")
    print(f"  логин:    {result.get('login') or '—'}")
    print(f"  источник: {result.get('source')}")
    print(f"  CSRF:     {'есть' if result.get('has_csrf') else 'нет'}")
    print(f"  отпечаток куки: {result.get('cookie_fingerprint')}")
    if result.get("saved_to"):
        print(f"  сохранено в: {result['saved_to']}")
    if result.get("missing_cookies"):
        print(f"  НЕ ХВАТАЕТ КУК: {', '.join(result['missing_cookies'])}")
    if not result.get("alive"):
        print(f"\nПричина: {result.get('reason')}")
        print("Что делать: contest auth login --browser (или --from-curl, см. docs/SETUP.md)")


if __name__ == "__main__":
    sys.exit(main())
