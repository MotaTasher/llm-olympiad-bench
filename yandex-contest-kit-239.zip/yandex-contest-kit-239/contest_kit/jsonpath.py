"""
Доступ к произвольному полю объекта задачи/контеста по пути через точку.

Это эскейп-хатч: высокоуровневые команды покрывают частое, а всё остальное
правится generic get/set. По истории вызовов на нём висит каждый десятый вызов,
так что он остаётся первоклассной частью API, а не «на крайний случай».

Числовая часть пути — индекс массива: statements.0.details.legend.
"""

import json

from . import errors


def _key(part):
    return int(part) if part.lstrip("-").isdigit() else part


def get_path(obj, path):
    cur = obj
    walked = []
    for part in path.split("."):
        try:
            cur = cur[_key(part)]
        except (KeyError, IndexError, TypeError) as e:
            where = ".".join(walked) or "<корень>"
            raise errors.make(
                "BAD_REF",
                f"Не нашёл путь '{path}': оборвался на '{part}' (после {where})",
                available=_available(cur),
            ) from e
        walked.append(part)
    return cur


def set_path(obj, path, value):
    parts = path.split(".")
    parent = get_path(obj, ".".join(parts[:-1])) if len(parts) > 1 else obj
    try:
        parent[_key(parts[-1])] = value
    except (KeyError, IndexError, TypeError) as e:
        raise errors.make("BAD_REF", f"Не смог записать путь '{path}': {e}") from e


def coerce_value(raw):
    """Значение из командной строки: JSON, если разбирается, иначе строка."""
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return raw


def top_level_key(path):
    """PATCH шлётся по верхнему ключу пути — см. errors.HINTS[FIELD_NOT_PATCHABLE]."""
    return path.split(".")[0]


def _available(node):
    """Что можно было выбрать в точке обрыва — чтобы агент починился с первой попытки."""
    if isinstance(node, dict):
        return sorted(node.keys())[:40]
    if isinstance(node, list):
        return f"массив из {len(node)} элементов, индексы 0..{len(node) - 1}"
    return None
