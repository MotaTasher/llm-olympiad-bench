"""
Команда `ycontest` — вход в монолит `legacy/contest_cli.py` после `pip install -e .`.

Монолит лежит вне пакета и сам добавляет корень репозитория в sys.path, поэтому
ставится только редактируемо (`-e`); эта обёртка нужна, чтобы скриптам задач
(`upload.sh`) и MCP-серверу не знать абсолютных путей.
"""

import runpy
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parent.parent / "legacy" / "contest_cli.py"


def main():
    if not SCRIPT.exists():
        sys.exit(f"нет {SCRIPT}: contest-kit должен быть установлен редактируемо (pip install -e .)")
    sys.argv[0] = str(SCRIPT)
    runpy.run_path(str(SCRIPT), run_name="__main__")


if __name__ == "__main__":
    main()
