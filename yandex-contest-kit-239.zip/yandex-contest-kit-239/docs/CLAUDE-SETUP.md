# Подключение к Claude

Кит работает с Claude двумя способами, и оба живут в одном `.venv`:

- **Claude Code** (терминал, VS Code, Desktop → Code): агент читает `CLAUDE.md`
  в папке кита и зовёт команды `contest` / `ycontest` сам. MCP не обязателен,
  но с ним инструменты типизированы и заливка папки идёт с ретраями «из коробки»;
- **Claude Desktop** (обычный чат): без MCP агент до площадки не дотянется —
  сервер `contest-mcp` обязателен.

`install.sh` кита делает всё ниже сам; здесь — что именно и как проверить.

## 1. Сервер `contest-mcp`

Появляется после `pip install -e ".[all]"` в `.venv` кита:

```bash
.venv/bin/contest-mcp        # stdio-сервер; запущенный руками просто ждёт клиента
```

### Claude Code

Проектный конфиг — файл `.mcp.json` в корне кита (его создаёт `install.sh`,
подставив абсолютный путь):

```json
{
  "mcpServers": {
    "yandex-contest": {
      "command": "/полный/путь/к/киту/.venv/bin/contest-mcp",
      "args": []
    }
  }
}
```

Claude Code, открытый в этой папке, при первом запуске спросит, доверять ли
серверу из `.mcp.json`. Либо глобально, для любой папки:

```bash
claude mcp add --scope user yandex-contest -- /полный/путь/к/киту/.venv/bin/contest-mcp
claude mcp list                                   # должен быть «yandex-contest … ✓ Connected»
```

Внутри сессии: `/mcp` показывает серверы и их инструменты.

### Claude Desktop

Файл `~/Library/Application Support/Claude/claude_desktop_config.json`
(macOS; на Windows — `%APPDATA%\Claude\claude_desktop_config.json`), тот же
блок `mcpServers`, что выше. После правки — перезапустить Claude Desktop
целиком (Cmd-Q, не закрыть окно). В чате появится значок инструментов, среди
них `yandex-contest`.

`install.sh --desktop` дописывает блок в этот файл сам (существующие серверы
не трогает).

## 2. Google Drive — коннектор claude.ai

Не MCP-сервер в ките, а встроенный коннектор аккаунта: claude.ai → Settings →
Connectors → Google Drive → Connect. После этого инструменты Диска видны и в
Claude Desktop, и в Claude Code (как `claude.ai Google Drive`). Умеет искать и
читать файлы, скачивать содержимое, создавать новые; правку ячеек таблиц — нет.

Как этим пользоваться при заливке — [RECON.md](RECON.md), раздел 2.

## 3. Chrome DevTools MCP — админка глазами

Нужен только для того, что не видно через API (как отрендерилось условие,
что показывает монитор). Официальный сервер Google, ставится через `npx`:

```bash
claude mcp add --scope user chrome-devtools -- npx -y chrome-devtools-mcp@latest
```

Для Claude Desktop — тот же блок в `claude_desktop_config.json`:

```json
"chrome-devtools": { "command": "npx", "args": ["-y", "chrome-devtools-mcp@latest"] }
```

Нужен Node.js 20+. Сервер поднимает **свой** Chrome с отдельным профилем — в
нём один раз залогиниться в Яндекс руками. Про то, почему куки лучше не брать
через него, — [RECON.md](RECON.md), раздел 3.

## 4. Проверить, что всё соединилось

В любом клиенте попросить: «проверь сессию Контеста». Агент должен вызвать
`auth_status` (или `contest auth status`) и ответить «Сессия: жива» с логином.
Если «НЕ РАБОТАЕТ» — `contest auth login --browser` в терминале кита, см.
[SETUP.md](SETUP.md).
