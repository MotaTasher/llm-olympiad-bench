import sys
from pathlib import Path

# Тесты гоняются и без установки пакета — прямо из репозитория.
sys.path.insert(0, str(Path(__file__).parent))
