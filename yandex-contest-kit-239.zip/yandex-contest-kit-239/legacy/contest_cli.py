#!/usr/bin/env python3
r"""
Единый CLI для работы с файлами задач Яндекс.Контеста в обход веб-интерфейса
(реверс-инжинирнутый API админки): файлы, настройки, условия, тесты, контесты, посылки.

Секретов в этом файле нет: куки и CSRF-токен берутся из contest_kit.auth
(переменные окружения -> ~/.config/contest-kit/auth.json -> браузер).
Настройка описана в docs/SETUP.md и делается один раз.

═══ АРХИТЕКТУРА СБОРКИ И ПРОВЕРКИ РЕШЕНИЯ ═══

Яндекс.Контест имеет ЧЕТЫРЕ этапа обработки посылки участника:

  1. ЗАГРУЗКА + КОМПИЛЯЦИЯ РЕШЕНИЯ (compile-stage):
     - Сервер копирует файлы из "Файлов для компиляции" (compile-files)
       в директорию сборки вместе с посылкой участника.
     - Запускает Makefile или другой скрипт для компиляции.
     - Полезно: Makefile (стадия сборки), build.sh, дополнительные .h/.lib.

  2. ЗАПУСК РЕШЕНИЯ (runtime-stage):
     - Сервер копирует файлы из "Файлов для времени запуска" (runtime-files)
       в директорию запуска (например, run.sh, wrapper.py).
     - Запускает run.sh или аналогичный скрипт, который вызывает скомпилированный
       бинарник или интерпретирует решение.
     - Полезно: run.sh (обёртка запуска), wrapper.py (вызов Python решения),
       библиотеки, конфиги.

  3. ЗАПУСК ЧЕКЕРА (checker-stage):
     - Сервер запускает чекер (скомпилированный исполняемый файл), передав ему:
       * input.txt (ввод теста)
       * output.txt (вывод участника)
       * answer.txt (правильный ответ)
     - Чекер выводит: "OK", "WA", "PE" (или иной вердикт + балл при scoring=true).
     - Дополнительные файлы чекера (checker-files) копируются рядом с чекером
       (например, data.dat, config.json).

  4. ПОСТПРОЦЕСС (postprocessor-stage):
     - Если задана, сервер запускает постпроцессор — Python скрипт или C++ программа.
     - Получает всю информацию о прогоне (тесты, вердикты, логи) и преобразует баллы.
     - Файлы для постпроцессора (postproc-files): score.py, Makefile, ytest.csv,
       true_answers.csv, дополнительные скрипты.
     - Окружение постпроцессора (postproc-env): Python версия, R, Julia, и т.д.
     - Полезно: score.py (считает метрику типа RMSE), Makefile (если нужна компиляция),
       данные для калибровки (ytest.csv, true_answers.csv).

ИСПОЛЬЗОВАНИЕ (первый аргумент — тип операции):

  upload <problem_url> <local_file> <target_path_in_problem>
      Залить один файл по конкретному пути в задаче.
      Пример: python contest_cli.py upload https://admin.contest.yandex.ru/problems/XXX/files ./checker.py checkers/checker.py

  upload-folder <problem_url> <local_folder> [target_prefix]
      Залить содержимое папки рекурсивно, по одному файлу через API,
      сохраняя структуру подпапок относительно local_folder. Если задан
      target_prefix — кладёт не в корень задачи, а под этот префикс.
      Пример: python contest_cli.py upload-folder https://.../files ./task_kit
              python contest_cli.py upload-folder https://.../files ./task_kit/tests tests

  upload-zip-folder <problem_url> <local_folder> <target_parent_path>
      Зипует local_folder ЦЕЛИКОМ и грузит получившийся .zip в target_parent_path
      как обычный файл — если Яндекс.Контест автоматически распаковывает zip
      при загрузке (это наблюдалось в веб-форме), на сервере появится папка
      с содержимым local_folder. ПРОВЕРЕНО ТОЛЬКО ДЛЯ ВЕБ-ФОРМЫ, не для этого
      API-эндпоинта — при первом использовании проверь на сайте, распаковался
      ли zip в папку, а не остался лежать как .zip-файл. Если не распаковался —
      используй upload-folder (создаёт путь тем же POST, что и обычная заливка,
      папки создаются неявно при регистрации первого файла в них).

  download <problem_url> [out_dir]
      Скачать всё дерево файлов задачи целиком (рекурсивно) в out_dir
      (по умолчанию ./downloaded_problem). Идемпотентно — уже скачанные
      файлы с совпадающим размером пропускаются, можно перезапускать.

  delete <problem_url> <path_in_problem>
      Удалить один файл из дерева задачи.
      Пример: python contest_cli.py delete https://.../files tests/old_test

  clear <problem_url> [regex...] [--yes]
      Удалить файлы из дерева задачи пулом потоков (на сотнях файлов часть
      запросов ловит 423 Locked — перезапустить, удалённое повторно не
      трогается). Без regex-аргументов — удаляет ВСЁ дерево. С одним
      или несколькими regex — удаляет только файлы, чей путь матчится хотя
      бы под один из них (re.search, полный путь вида "tests/01.a").
      Печатает список и спрашивает подтверждение, если не передан --yes.
      Папки отдельно не хранятся — пропадают сами, когда в них не остаётся
      файлов, и появляются заново при следующей заливке.
      Примеры:
        python contest_cli.py clear https://.../files
        python contest_cli.py clear https://.../files --yes
        python contest_cli.py clear https://.../files '^tests/' --yes
        python contest_cli.py clear https://.../files '\.pyc$' '^__pycache__/' --yes

  settings <problem_url>
      Показать текущие настройки чекера/сборки: тип чекера, выставляет ли
      баллы, скомпилированный файл + его компилятор, доп. файлы чекера,
      файлы для компиляции / времени запуска / постпроцессора, окружение
      постпроцессора, лимиты времени/памяти на всех этапах.

  compilers <problem_url> [подстрока]
      Список доступных компиляторов/окружений (id + название + язык), можно
      отфильтровать подстрокой (ищет в id/name/lang, без учёта регистра).
      Без подстроки — весь список видимых недеприкейченных компиляторов.
      Пример: python contest_cli.py compilers https://.../settings python

  checker-compile <problem_url> <source_path> <compiler_id> [checker_type]
      Скомпилировать чекер из source_path (путь ВНУТРИ дерева задачи, уже
      залитый, например checkers/checker.py) заданным компилятором/
      окружением (id из команды compilers). checker_type по умолчанию
      TESTLIB_EXITCODE_CHECKER (варианты: TESTLIB_EXITCODE_CHECKER,
      TESTLIB_CHECKER, EJUDGE_EXITCODE_CHECKER — это все типы, которые
      поддерживает площадка; EJUDGE берёт из stdout первый токен и при OK
      молча ставит 0 баллов — для задач с баллами не годится). Ждёт
      завершения компиляции (поллинг) и печатает результат: при успехе —
      путь к получившемуся исполняемому файлу, при ошибке — stdout/stderr.
      Пример: python contest_cli.py checker-compile https://.../settings checkers/checker.cpp gcc14_cpp23

  checker-files <problem_url> add|remove <path> | upload <local_file> [target_path]
  compile-files <problem_url> add|remove <path> | upload <local_file> [target_path]
  runtime-files <problem_url> add|remove <path> | upload <local_file> [target_path]
  postproc-files <problem_url> add|remove <path> | upload <local_file> [target_path]
      Управление списками "Файлы чекера" (доп. файлы рядом с исполняемым
      файлом чекера) / "Файлы для компиляции" / "Файлы для времени запуска" /
      "Файлы постпроцессора".
      add/remove — работают с путём, который УЖЕ есть в дереве файлов
      задачи (см. upload-folder/upload или команду upload ниже).
      upload — ВАЖНО, закрывает частую дыру: реально заливает local_file
      в дерево задачи (в target_path, по умолчанию — просто имя файла в
      корне) И СРАЗУ регистрирует этот путь в списке. Одна add/remove без
      реального файла в дереве создаёт путь-призрак — пайплайн упадёт,
      пытаясь его скопировать при сборке/запуске/обработке (используй
      check-files, чтобы найти такие призраки).
      Примеры:
        python contest_cli.py compile-files https://.../settings upload ./final/score.py score.py
        python contest_cli.py postproc-files https://.../settings add score.py

  check-files <problem_url> [checker-files|compile-files|runtime-files|postproc-files]
      Сверить один (или все четыре, если не указано) список файлов с
      реальным деревом файлов задачи и напечатать, какие пути — призраки
      (числятся в настройках, но физически отсутствуют в дереве). Полезно
      после ручных правок в вебе или чтобы проверить задачу перед тем, как
      гонять решения.
      Пример: python contest_cli.py check-files https://.../settings

  postproc-env <problem_url> <compiler_id|none>
      Установить окружение постпроцессора (compiler_id из команды
      compilers), либо "none" чтобы снять.

  list <problem_url>
      Показать дерево файлов задачи (путь, размер, content-type) БЕЗ
      скачивания — быстрая проверка, что реально лежит на сервере и как
      называются файлы (например для сверки с паттернами тест-сетов).
      Пример: python contest_cli.py list https://.../files

  ---- НАБОРЫ ТЕСТОВ (страница "Тесты и решения") ----
  ВАЖНО: testSets.N.* НЕЛЬЗЯ править через общий get/set (ниже) — сервер
  тихо принимает PATCH (200/204), но ничего не сохраняет и не пересканирует
  файлы. Настоящий эндпоинт — отдельный testset-set-pattern (тот же вызов,
  что кнопка "Обновить тесты" в вебе). Паттерн — ТОЧНОЕ имя файла в дереве
  задачи (не glob), должно посимвольно совпадать с путём на вкладке "Файлы"
  (проверяй командой list).

  testset-get <problem_url> [index]
      Показать один набор тестов целиком (index по умолчанию 0): паттерны
      input/output, testsMatched, список реально найденных тестов.
      Пример: python contest_cli.py testset-get https://.../settings 0

  testset-set-pattern <problem_url> <index> <input_pattern> <output_pattern>
      Установить паттерны входного файла / файла правильного ответа для
      набора тестов и сразу пересканировать дерево файлов на совпадения.
      Пример: python contest_cli.py testset-set-pattern https://.../settings 0 tests/public tests/public.a

  ---- ОБЩИЕ НАСТРОЙКИ ЗАДАЧИ (страница "Настройки") ----
  Всё это — поля ОДНОГО общего JSON-объекта задачи (GET/PATCH
  /api/admin/problem/{id}), кроме statements (см. ниже — у него свой блок
  команд, т.к. это массив по языкам). Есть удобные команды под самое частое
  и низкоуровневые get/set под ВСЁ остальное.

  get <problem_url> <путь.через.точку>
      Прочитать произвольное поле общего объекта задачи (кроме statements —
      см. блок statement-*). Путь — через точку, числа — индексы массива.
      Примеры путей: name / shortName / type / metaInfo.maxScore /
      sectionVisibility.showSamples / fileSettings.maxSourceSize /
      allowHugeSubmissions / isPublished / checkerSettings.details.scoring /
      compileLimit.common.timeLimit / runtimeLimit.common.memoryLimit /
      testSets (для ЧТЕНИЯ ок; для ПРАВКИ паттернов тестов используй
      testset-set-pattern — см. блок "НАБОРЫ ТЕСТОВ" ниже, generic set
      сюда не пишет)
      Пример: python contest_cli.py get https://.../settings metaInfo.maxScore

  set <problem_url> <путь.через.точку> <значение>
      Записать произвольное поле (GET всего объекта -> правка поля -> PATCH
      целиком обратно — как делает сама веб-форма). Значение парсится как
      JSON, если получится (true/false/null/числа/"строка в кавычках"/
      [массив]/{"объект":1}), иначе кладётся как обычная строка.
      Примеры:
        python contest_cli.py set https://.../settings metaInfo.maxScore 100
        python contest_cli.py set https://.../settings sectionVisibility.showSamples true
        python contest_cli.py set https://.../settings fileSettings.maxSourceSize 262144
        python contest_cli.py set https://.../settings shortName '"chess"'
        python contest_cli.py set https://.../settings names.en '"Chess"'

  set-name <problem_url> <название> [locale]
      Короткая обёртка над set для названия задачи (locale по умолчанию ru).
      Пример: python contest_cli.py set-name https://.../settings "Моя задача"
              python contest_cli.py set-name https://.../settings "My problem" en

  checker-scoring <problem_url> on|off
      "Чекер выставляет баллы" (Да/Нет). Короткая обёртка над
      checkerSettings.details.scoring.

  max-score <problem_url> <число>
      "Максимальный балл" (metaInfo.maxScore).

  visibility <problem_url> samples|limits|io on|off
      Переключатели "Показывать примеры/ограничения/настройки файлов в
      условии задачи" (sectionVisibility.showSamples/showLimits/showIo).

  submission-limits <problem_url> [--max-source-size байт] [--allow-huge on|off]
      Размер посылки: --max-source-size правит fileSettings.maxSourceSize
      (байты исходного кода участника), --allow-huge правит
      allowHugeSubmissions (разрешить большие посылки, actual для
      файловых/zip-ответов). Можно оба флага сразу.
      Пример: python contest_cli.py submission-limits https://.../settings --max-source-size 20971520 --allow-huge on

  ---- УСЛОВИЯ ЗАДАЧИ (страница "Условия" / statements) ----
  Условие хранится НЕ как обычный файл дерева, а как элемент массива
  statements[] общего объекта задачи (один элемент на язык), с полями:
  details.legend / details.inputFormat / details.outputFormat /
  details.interaction / details.scoring / details.notes — каждое отдельный
  markdown-текст (при format=MARKDOWN). Правится тем же механизмом
  GET+PATCH, что и остальные настройки — просто со своими командами, т.к.
  нужно сначала найти нужный элемент массива по locale.

  statement-list <problem_url>
      Показать все языки условия (locale, format, путь) и длины секций
      в символах (без содержимого — быстрая проверка, что залито/пусто).

  statement-add-locale <problem_url> <locale> [format]
      Добавить условие на новом языке (если такого locale ещё нет).
      format по умолчанию MARKDOWN (видел в UI ещё как минимум опцию
      обычного HTML — если понадобится, узнай точное имя через
      `get <url> statements.0.format` на задаче с другим типом условия).
      Пример: python contest_cli.py statement-add-locale https://.../settings en

  statement-get <problem_url> <locale> <section> [out_file]
      Прочитать секцию условия. section — одно из: legend, input-format,
      output-format, interaction, scoring, notes. Без out_file — печатает
      в stdout, с out_file — пишет в локальный файл.
      Пример: python contest_cli.py statement-get https://.../settings ru legend

  statement-set <problem_url> <locale> <section> <local_file>
      Залить секцию условия из локального markdown-файла (весь файл
      целиком становится содержимым этой секции). locale должен уже
      существовать (см. statement-add-locale).
      Пример: python contest_cli.py statement-set https://.../settings ru legend ./legend.md

  statement-set-all <problem_url> <locale> <local_folder>
      Массово залить условие из папки: берёт файлы legend.md,
      input-format.md, output-format.md, interaction.md, scoring.md,
      notes.md — какие найдутся — и заливает все секции ОДНИМ PATCH.
      Создаёт locale, если его ещё нет.
      Пример: python contest_cli.py statement-set-all https://.../settings ru ./statements_ru

  upload-statement <problem_url> [local_file] [locale] [section]
      Быстрая обёртка: создаёт locale, если его нет, и заливает ОДИН файл
      целиком в ОДНУ секцию (по умолчанию ./statements/problem.md -> ru/legend
      — как раз то, что нужно, когда весь текст условия в одном .md без
      разбивки на input/output-format). Эквивалент statement-add-locale +
      statement-set с более удобными дефолтами.
      Пример: python contest_cli.py upload-statement https://.../settings
              python contest_cli.py upload-statement https://.../settings ./statements/problem.en.md en legend

<problem_url> — ЛЮБАЯ ссылка на задачу в admin.contest.yandex.ru
(/settings, /files, что угодно) — ID вытаскивается из неё автоматически.

  ---- СОЗДАНИЕ / КЛОНИРОВАНИЕ ----
  Реверс-инжинирнуто перехватом запросов в браузере 2026-07-25.

  create-contest <название>
      Создать новый контест (в текущей активной группе — группа не
      передаётся явно, сервер сам берёт её из сессии). Печатает id и ссылку
      на настройки.
      Пример: python contest_cli.py create-contest "Кружок по ИИ. Неделя 3"

  create-problem <название>
      Создать пустую задачу в банке задач (дальше настраивается обычными
      командами: upload/set/checker-compile/testset-set-pattern/...).
      Пример: python contest_cli.py create-problem "Предсказание спроса"

  clone-problem <problem_url>
      Склонировать существующую задачу целиком (файлы, чекер, тесты,
      настройки) — то же самое, что кнопка "Клонировать задачу" в вебе.
      Печатает id и ссылку на настройки новой (клонированной) задачи.
      Пример: python contest_cli.py clone-problem https://.../settings

  ---- КОНТЕСТ: НАСТРОЙКИ ----
  <contest_ref> — числовой ID контеста ИЛИ любая ссылка вида
  .../contests/{id}/... (ID вытаскивается автоматически). ВАЖНО: список
  задач контеста НЕ хранится в объекте контеста (см. блок ниже) — только
  общие настройки (время, компиляторы, лимиты, монитор и т.д.).

  contest-standard-settings <contest_ref>
      Привести существующий контест к нашим умолчаниям (31 день, повторные
      посылки, SCORING-монитор по лучшей посылке). ОСТОРОЖНО: перетирает
      настройки монитора — не запускать на контесте, где лидерборд
      настраивали на стороне Яндекса.

  contest-settings <contest_ref>
      Показать ключевые настройки контеста: владелец, время, компиляторы,
      разрешения (команды/старт/апсолвинг/повторные посылки), лимиты,
      видимость монитора и правильных ответов, типы авторизации.
      Пример: python contest_cli.py contest-settings https://.../contests/10000/settings

  contest-get <contest_ref> <путь.через.точку>
  contest-set <contest_ref> <путь.через.точку> <значение>
      Аналоги get/set, но для объекта контеста (GET/PATCH
      /api/admin/contest/{id}). Значение парсится как JSON, если получится.
      Примеры путей: name / startTime / duration / endTime / compilers /
      teamsAllowed / startingAllowed / upsolvingAllowed / sourceSizeLimit /
      monitorVisibility / correctAnswerVisibility / allowedAuthorizationTypes.
      Примеры:
        python contest_cli.py contest-get https://.../contests/10000/settings compilers
        python contest_cli.py contest-set https://.../contests/10000/settings teamsAllowed true

  ---- КОНТЕСТ: СПИСОК ЗАДАЧ (вкладка "Задачи") ----
  Список задач контеста хранится ОТДЕЛЬНО от объекта контеста — в объекте
  "набор задач" (problem set), на который контест ссылается через
  problemSetId, и сохраняется ПОЛНОЙ ЗАМЕНОЙ массива problems (ровно так
  делает сама веб-форма). Функции ниже сами читают текущий список, дописывают/
  убирают одну задачу и шлют массив целиком — снаружи выглядит как обычный
  add/remove.

  contest-problems <contest_ref>
      Показать список задач, привязанных к контесту (буква + название + id).

  contest-add-problem <contest_ref> <problem_ref> [letter]
      Привязать существующую задачу к контесту. <problem_ref> — ссылка на
      задачу, %2F-кодированный ID или уже плоский ID (group/date/slug) — любой
      формат подойдёт. letter — буква/алиас в контесте (A/B/...), по
      умолчанию первая свободная. Идемпотентно.
      Пример: python contest_cli.py contest-add-problem 10000 https://.../problems/123456%2F2026_07_23%2FaB1cD2eF3g/settings

  contest-remove-problem <contest_ref> <problem_ref>
      Отвязать задачу от контеста (саму задачу не удаляет, только убирает
      из списка задач этого контеста).

  ---- КОНТЕСТ: ПОСЫЛКИ ----

  submissions <contest_ref> [--problem <problem_ref>] [--participant <id>]
              [--filter <сырой_filter>] [--limit N|all] [--offset N] [--all]
      Показать список посылок контеста (id, задача, участник, вердикт, балл,
      статус). Без флагов — limit по умолчанию 20.
      --limit all (то же самое --all) — забрать ВСЕ посылки, сколько бы их ни
      было: клиент сам ходит страницами. --offset N — пропустить первые N
      записей (нумерация в записях, не в страницах).
      Осторожно: сама площадка за один запрос отдаёт максимум 100 записей и
      молча обрезает всё сверх того, а поле total в ответе не учитывает
      фильтры. Поэтому «показано 20» ничего не говорит о том, сколько посылок
      есть на самом деле — для выводов по всему контесту нужен --all.
      --problem — фильтр по конкретной задаче (любой формат ссылки/ID, как
      везде). --participant — фильтр по числовому ID участника (это и есть
      "мои посылки по задаче", если знаешь свой participant.id — он виден в
      выводе любой команды submissions/submission-get). --filter — сырая
      строка вида "field=value" добавляется как есть (для полей, для
      которых нет отдельного флага, например userId=/login=/groupId=/
      groupName= по аналогии — не проверялись вживую). При нескольких
      условиях сразу они комбинируются через И (AND).
      Примеры:
        python contest_cli.py submissions 10000
        python contest_cli.py submissions 10000 --problem https://.../problems/123456%2F2026_07_23%2FaB1cD2eF3g/settings
        python contest_cli.py submissions 10000 --participant 100000001 --limit 100

  rejudge <contest_ref> <id посылки> [<id> ...]
      Отправить посылки на перетестирование. Нужно после любой правки файлов
      задачи: воркеры держат распакованные копии пакета и сами их не обновляют,
      поэтому часть посылок продолжает считаться старым score.py
      (docs/PLATFORM.md, грабли 11).
      Запрос принимается мгновенно, пересчёт идёт секунды — проверять результат
      надо по отметке времени проверки посылки, а не по коду ответа.
      Пример:
        python contest_cli.py rejudge 12345 200000002 200000003

  submission-stat <contest_ref>
      Показать сводную статистику контеста: всего посылок, по вердиктам
      (OK/WrongAnswer/Crash/...), по статусам (FINISHED/...).

  submit <contest_ref> <problem_ref> <local_file> <compiler_id>
      Отправить решение на проверку — как кнопка "Отправить решение" на
      странице посылок контеста. ВАЖНО (подтверждено, не догадка): это ВСЕГДА
      посылка от имени самого залогиненного админа как участника — в API нет
      способа отправить "за другого человека". Протестировано 2026-07-25:
      для владельца контеста (permission=OWNER) работает сразу, даже на
      только что созданном контесте, без ручной регистрации участника — не
      проверялось для НЕ-владельцев (там регистрация ещё может понадобиться).
      Пример: python contest_cli.py submit 10000 123456/2026_07_23/aB1cD2eF3g ./solution.zip python-lyceum

  ---- ОДНА ПОСЫЛКА (по ID, БЕЗ привязки к контесту в пути) ----
  <submission_ref> — голое число (ID посылки) или ссылка вида
  .../submissions/{id}. Внутри — GET /api/admin/submission/{id}[/source-file],
  контест НЕ передаётся (даже не нужен — есть внутри ответа для справки).

  submission-get <submission_ref>
      Полный отчёт по одной посылке: контест, задача, участник, компилятор,
      имя файла, вердикт, баллы (предв./итог.), начало compileLog, и — если
      решение текстовое — начало sourceCode. Для полного файла целиком
      используй download-submission.
      Пример: python contest_cli.py submission-get 200000002

  submission-json <submission_ref>
      Полный JSON посылки как отдаёт площадка: postProcessorMessage (текст
      ошибки упавшей посылки), tests[] (время/память/вердикт по тестам),
      compileLog, publicLog (лог инвокера). Для разбора «почему ноль».
      Пример: python contest_cli.py submission-json 200000002

  download-submission <submission_ref> [out_file]
      Скачать РЕАЛЬНЫЙ загруженный файл посылки как есть (байты, не
      пересобранный текст) — работает и для текстовых решений, и для
      файловых/zip-ответов (fileSettings.answerType=FILE у датасетных
      задач). Без out_file — сохраняет под оригинальным именем
      файла из отчёта посылки.
      Пример: python contest_cli.py download-submission 200000002
              python contest_cli.py download-submission https://.../submissions/200000002 ./out/solution.zip
"""

import concurrent.futures
import json
import mimetypes
import os
import re
import sys
import time

import requests

BASE = "https://admin.contest.yandex.ru"

# ============================== ДОСТУП =======================================
#
# Куки и CSRF-токен живут вне репозитория, см. docs/SETUP.md. Настроить один раз:
#
#     contest auth login --browser
#
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from contest_kit import auth as _auth              # noqa: E402
from contest_kit.http import Client as _Client     # noqa: E402

_CREDS = None


def _creds():
    """Учётные данные на весь запуск; CSRF добирается со страницы админки."""
    global _CREDS
    if _CREDS is None:
        _CREDS = _auth.resolve()
        if not _CREDS.csrf:
            _CREDS.csrf = _Client(_CREDS).refresh_csrf()
    return _CREDS


DEBUG = os.environ.get("CONTEST_CLI_DEBUG") == "1"  # или поставь True здесь вручную

# ============================== ОБЩЕЕ ========================================


def parse_problem_id(url):
    """Достаём %2F-кодированный ID задачи из любой ссылки на неё."""
    m = re.search(r"/problems/([^/]+)/", url)
    if not m:
        raise ValueError(f"Не смог найти ID задачи в ссылке: {url}")
    return m.group(1)


def parse_contest_id(ref):
    """Достаём числовой ID контеста либо из голого числа, либо из любой
    ссылки вида .../contests/{id}/... или .../contest/{id}/..."""
    ref = ref.strip()
    if ref.isdigit():
        return ref
    m = re.search(r"/contests?/(\d+)", ref)
    if not m:
        raise ValueError(f"Не смог найти ID контеста в: {ref}")
    return m.group(1)


def parse_submission_id(ref):
    """Достаём числовой ID посылки либо из голого числа, либо из ссылки вида
    .../submissions/{id} (страница детали посылки)."""
    ref = ref.strip()
    if ref.isdigit():
        return ref
    m = re.search(r"/submissions?/(\d+)", ref)
    if not m:
        raise ValueError(f"Не смог найти ID посылки в: {ref}")
    return m.group(1)


def resolve_problem_id_plain(problem_ref):
    """
    Принимает ссылку на задачу (.../problems/<enc>/...), закодированный ID
    ("group%2Fdate%2Fslug") или уже плоский декодированный ID
    ("group/date/slug"). Возвращает ID в ПЛОСКОМ виде (со слэшами) — именно
    так задачи хранятся в problemset.problems[].id (список задач контеста).
    """
    if "/problems/" in problem_ref:
        enc = parse_problem_id(problem_ref)
    else:
        enc = problem_ref
    return enc.replace("%2F", "/").replace("%2f", "/")


def extract_cookie_from_curl(curl_text):
    patterns = [
        r"-b\s+'([^']+)'",
        r'-b\s+"([^"]+)"',
        r"--cookie\s+'([^']+)'",
        r'--cookie\s+"([^"]+)"',
        r"-H\s+'Cookie:\s*([^']+)'",
        r'-H\s+"Cookie:\s*([^"]+)"',
    ]
    for pat in patterns:
        m = re.search(pat, curl_text)
        if m:
            return m.group(1).strip()
    return None


def session(problem_id_enc=None, page="files", referer_path=None):
    """
    page — какая страница подставляется в Referer ("files"/"settings"/
    "statements"/"tests"). Запись общих настроек задачи (PATCH .../problem/{id})
    требует Referer со страницы, с которой это правится в вебе: с ".../files"
    PATCH настроек падает 403, хотя POST файла с тем же Referer проходит.
    Поэтому main() передаёт page под конкретную команду. Подробнее —
    docs/PLATFORM.md, грабли 3.

    referer_path — полный путь после домена для команд, у которых нет
    problem_id_enc (создание контеста/задачи) или чей Referer строится по схеме
    "/contests/{id}/*". Если передан — имеет приоритет.
    """
    creds = _creds()
    s = requests.Session()
    headers = {
        "User-Agent": "contest-kit-legacy",
        "Accept": "application/json, text/plain, */*",
        "Cookie": creds.cookie,
        "x-csrf-token": creds.csrf or "",
    }
    if referer_path:
        headers["Origin"] = BASE
        headers["Referer"] = f"{BASE}{referer_path}"
    elif problem_id_enc:
        headers["Origin"] = BASE
        headers["Referer"] = f"{BASE}/problems/{problem_id_enc}/{page}"
    s.headers.update(headers)
    if DEBUG:
        print(f"[debug] профиль {creds.profile} из {creds.source}, "
              f"кука {_auth.cookie_fingerprint(creds.cookie)}")
    return s


# ============================== ЗАГРУЗКА =====================================


def parse_upload_target(resp_json):
    """
    GET /api/admin/upload-file отдаёт S3 POST-policy:
    {"url": "...", "fields": {"key": ..., ...подпись...}, "key": "uploads/<ts>-<uuid>-<name>"}
    "key" (= fields["key"]) — это s3Id для шага 3.
    """
    return resp_json["url"], resp_json["fields"], resp_json["key"]


def upload_one_file(s, problem_id_enc, local_path, target_path_in_problem, content_type=None):
    filename = os.path.basename(local_path)
    content_type = content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"

    # Шаг 1: presigned URL / s3Id
    r = s.get(f"{BASE}/api/admin/upload-file",
              params={"contentType": content_type, "fileName": filename})
    if DEBUG:
        print(f"=== GET upload-file: status={r.status_code} ===\n{r.text[:1500]}")
    r.raise_for_status()
    try:
        data = r.json()
    except ValueError:
        print("Ответ не JSON (см. выше) — куки протухли. "
              "Обнови их: contest auth login --browser")
        sys.exit(1)

    upload_url, fields, s3_id = parse_upload_target(data)

    # Шаг 2: multipart POST-policy в S3 (без куки/csrf — прямой запрос в S3)
    with open(local_path, "rb") as f:
        put_resp = requests.post(upload_url, data=fields, files={"file": (filename, f, content_type)})
    if DEBUG:
        print(f"=== S3 upload: status={put_resp.status_code} ===\n{put_resp.text[:500]}")
    put_resp.raise_for_status()

    # Шаг 3: регистрация файла по пути в дереве задачи
    reg_resp = s.post(f"{BASE}/api/admin/problems/{problem_id_enc}/files",
                       json={"path": target_path_in_problem, "s3Id": s3_id})
    if DEBUG:
        print(f"=== register: status={reg_resp.status_code} ===\n{reg_resp.text[:500]}")
    reg_resp.raise_for_status()
    print(f"OK: {local_path} -> {target_path_in_problem}")


def upload_folder(s, problem_id_enc, local_root, target_prefix=""):
    """
    Рекурсивно заливает всё содержимое local_root, сохраняя структуру подпапок.
    target_prefix — если задан, все пути кладутся под этот префикс
    (например target_prefix="tests" при local_root=".../tests_compact").
    """
    local_root = os.path.abspath(local_root)
    n = 0
    for dirpath, _dirnames, filenames in os.walk(local_root):
        for fname in filenames:
            local_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(local_path, local_root).replace(os.sep, "/")
            target = f"{target_prefix.rstrip('/')}/{rel_path}" if target_prefix else rel_path
            upload_one_file(s, problem_id_enc, local_path, target)
            n += 1
    print(f"Готово: залито файлов — {n}")


def upload_zip_folder(s, problem_id_enc, local_folder, target_parent_path):
    """
    Зипует local_folder целиком (сама папка становится корнем архива) и грузит
    .zip в target_parent_path — расчёт на автораспаковку на стороне сервера
    (подтверждено для веб-формы, для этого API-эндпоинта пока не проверено).
    После загрузки — проверь на сайте, распаковалось ли в папку.
    """
    import shutil
    import tempfile

    local_folder = os.path.abspath(local_folder.rstrip("/"))
    folder_name = os.path.basename(local_folder)
    with tempfile.TemporaryDirectory() as tmp:
        zip_base = os.path.join(tmp, folder_name)
        zip_path = shutil.make_archive(zip_base, "zip", root_dir=os.path.dirname(local_folder), base_dir=folder_name)
        target = f"{target_parent_path.rstrip('/')}/{folder_name}.zip"
        upload_one_file(s, problem_id_enc, zip_path, target, content_type="application/zip")
    print(f"Зип загружен как {target} — проверь на сайте, распаковался ли он в папку "
          f"'{folder_name}/'. Если остался .zip-файлом — используй upload-folder вместо этого.")


# ============================== СКАЧИВАНИЕ ====================================


def list_files(s, problem_id_enc):
    """GET /api/admin/problem/{id}/file (без пути) — полное дерево файлов задачи."""
    r = s.get(f"{BASE}/api/admin/problem/{problem_id_enc}/file")
    r.raise_for_status()
    return r.json()


def flatten_tree(node, prefix=""):
    out = []
    for item in node.get("items", []):
        path = f"{prefix}{item['name']}"
        if item.get("directory"):
            out.extend(flatten_tree(item, prefix=path + "/"))
        else:
            out.append((path, item.get("size"), (item.get("contentType") or {}).get("type")))
    return out


def download_file(s, problem_id_enc, path, out_dir, retries=4):
    path_enc = path.replace("/", "%7C")
    url = f"{BASE}/api/admin/problem/{problem_id_enc}/file/{path_enc}"
    last_exc = None
    for attempt in range(1, retries + 1):
        try:
            r = s.get(url, timeout=60)
            r.raise_for_status()
            content = r.content
            local_path = os.path.join(out_dir, path)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            with open(local_path, "wb") as f:
                f.write(content)
            return len(content), r.headers.get("Content-Type")
        except (requests.exceptions.ChunkedEncodingError,
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout) as e:
            last_exc = e
            wait = 2 * attempt
            print(f"    [retry {attempt}/{retries}] {path}: {e} — жду {wait}с")
            time.sleep(wait)
    raise last_exc


def download_all(s, problem_id_enc, out_dir):
    tree = list_files(s, problem_id_enc)
    files = flatten_tree(tree)
    print(f"Файлов в дереве: {len(files)}")
    ok, skipped, mismatched, failed = 0, 0, [], []
    for path, expected_size, _ctype in files:
        local_path = os.path.join(out_dir, path)
        if os.path.exists(local_path) and os.path.getsize(local_path) == expected_size:
            skipped += 1
            continue
        try:
            n_bytes, _ = download_file(s, problem_id_enc, path, out_dir)
        except Exception as e:
            print(f"FAILED: {path}: {e}")
            failed.append(path)
            continue
        status = "OK" if n_bytes == expected_size else "MISMATCH"
        if status == "MISMATCH":
            mismatched.append((path, expected_size, n_bytes))
        print(f"{status} ({n_bytes}b): {path}")
        ok += 1
    print(f"\nСкачано: {ok}, пропущено (уже было): {skipped}, не удалось: {len(failed)}. Папка: {out_dir}")
    if mismatched:
        print("Несовпадение размера:")
        for path, exp, got in mismatched:
            print(f"  {path}: ожидалось {exp}, получено {got}")
    if failed:
        print("Не скачались (перезапусти скрипт — остальное пропустится):")
        for path in failed:
            print(f"  {path}")


# ============================== УДАЛЕНИЕ ======================================


def delete_file(s, problem_id_enc, path_in_problem):
    """DELETE .../problem/{id}/file/{path}. id через %2F, путь к файлу через %7C."""
    path_enc = path_in_problem.replace("/", "%7C")
    resp = s.delete(f"{BASE}/api/admin/problem/{problem_id_enc}/file/{path_enc}")
    if DEBUG:
        print(f"=== DELETE: status={resp.status_code} ===\n{resp.text[:500]}")
    resp.raise_for_status()
    print(f"DELETED: {path_in_problem}")


def clear_all(s, problem_id_enc, patterns=None, confirm=False, workers=8):
    """
    Удаляет файлы из дерева задачи пулом потоков. Часть DELETE-запросов при
    этом ловит 423 Locked (площадка блокирует задачу на время операции) —
    команда для человека, перезапуск дочищает.

    patterns: список regex-строк. Файл удаляется, если его путь матчится
    хотя бы под один паттерн (re.search). Пусто/None — удаляются все файлы.
    Папки как отдельные объекты на этой площадке не существуют — пропадают
    сами, когда в них не остаётся файлов, и появляются заново при заливке.
    """
    tree = list_files(s, problem_id_enc)
    all_files = flatten_tree(tree)

    if patterns:
        compiled = [re.compile(p) for p in patterns]
        files = [f for f in all_files if any(c.search(f[0]) for c in compiled)]
    else:
        files = all_files

    if not files:
        print("Нечего удалять (подходящих файлов нет).")
        return

    print(f"Будет удалено файлов: {len(files)} из {len(all_files)}")
    for path, _size, _ctype in files:
        print(f"  {path}")
    if not confirm:
        answer = input("Точно удалить всё это? (yes/no): ").strip().lower()
        if answer != "yes":
            print("Отменено.")
            return

    ok, failed = 0, []

    def _delete(path):
        delete_file(s, problem_id_enc, path)
        return path

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        future_to_path = {pool.submit(_delete, path): path for path, _size, _ctype in files}
        for future in concurrent.futures.as_completed(future_to_path):
            path = future_to_path[future]
            try:
                future.result()
                ok += 1
            except Exception as e:
                print(f"FAILED: {path}: {e}")
                failed.append(path)

    print(f"\nУдалено: {ok}, не удалось: {len(failed)}")


# ===================== ЧЕКЕР / НАСТРОЙКИ ЗАДАЧИ ==============================
#
# В отличие от файлового дерева (upload/download/delete/clear), эти настройки
# хранятся не как файлы, а как поля общего JSON-объекта задачи. Есть два
# независимых механизма записи:
#
#  1) Компиляция чекера — POST .../checker/{путь%7Cчерез%7Cпайп}?compilerId=X&type=Y
#     (путь — ВНУТРИ дерева задачи, уже залитый через upload). Асинхронно,
#     статус узнаётся поллингом GET .../checker. При успехе сервер сам
#     проставляет результат первым элементом в checkerFiles.
#
#  2) Списки доп. файлов (Файлы чекера / Файлы для компиляции / Файлы для
#     времени запуска / Файлы постпроцессора) и окружение постпроцессора —
#     правятся через GET общего объекта задачи -> модификация нужного поля
#     -> PATCH обратно. ВАЖНО (проверено вживую, отловлено на реальной ошибке
#     пользователя): PATCH делает JSON-merge на уровне переданных top-level
#     ключей — значения ключей, которых НЕТ в теле PATCH, не трогаются
#     и не сбрасываются, а внутри переданного ключа сервер тоже мержит
#     вложенные объекты (проверено на sectionVisibility — отправили только
#     showSamples, showLimits/showIo не тронулись), но массивы заменяются
#     ЦЕЛИКОМ, не поэлементно.
#
#     Из этого следует главное правило: PATCH-запрос должен содержать ТОЛЬКО
#     те top-level ключи объекта задачи, которые реально нужно поменять —
#     НИКОГДА не весь объект целиком. Если отправить весь объект (как я
#     делал раньше, "как веб-форма"), сервер вернёт 403 с
#     {"code":"cannot-allow-huge-submissions","message":"You can't set this
#     field"} — потому что allowHugeSubmissions на некоторых задачах (там,
#     где тип ответа "Файл") сервер запрещает переустанавливать явно, даже
#     тем же значением, и это гасит PATCH целиком, даже если ты на самом деле
#     менял что-то совсем другое (например name). Поэтому все функции ниже
#     шлют PATCH только по нужному top-level ключу (или нескольким, если
#     меняется больше одного), а не весь объект из get_problem().


def get_problem(s, problem_id_enc):
    """GET /api/admin/problem/{id} — полный объект настроек задачи."""
    r = s.get(f"{BASE}/api/admin/problem/{problem_id_enc}")
    r.raise_for_status()
    return r.json()


def patch_problem(s, problem_id_enc, partial):
    """
    PATCH /api/admin/problem/{id} — partial должен содержать ТОЛЬКО те
    top-level ключи, которые реально надо поменять (см. комментарий выше).
    НЕ передавай сюда весь объект из get_problem() целиком.
    """
    r = s.patch(f"{BASE}/api/admin/problem/{problem_id_enc}", json=partial)
    if DEBUG:
        print(f"=== PATCH problem: status={r.status_code} keys={list(partial)} ===\n{r.text[:500]}")
    r.raise_for_status()


def patch_top_level_keys(s, problem_id_enc, data, *keys):
    """Удобный шорткат: взять текущие (уже изменённые в data) значения
    перечисленных top-level ключей и отправить PATCH только по ним."""
    patch_problem(s, problem_id_enc, {k: data[k] for k in keys})


def list_compilers(s, query=None):
    """
    GET /api/admin/compilers — общий (не привязанный к задаче) каталог всех
    компиляторов/окружений площадки. Возвращает только видимые и не
    deprecated, опционально отфильтрованные подстрокой по id/name/lang.
    """
    r = s.get(f"{BASE}/api/admin/compilers")
    r.raise_for_status()
    compilers = [c for c in r.json() if c.get("visible") and not c.get("deprecated")]
    if query:
        q = query.lower()
        compilers = [
            c for c in compilers
            if q in c["id"].lower() or q in c["name"].lower() or q in (c.get("lang") or "").lower()
        ]
    return compilers


def print_settings(s, problem_id_enc):
    data = get_problem(s, problem_id_enc)

    print("=== Общее ===")
    print(f"  Название:         {data.get('names')}")
    print(f"  Короткое имя:     {data.get('shortName')}")
    print(f"  Тип задачи:       {data.get('type')}")
    print(f"  Максимальный балл: {(data.get('metaInfo') or {}).get('maxScore')}")
    print(f"  Опубликована:     {data.get('isPublished')}")
    sv = data.get("sectionVisibility") or {}
    print(f"  Показывать в условии: примеры={sv.get('showSamples')} "
          f"ограничения={sv.get('showLimits')} настройки файлов={sv.get('showIo')}")

    det = data.get("details") or {}
    print("=== Поле ответа ===")
    print(f"  Тип: {det.get('answerType')}  Макс.длина: {det.get('maxLength')}  Паттерн: {det.get('pattern')}")

    fs = data.get("fileSettings") or {}
    print("=== Настройки файлов ===")
    print(f"  Входной файл: {fs.get('inputFileName')}  Выходной файл: {fs.get('outputFileName')}")
    print(f"  stdin={fs.get('allowReadStdin')} stdout={fs.get('allowWriteStdout')} "
          f"создание файлов={fs.get('allowFileCreation')} тип теста={fs.get('testFileType')}")
    print(f"  Ограничение размера исходника: {fs.get('maxSourceSize')} байт")
    print(f"  Разрешить большие посылки (allowHugeSubmissions): {data.get('allowHugeSubmissions')}")

    for label, key in (("Ограничения на запуск", "runtimeLimit"), ("Ограничения на компиляцию", "compileLimit")):
        common = (data.get(key) or {}).get("common") or {}
        print(f"=== {label} ===")
        print(f"  time={common.get('timeLimit')}мс idle={common.get('idlenessLimit')}мс "
              f"mem={common.get('memoryLimit')}б output={common.get('outputLimit')}б")

    cs = data.get("checkerSettings") or {}
    details = cs.get("details") or {}
    limits = cs.get("limits") or {}
    print("=== Чекер ===")
    print(f"  Тип:              {cs.get('type')}")
    print(f"  Выставляет баллы: {details.get('scoring')}")
    print(f"  Компилятор:       {details.get('compilerId')}")
    print(f"  Файлы чекера:     {details.get('checkerFiles')}")
    print(f"  Лимиты:           time={limits.get('timeLimitMillis')}мс "
          f"idle={limits.get('idlenessLimitMillis')}мс "
          f"mem={limits.get('memoryLimit')}б output={limits.get('outputLimit')}б")

    for label, key in (
        ("Файлы для компиляции", "compileLimit"),
        ("Файлы для времени запуска", "runtimeLimit"),
        ("Файлы постпроцессора", "postprocessorLimit"),
    ):
        block = data.get(key) or {}
        files = ((block.get("files") or {}).get("files")) or []
        common = block.get("common") or {}
        print(f"=== {label} ===")
        print(f"  Файлы:  {files}")
        if common:
            print(f"  Лимиты: time={common.get('timeLimit')}мс "
                  f"idle={common.get('idlenessLimit')}мс "
                  f"mem={common.get('memoryLimit')}б output={common.get('outputLimit')}б")

    pp = data.get("postProcessorSettings") or {}
    print("=== Окружение постпроцессора ===")
    print(f"  {pp.get('compilerId')}")

    print("=== Условия (языки) ===")
    for st in data.get("statements") or []:
        print(f"  {st.get('locale')}: format={st.get('format')}")
    if not data.get("statements"):
        print("  (нет ни одного условия — см. statement-add-locale)")


def compile_checker(s, problem_id_enc, source_path, compiler_id, checker_type="EJUDGE_EXITCODE_CHECKER", timeout=120):
    """
    Запускает компиляцию чекера из уже залитого source_path и ждёт результата
    поллингом. Возвращает финальный JSON статуса ({compileResult, filePath,
    stdout, stderr, finishTime}) или None при таймауте.
    """
    path_enc = source_path.replace("/", "%7C")
    r = s.post(f"{BASE}/api/admin/problem/{problem_id_enc}/checker/{path_enc}",
               params={"compilerId": compiler_id, "type": checker_type})
    if DEBUG:
        print(f"=== compile trigger: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()
    print(f"Компиляция запущена: {source_path} ({compiler_id}, {checker_type})")

    start = time.time()
    while time.time() - start < timeout:
        time.sleep(1.5)
        resp = s.get(f"{BASE}/api/admin/problem/{problem_id_enc}/checker")
        resp.raise_for_status()
        data = resp.json()
        result = data.get("compileResult")
        if result in (None, "IN_PROGRESS"):
            continue
        if result == "OK":
            print(f"OK: чекер скомпилирован -> {data.get('filePath')}")
        else:
            print(f"ОШИБКА КОМПИЛЯЦИИ ({result}):")
            if data.get("stdout"):
                print("--- stdout ---\n" + data["stdout"])
            if data.get("stderr"):
                print("--- stderr ---\n" + data["stderr"])
        return data

    print("Таймаут ожидания компиляции (проверь статус вручную командой settings).")
    return None


# Путь внутри JSON-объекта задачи для каждого управляемого списка файлов.
_FILE_LIST_PATHS = {
    "checker-files": ("checkerSettings", "details", "checkerFiles"),
    "compile-files": ("compileLimit", "files", "files"),
    "runtime-files": ("runtimeLimit", "files", "files"),
    "postproc-files": ("postprocessorLimit", "files", "files"),
}


def modify_file_list(s, problem_id_enc, list_key, action, path):
    keys = _FILE_LIST_PATHS[list_key]
    data = get_problem(s, problem_id_enc)

    node = data
    for k in keys[:-1]:
        if node.get(k) is None:
            node[k] = {}
        node = node[k]
    last = keys[-1]
    current = list(node.get(last) or [])

    if action == "add":
        if path in current:
            print(f"'{path}' уже есть в списке — ничего не делаю.")
            return
        current.append(path)
    elif action == "remove":
        if path not in current:
            print(f"'{path}' не найден в списке — нечего удалять.")
            return
        current.remove(path)
    else:
        raise ValueError(f"action должен быть add/remove, получено: {action!r}")

    node[last] = current
    patch_top_level_keys(s, problem_id_enc, data, keys[0])
    print(f"OK: {list_key} теперь = {current}")


def upload_and_register_file(s, problem_id_enc, list_key, local_path, target_path=None):
    """
    Аналог кнопки "Выбрать файл"/"Добавить файл" в вебе для compile-files/
    runtime-files/postproc-files/checker-files: реально заливает локальный
    файл в дерево задачи И регистрирует его путь в соответствующем списке —
    одной командой, вместо upload + add по отдельности (легко забыть первый
    шаг и получить в списке путь-призрак, который ничему не соответствует
    в дереве файлов).
    """
    target_path = target_path or os.path.basename(local_path)
    upload_one_file(s, problem_id_enc, local_path, target_path)
    modify_file_list(s, problem_id_enc, list_key, "add", target_path)


def check_file_list_refs(s, problem_id_enc, list_key):
    """
    Сверяет список путей (compile-files/runtime-files/postproc-files/
    checker-files) с реальным деревом файлов задачи и печатает, какие из
    них — файлы-призраки (числятся в списке, но отсутствуют в дереве —
    пайплайн упадёт, пытаясь их скопировать при сборке/запуске/обработке).
    """
    keys = _FILE_LIST_PATHS[list_key]
    data = get_problem(s, problem_id_enc)
    node = data
    for k in keys[:-1]:
        node = node.get(k) or {}
    referenced = list(node.get(keys[-1]) or [])

    tree = list_files(s, problem_id_enc)
    existing = {path for path, _size, _ctype in flatten_tree(tree)}

    missing = [p for p in referenced if p not in existing]
    ok = [p for p in referenced if p in existing]
    print(f"{list_key}: {len(referenced)} путей в списке, {len(ok)} реально существуют, {len(missing)} отсутствуют.")
    for p in ok:
        print(f"  OK      {p}")
    for p in missing:
        print(f"  ПРИЗРАК {p}  (нет в дереве файлов — пайплайн сломается на этом файле)")


def set_postproc_env(s, problem_id_enc, compiler_id):
    data = get_problem(s, problem_id_enc)
    if data.get("postProcessorSettings") is None:
        data["postProcessorSettings"] = {}
    value = None if compiler_id.lower() == "none" else compiler_id
    data["postProcessorSettings"]["compilerId"] = value
    patch_top_level_keys(s, problem_id_enc, data, "postProcessorSettings")
    print(f"OK: окружение постпроцессора = {value}")


# ------------------------- generic dotted-path get/set -----------------------
#
# Покрывает ЛЮБОЕ поле общего объекта задачи (кроме statements[] — у него
# свой набор команд ниже, т.к. это массив по языкам и находить нужный элемент
# надо по locale, а не по индексу). Путь — через точку, числовая часть пути
# трактуется как индекс массива. Значение при set парсится как JSON, если
# получится, иначе как обычная строка — так одной командой можно выставить
# и число, и bool, и строку, и целый под-объект/массив.


def _get_path(obj, path):
    cur = obj
    for part in path.split("."):
        key = int(part) if part.lstrip("-").isdigit() else part
        cur = cur[key]
    return cur


def _set_path(obj, path, value):
    parts = path.split(".")
    cur = obj
    for part in parts[:-1]:
        key = int(part) if part.lstrip("-").isdigit() else part
        cur = cur[key]
    last = parts[-1]
    key = int(last) if last.lstrip("-").isdigit() else last
    cur[key] = value


def _coerce_value(raw):
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return raw


def get_field(s, problem_id_enc, path):
    data = get_problem(s, problem_id_enc)
    try:
        value = _get_path(data, path)
    except (KeyError, IndexError, TypeError) as e:
        print(f"Не нашёл путь '{path}': {e}")
        return
    print(json.dumps(value, ensure_ascii=False, indent=2))


def set_field(s, problem_id_enc, path, raw_value):
    """
    ВАЖНО: PATCH шлётся только по top-level ключу пути (path.split('.')[0]),
    со значением ЭТОГО КЛЮЧА взятым из свежего GET (с применённой правкой)
    — не всем объектом целиком. Иначе сервер иногда отвечает 403 на
    полях, которые нельзя переустанавливать явно (например
    allowHugeSubmissions), даже если ты меняешь что-то совсем другое.
    """
    data = get_problem(s, problem_id_enc)
    value = _coerce_value(raw_value)
    try:
        _set_path(data, path, value)
    except (KeyError, IndexError, TypeError) as e:
        print(f"Не смог записать путь '{path}': {e}")
        return
    top_key = path.split(".")[0]
    patch_top_level_keys(s, problem_id_enc, data, top_key)
    print(f"OK: {path} = {json.dumps(value, ensure_ascii=False)}")


# ------------------------------- удобные обёртки ------------------------------


def set_name(s, problem_id_enc, name, locale="ru"):
    set_field(s, problem_id_enc, f"names.{locale}", json.dumps(name, ensure_ascii=False))
    # если locale=ru — также обновим верхнеуровневое "name" (то, что видно в списках)
    if locale == "ru":
        set_field(s, problem_id_enc, "name", json.dumps(name, ensure_ascii=False))


def set_checker_scoring(s, problem_id_enc, on):
    set_field(s, problem_id_enc, "checkerSettings.details.scoring", "true" if on else "false")


def set_max_score(s, problem_id_enc, score):
    set_field(s, problem_id_enc, "metaInfo.maxScore", str(int(score)))


_VISIBILITY_FIELDS = {"samples": "showSamples", "limits": "showLimits", "io": "showIo"}


def set_visibility(s, problem_id_enc, which, on):
    field = _VISIBILITY_FIELDS[which]
    set_field(s, problem_id_enc, f"sectionVisibility.{field}", "true" if on else "false")


# ------------------------------- наборы тестов (test sets) -------------------
#
# ВАЖНО: testSets.N.name/inputFilePattern/... через общий PATCH .../problem/{id}
# (см. set_field выше) сервер ТИХО игнорирует — возвращает 200/204, но значение
# не сохраняется и файлы не пересканируются. Реальный рабочий эндпоинт —
# отдельный PATCH .../problem/{id}/testset/{index}, ровно тот же, что дёргает
# кнопка "Обновить тесты" в вебе (страница /tests). Он и сохраняет паттерны,
# и пересканирует дерево файлов на совпадения. Обнаружено перехватом запроса
# в браузере 2026-07-24 — до этого testSets считался управляемым через generic
# get/set, но это оказалось не так.


def get_testset(s, problem_id_enc, index):
    """GET /api/admin/problem/{id}/testset/{index} — один набор тестов
    с уже сматченными файлами (поле tests[])."""
    r = s.get(f"{BASE}/api/admin/problem/{problem_id_enc}/testset/{index}")
    r.raise_for_status()
    return r.json()


def set_testset_patterns(s, problem_id_enc, index, input_pattern, output_pattern):
    """
    PATCH .../testset/{index} — сохраняет паттерны входного файла/файла
    правильного ответа И ЗАРАЗ пересканирует дерево файлов задачи на
    совпадения (это тот же вызов, что кнопка "Обновить тесты"). Паттерн —
    ТОЧНОЕ имя файла в дереве (не glob/wildcard), например "tests/public"
    должен совпадать 1-в-1 с реальным путём файла на вкладке "Файлы".
    """
    body = {"inputFilePattern": input_pattern, "outputFilePattern": output_pattern}
    r = s.patch(f"{BASE}/api/admin/problem/{problem_id_enc}/testset/{index}", json=body)
    if DEBUG:
        print(f"=== PATCH testset/{index}: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()
    data = get_testset(s, problem_id_enc, index)
    matched = data.get("tests") or []
    print(f"OK: testset/{index} паттерны = {input_pattern!r} / {output_pattern!r}")
    print(f"    testsMatched={data.get('testsMatched')}  найдено тестов: {len(matched)}")
    for t in matched:
        print(f"    {t}")


def print_testset(s, problem_id_enc, index):
    data = get_testset(s, problem_id_enc, index)
    print(json.dumps(data, ensure_ascii=False, indent=2))


def set_submission_limits(s, problem_id_enc, max_source_size=None, allow_huge=None):
    data = get_problem(s, problem_id_enc)
    keys = []
    if max_source_size is not None:
        data.setdefault("fileSettings", {})["maxSourceSize"] = int(max_source_size)
        keys.append("fileSettings")
    if allow_huge is not None:
        data["allowHugeSubmissions"] = allow_huge
        keys.append("allowHugeSubmissions")
    patch_top_level_keys(s, problem_id_enc, data, *keys)
    print(f"OK: maxSourceSize={data.get('fileSettings', {}).get('maxSourceSize')} "
          f"allowHugeSubmissions={data.get('allowHugeSubmissions')}")


# =============================== УСЛОВИЯ (statements) =========================
#
# statements — массив объектов {locale, path, format, details, renderingError}.
# details содержит секции условия как raw markdown-текст (при format=MARKDOWN):
# legend, inputFormat, outputFormat, interaction, scoring, notes. Правится тем
# же GET+PATCH общего объекта задачи, что и остальные настройки — сохранение
# в веб-форме идёт ровно через этот же endpoint (проверено перехватом запроса).

_STATEMENT_SECTIONS = {
    "legend": "legend",
    "input-format": "inputFormat",
    "output-format": "outputFormat",
    "interaction": "interaction",
    "scoring": "scoring",
    "notes": "notes",
}


def _find_statement(data, locale):
    for st in data.get("statements") or []:
        if st.get("locale") == locale:
            return st
    return None


def statement_list(s, problem_id_enc):
    data = get_problem(s, problem_id_enc)
    statements = data.get("statements") or []
    if not statements:
        print("Нет ни одного условия.")
        return
    for st in statements:
        d = st.get("details") or {}
        lens = {cli_name: len(d.get(json_key) or "") for cli_name, json_key in _STATEMENT_SECTIONS.items()}
        print(f"{st.get('locale')}: format={st.get('format')} path={st.get('path')}")
        print(f"  длины секций (симв.): {lens}")


def statement_add_locale(s, problem_id_enc, locale, fmt="MARKDOWN"):
    data = get_problem(s, problem_id_enc)
    if _find_statement(data, locale):
        print(f"Условие для '{locale}' уже есть — ничего не делаю.")
        return
    data.setdefault("statements", []).append({
        "locale": locale,
        "path": f"statements/.html/{locale}/full_page.html",
        "format": fmt,
        "details": {
            "type": fmt, "legend": "", "inputFormat": "", "outputFormat": "",
            "interaction": "", "scoring": "", "notes": "",
        },
        "renderingError": None,
    })
    patch_top_level_keys(s, problem_id_enc, data, "statements")
    print(f"OK: добавлено условие для языка '{locale}' ({fmt})")


def statement_get_section(s, problem_id_enc, locale, section, out_file=None):
    json_key = _STATEMENT_SECTIONS[section]
    data = get_problem(s, problem_id_enc)
    st = _find_statement(data, locale)
    if not st:
        print(f"Нет условия для языка '{locale}'.")
        return
    text = (st.get("details") or {}).get(json_key) or ""
    if out_file:
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"OK: {locale}/{section} ({len(text)} симв.) -> {out_file}")
    else:
        print(text)


def statement_set_section(s, problem_id_enc, locale, section, local_file):
    json_key = _STATEMENT_SECTIONS[section]
    with open(local_file, "r", encoding="utf-8") as f:
        text = f.read()
    data = get_problem(s, problem_id_enc)
    st = _find_statement(data, locale)
    if not st:
        print(f"Нет условия для языка '{locale}' — сначала statement-add-locale {locale}.")
        return
    st.setdefault("details", {})[json_key] = text
    patch_top_level_keys(s, problem_id_enc, data, "statements")
    print(f"OK: {locale}/{section} обновлён ({len(text)} симв.)")


def statement_set_all(s, problem_id_enc, locale, local_folder, fmt="MARKDOWN"):
    data = get_problem(s, problem_id_enc)
    st = _find_statement(data, locale)
    if not st:
        st = {
            "locale": locale,
            "path": f"statements/.html/{locale}/full_page.html",
            "format": fmt,
            "details": {"type": fmt, "legend": "", "inputFormat": "", "outputFormat": "",
                        "interaction": "", "scoring": "", "notes": ""},
            "renderingError": None,
        }
        data.setdefault("statements", []).append(st)

    updated = []
    for cli_name, json_key in _STATEMENT_SECTIONS.items():
        local_path = os.path.join(local_folder, f"{cli_name}.md")
        if os.path.exists(local_path):
            with open(local_path, "r", encoding="utf-8") as f:
                st.setdefault("details", {})[json_key] = f.read()
            updated.append(cli_name)

    if not updated:
        print(f"В {local_folder} не нашёл ни одного из файлов: "
              f"{', '.join(n + '.md' for n in _STATEMENT_SECTIONS)}")
        return

    patch_top_level_keys(s, problem_id_enc, data, "statements")
    print(f"OK: locale={locale}, обновлены секции: {', '.join(updated)}")


def upload_statement(s, problem_id_enc, local_file="statements/problem.md", locale="ru", section="legend", fmt="MARKDOWN"):
    """
    Удобная обёртка над statement_add_locale + statement_set_section с
    дефолтами под случай "один .md файл целиком = вся легенда".
    """
    if not os.path.exists(local_file):
        print(f"Не нашёл файл {local_file}")
        return
    if section not in _STATEMENT_SECTIONS:
        print(f"section должен быть одним из: {', '.join(_STATEMENT_SECTIONS)}")
        return

    data = get_problem(s, problem_id_enc)
    if not _find_statement(data, locale):
        statement_add_locale(s, problem_id_enc, locale, fmt)

    statement_set_section(s, problem_id_enc, locale, section, local_file)


# ================================ КОНТЕСТЫ ====================================
#
# В отличие от задач (у которых ID — это %2F-путь group/date/slug), контест
# адресуется простым числовым ID. Реверс-инжинирнуто перехватом запросов в
# браузере 2026-07-25 (создание контеста/задачи, клонирование, настройки
# контеста, список задач контеста, посылки).
#
# Важное отличие от задач: список задач контеста НЕ хранится в самом объекте
# контеста (GET /api/admin/contest/{id} не содержит поля problems) — он живёт
# в отдельном объекте "набор задач" (problem set), на который контест
# ссылается полем problemSetId ("123456/problemsets/2026_07_25/xxx/").
# Список задач правится ПОЛНОЙ ЗАМЕНОЙ массива problems через
# PATCH /api/admin/problemset/{problemSetId} — ровно так делает сама веб-форма
# (кнопка "Сохранить" на вкладке "Задачи" контеста шлёт весь желаемый список
# {id, title} целиком, а не один добавленный/удалённый элемент).


# Значения по умолчанию для НАШИХ контестов. Свежесозданный контест приходит с
# настройками площадки (ACM-монитор, сутки на соревнование, запрет повторных
# посылок) — они нам не подходят, и каждый раз это чинилось руками. Теперь
# create_contest применяет их сразу; отключается флагом --raw.
STANDARD_CONTEST_SETTINGS = {
    "duration": 31 * 24 * 60 * 60 * 1000,       # 31 день на соревнование
    "duplicateSubmissionsAllowed": True,        # одинаковый код слать можно
    "participationInterfaceType": "ODO",        # новый интерфейс участника
    "timeControlType": "USUAL",                 # фиксированный старт, не виртуальный
    "participationInterfaceSettings": {         # ODO без этого объекта не настраивается
        "eventTitle": None, "eventName": None, "eventDate": None,
        "eventThresholdScore": None, "greetings": None, "rules": None,
        "backgroundImage": None, "testContestId": None,
        "finalPageShowDates": None, "finalPageShowResult": None,
        "finalPageShowFeedback": None,
    },
    "monitorRequired": True,                    # "отключить генерацию монитора" — выкл
    "monitorPlugin": "SCORING",                 # ACM молча теряет частичные баллы
    "monitorSettings": {
        "ignoreCompilationErrors": True,
        "ignorePrecompileCheckErrors": True,
        "frozenSubmissionVisibility": "SHOW_NOTHING",
        "ignoreFailedSamples": True,
        "showEmptyRows": False,
        "submissionsFilter": "BEST_BY_SCORE",   # оценивается лучшая посылка
        "details": {
            "type": "SCORING",
            "acceptedCounterMode": "WITH_POINTS",
            "penaltySettings": {"enable": False, "penalty": 30, "policy": "SUM"},
        },
        "penaltySettings": {"enable": False, "penalty": 30, "policy": "SUM"},
    },
}


def apply_standard_contest_settings(s, contest_id):
    """Привести контест к нашим умолчаниям (см. STANDARD_CONTEST_SETTINGS).

    contestFinishTime считается здесь, а не лежит в словаре: он зависит от
    момента создания. При timeControlType=USUAL (фиксированный старт) площадка
    ждёт согласованную тройку start/duration/finish — иначе контест выглядит
    бесконечным, а на вкладке настроек пустует поле окончания.
    """
    patch = dict(STANDARD_CONTEST_SETTINGS)
    current = get_contest(s, contest_id)
    start = current.get("startTime")
    if start:
        patch["contestFinishTime"] = start + patch["duration"]
    patch_contest(s, contest_id, patch)
    print("OK: применены стандартные настройки — новый интерфейс (ODO), "
          "фиксированный старт, 31 день, повторные посылки разрешены, "
          "монитор SCORING по лучшей посылке, генерация монитора включена")


def create_contest(s, name, standard=True):
    """POST /api/admin/contest {"name": ...} — создаёт новый контест в текущей
    активной группе (группа не передаётся явно, сервер берёт её из сессии).
    Сразу приводит его к нашим умолчаниям, если не передано standard=False."""
    r = s.post(f"{BASE}/api/admin/contest", json={"name": name})
    if DEBUG:
        print(f"=== POST contest: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()
    data = r.json()
    print(f"OK: контест создан, id={data['id']}")
    print(f"    problemSetId={data.get('problemSetId')}")
    print(f"    https://admin.contest.yandex.ru/contests/{data['id']}/settings")
    if standard:
        apply_standard_contest_settings(
            session(referer_path=f"/contests/{data['id']}/settings"), data["id"])
    return data


def create_problem(s, name):
    """POST /api/admin/problem {"name": ...} — создаёт пустую задачу в банке
    задач текущей активной группы."""
    r = s.post(f"{BASE}/api/admin/problem", json={"name": name})
    if DEBUG:
        print(f"=== POST problem: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()
    data = r.json()
    pid = data["id"]
    pid_enc = pid.replace("/", "%2F")
    print(f"OK: задача создана, id={pid}")
    print(f"    https://admin.contest.yandex.ru/problems/{pid_enc}/settings")
    return data


def clone_problem(s, problem_id_enc):
    """POST /api/admin/problem/{id}/clone (без тела) — клонирует существующую
    задачу целиком (файлы, чекер, настройки, тесты) — то же, что кнопка
    «Клонировать задачу» в вебе; в имени копии появляется " [cloned]"."""
    r = s.post(f"{BASE}/api/admin/problem/{problem_id_enc}/clone")
    if DEBUG:
        print(f"=== POST clone: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()
    data = r.json()
    pid = data["id"]
    pid_enc = pid.replace("/", "%2F")
    print(f"OK: задача склонирована, новый id={pid}")
    print(f"    https://admin.contest.yandex.ru/problems/{pid_enc}/settings")
    return data


def get_contest(s, contest_id):
    """GET /api/admin/contest/{id} — полный объект настроек контеста
    (БЕЗ списка задач — см. get_problemset)."""
    r = s.get(f"{BASE}/api/admin/contest/{contest_id}")
    r.raise_for_status()
    return r.json()


def patch_contest(s, contest_id, partial):
    """PATCH /api/admin/contest/{id} — как и у задач, шли только те top-level
    ключи, которые реально меняются (не весь объект из get_contest())."""
    r = s.patch(f"{BASE}/api/admin/contest/{contest_id}", json=partial)
    if DEBUG:
        print(f"=== PATCH contest: status={r.status_code} keys={list(partial)} ===\n{r.text[:500]}")
    r.raise_for_status()


def patch_contest_top_level_keys(s, contest_id, data, *keys):
    patch_contest(s, contest_id, {k: data[k] for k in keys})


def print_contest_settings(s, contest_id):
    data = get_contest(s, contest_id)
    owner = data.get("owner") or {}
    print(f"=== Контест {contest_id}: {data.get('name')} ===")
    print(f"  Владелец:         {owner.get('name')} (id={owner.get('id')})")
    print(f"  problemSetId:     {data.get('problemSetId')}")
    print(f"  Права:            {data.get('permission')}")
    print(f"  Заблокирован:     {data.get('locked')}")
    print(f"  Тип времени:      {data.get('timeControlType')}")
    print(f"  Начало/длительность/конец: {data.get('startTime')} / {data.get('duration')} / {data.get('endTime')}")
    print(f"  Компиляторы:      {data.get('compilers')}")
    print(f"  Команды разрешены (teamsAllowed): {data.get('teamsAllowed')}")
    print(f"  Можно стартовать (startingAllowed): {data.get('startingAllowed')}")
    print(f"  Апсолвинг (upsolvingAllowed): {data.get('upsolvingAllowed')}")
    print(f"  Повторные посылки (duplicateSubmissionsAllowed): {data.get('duplicateSubmissionsAllowed')}")
    print(f"  Лимит размера исходника: {data.get('sourceSizeLimit')}")
    print(f"  Макс. посылок на задачу: {data.get('maxProblemSubmissionsCount')}")
    ms = data.get("monitorSettings") or {}
    print(f"  Монитор (monitorPlugin): {data.get('monitorPlugin')}; тип: {(ms.get('details') or {}).get('type')}; "
          f"в зачёт (submissionsFilter): {ms.get('submissionsFilter')}")
    print(f"  Видимость монитора: {data.get('monitorVisibility')}")
    print(f"  Видимость правильных ответов: {data.get('correctAnswerVisibility')}")
    print(f"  Типы авторизации: {data.get('allowedAuthorizationTypes')}")


def get_contest_field(s, contest_id, path):
    data = get_contest(s, contest_id)
    try:
        value = _get_path(data, path)
    except (KeyError, IndexError, TypeError) as e:
        print(f"Не нашёл путь '{path}': {e}")
        return
    print(json.dumps(value, ensure_ascii=False, indent=2))


def set_contest_field(s, contest_id, path, raw_value):
    """Аналог set_field, но для объекта контеста (PATCH /api/admin/contest/{id})."""
    data = get_contest(s, contest_id)
    value = _coerce_value(raw_value)
    try:
        _set_path(data, path, value)
    except (KeyError, IndexError, TypeError) as e:
        print(f"Не смог записать путь '{path}': {e}")
        return
    top_key = path.split(".")[0]
    patch_contest_top_level_keys(s, contest_id, data, top_key)
    print(f"OK: {path} = {json.dumps(value, ensure_ascii=False)}")


# ------------------------- список задач контеста (problem set) ---------------


def get_problemset(s, contest_id):
    """GET /api/admin/contests/{id}/problemset?fields=problems,id — список
    задач, привязанных к контесту (letter/title + сама задача), плюс id
    набора задач. Более простой путь чтения, чем через problemSetId контеста."""
    r = s.get(f"{BASE}/api/admin/contests/{contest_id}/problemset", params={"fields": "problems,id"})
    r.raise_for_status()
    return r.json()


def _patch_problemset_problems(s, contest_id, new_problems):
    """
    Общая часть add/remove: контест ссылается на набор задач через
    problemSetId ("123456/problemsets/2026_07_25/xxx/"), а сохраняется он
    ПОЛНОЙ ЗАМЕНОЙ массива problems через
    PATCH /api/admin/problemset/{problemSetId%2Fс%2Fслэшами}. Тело всегда
    включает contests=[{id,name}] и statements=[] — так шлёт сама веб-форма,
    даже если реально меняется только problems.
    """
    contest = get_contest(s, contest_id)
    problemset_id_enc = contest["problemSetId"].replace("/", "%2F")
    body = {
        "contests": [{"id": int(contest_id), "name": contest.get("name")}],
        "problems": new_problems,
        "statements": [],
    }
    r = s.patch(f"{BASE}/api/admin/problemset/{problemset_id_enc}", json=body)
    if DEBUG:
        print(f"=== PATCH problemset: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()


def print_contest_problems(s, contest_id):
    data = get_problemset(s, contest_id)
    problems = data.get("problems") or []
    print(f"Задач в контесте {contest_id}: {len(problems)}")
    for p in problems:
        print(f"  {p.get('title')}: {p.get('name')}  ({p['id']})")


def contest_add_problem(s, contest_id, problem_id_plain, letter=None):
    """
    Добавляет существующую задачу (ID в ПЛОСКОМ виде, см.
    resolve_problem_id_plain) в список задач контеста. letter — буква/алиас
    задачи в контесте (A/B/.../Z), по умолчанию — первая свободная по
    алфавиту. Идемпотентно: если задача уже привязана — ничего не делает.
    """
    current = (get_problemset(s, contest_id).get("problems")) or []
    if any(p["id"] == problem_id_plain for p in current):
        print(f"'{problem_id_plain}' уже привязана к контесту {contest_id} — ничего не делаю.")
        return
    if letter is None:
        used = {p.get("title") for p in current}
        letter = next((chr(ord("A") + i) for i in range(26) if chr(ord("A") + i) not in used), "A")
    new_problems = [{"id": p["id"], "title": p.get("title")} for p in current]
    new_problems.append({"id": problem_id_plain, "title": letter})
    _patch_problemset_problems(s, contest_id, new_problems)
    print(f"OK: '{problem_id_plain}' добавлена в контест {contest_id} под буквой {letter}")


def contest_remove_problem(s, contest_id, problem_id_plain):
    current = (get_problemset(s, contest_id).get("problems")) or []
    if not any(p["id"] == problem_id_plain for p in current):
        print(f"'{problem_id_plain}' не привязана к контесту {contest_id} — нечего удалять.")
        return
    new_problems = [{"id": p["id"], "title": p.get("title")} for p in current if p["id"] != problem_id_plain]
    _patch_problemset_problems(s, contest_id, new_problems)
    print(f"OK: '{problem_id_plain}' удалена из контеста {contest_id}")


# ------------------------------- посылки (submissions) ------------------------


def _build_submission_filters(problem_id_plain=None, participant_id=None, raw_filter=None):
    """
    Собирает query-параметры фильтра для GET .../submission — реверс-
    инжинирнутый синтаксис (перехват запросов в браузере 2026-07-25,
    фильтр-меню + инлайн-иконка фильтра по задаче в строке таблицы):

      0 условий  -> ?filter=                          (без фильтра, всё)
      1 условие  -> ?filter=field=value                (например problemId=123456/2026_07_25/xxx)
      2+ условия -> ?filter[]=field1=value1&filter[]=field2=value2  (И между полями)

    Внутри одного поля несколько значений (ИЛИ) разделяются "|" — например
    jobStatus=WAITING|RUNNING — но это не используется явно ниже, можно
    передать готовой строкой через raw_filter.

    Известные имена полей: problemId, participantId (в фильтр-меню есть ещё
    userId/login/groupId/groupName по аналогии, но не проверялись вживую).
    """
    parts = []
    if problem_id_plain:
        parts.append(f"problemId={problem_id_plain}")
    if participant_id:
        parts.append(f"participantId={participant_id}")
    if raw_filter:
        parts.append(raw_filter)
    if not parts:
        return [("filter", "")]
    if len(parts) == 1:
        return [("filter", parts[0])]
    return [("filter[]", p) for p in parts]


# Потолок серверной страницы. Площадка молча обрезает `limit` до 100: и 500, и
# 100000 возвращают ровно сто записей, без ошибки и без признака усечения.
# Поэтому больше сотни за раз не просим никогда, а собираем страницами.
SUBMISSION_PAGE = 100


def get_submissions(s, contest_id, problem_id_plain=None, participant_id=None,
                    raw_filter=None, limit=None, offset=0):
    """GET /api/admin/contest/{id}/submission?filter=... — список посылок
    контеста. Без аргументов фильтра — все посылки.

    Сортировка по убыванию id, сначала свежие. Аргументы `limit` и `offset`
    здесь — В ЗАПИСЯХ, как ожидает человек; в запрос они переводятся.

    Грабли площадки, из-за которых это переписано:

      * без `limit` отдаётся ровно 20 записей — а `total` при этом пишет
        настоящее число, так что «посылок всего двадцать» получается само собой;
      * `limit` больше 100 обрезается молча (см. SUBMISSION_PAGE);
      * **`offset` в запросе — НОМЕР СТРАНИЦЫ, а не смещение в записях.**
        Отдаются записи `[offset*limit, offset*limit + limit)`. Отсюда весь
        разнобой при отладке: `limit=50&offset=11` отдаёт 30 записей (это хвост
        580-й), а `limit=20&offset=30` — ноль, потому что страница 30 по 20
        начинается с 600-й записи, которой нет. Проверено на контесте с
        580 посылок, страницами по 100 и по 7 собираются в идентичные списки.
      * `total` НЕ учитывает фильтр: с `--problem` он всё равно показывает счёт
        по всему контесту. Останов идёт по короткой странице, не по `total`.

    limit=None — забрать все. Возвращает (JSON последней страницы, список items).
    """
    base = _build_submission_filters(problem_id_plain, participant_id, raw_filter)
    url = f"{BASE}/api/admin/contest/{contest_id}/submission"

    def fetch_page(index):
        """Страница №index размером SUBMISSION_PAGE (нумерация с нуля)."""
        r = s.get(url, params=base + [("limit", str(SUBMISSION_PAGE)),
                                      ("offset", str(index))])
        r.raise_for_status()
        data = r.json()
        return data, (data.get("items") or [])

    # Начинаем не с нуля, а со страницы, на которую попадает offset, —
    # лишние записи в её начале отрежем.
    first_page, skip = divmod(offset, SUBMISSION_PAGE)
    items, data, index = [], None, first_page
    while True:
        data, chunk = fetch_page(index)
        items += chunk
        index += 1
        if len(chunk) < SUBMISSION_PAGE:
            break
        if limit is not None and len(items) - skip >= limit:
            break

    items = items[skip:]
    if limit is not None:
        items = items[:limit]
    return data, items


def print_submissions(s, contest_id, problem_id_plain=None, participant_id=None,
                      raw_filter=None, limit=20, offset=0):
    data, items = get_submissions(s, contest_id, problem_id_plain, participant_id,
                                  raw_filter, limit, offset)
    total = data.get("total")
    filtered = bool(problem_id_plain or participant_id or raw_filter)
    where = f", начиная с {offset}" if offset else ""
    if filtered:
        # total у площадки считает весь контест и фильтр игнорирует, поэтому
        # выносим его отдельно, а не выдаём за число подходящих посылок.
        head = f"Показано посылок: {len(items)}{where} (total по контесту: {total}, фильтр в нём не учтён)"
        more = limit is not None
    else:
        head = f"Всего посылок: {total} (показано {len(items)}{where})"
        more = limit is not None and (total or 0) > len(items) + offset
    print(head + ("  (--limit all — забрать все)" if more else ""))
    for it in items:
        score = it.get("score") or {}
        sc = score.get("doubleScore") if score.get("scoreType") == "DOUBLE" else score.get("longScore")
        prob = it.get("problem") or {}
        part = it.get("participant") or {}
        print(f"  #{it.get('id')}  {prob.get('title')} {prob.get('name')}  "
              f"участник={part.get('participantName')} (id={part.get('id')})  "
              f"вердикт={it.get('verdict')}  балл={sc}  статус={it.get('status')}")


REJUDGE_CHUNK = 50


def rejudge_submissions(s, contest_id, submission_ids):
    """POST /api/admin/contest/{id}/submission/rejudge/multiple?runIds=... —
    отправить перечисленные посылки на перетестирование.

    Форма запроса снята с клиентского бандла админки: id едут в QUERY
    повторяющимся параметром `runIds`, тела нет, ответ `204`. Поле называется
    именно `runId` — ни `submissionId`, ни `ids` не работают.

    Рядом живёт `/submission/rejudge` (без `/multiple`) — массовый вариант по
    фильтру. Им сознательно не пользуемся: при неверной форме фильтра он
    отвечает `200 {"rejudgeId": N}` и молча не делает ничего, что невозможно
    отличить от успеха. `/multiple` отвечает честным `204`.

    Пересуждение нужно после любой правки файлов задачи: воркеры держат
    распакованные копии пакета и сами их не обновляют (docs/PLATFORM.md, грабли 11).
    """
    url = f"{BASE}/api/admin/contest/{contest_id}/submission/rejudge/multiple"
    ids = [str(i) for i in submission_ids]
    for start in range(0, len(ids), REJUDGE_CHUNK):
        chunk = ids[start:start + REJUDGE_CHUNK]
        r = s.post(url, params=[("runIds", i) for i in chunk])
        if r.status_code not in (200, 204):
            print(f"ОШИБКА: {r.status_code} {r.text[:300]}")
            r.raise_for_status()
        print(f"OK: отправлено на перетестирование {len(chunk)} шт. "
              f"({chunk[0]}…{chunk[-1]})" if len(chunk) > 1 else f"OK: отправлена {chunk[0]}")
    print("Проверять результат — по отметке времени проверки посылки: "
          "запрос принимается быстрее, чем посылка пересчитывается.")


def get_submission_stat(s, contest_id):
    """GET /api/admin/contest/{id}/submission/stat — сводная статистика по
    вердиктам/статусам всех посылок контеста."""
    r = s.get(f"{BASE}/api/admin/contest/{contest_id}/submission/stat")
    r.raise_for_status()
    return r.json()


def print_submission_stat(s, contest_id):
    data = get_submission_stat(s, contest_id)
    print(f"Всего посылок: {data.get('total')}   неверных: {data.get('incorrect')}")
    verdicts = data.get("verdictsStats") or {}
    statuses = data.get("statusStats") or {}
    if verdicts:
        print("По вердиктам:")
        for k, v in verdicts.items():
            print(f"  {k}: {v}")
    if statuses:
        print("По статусам:")
        for k, v in statuses.items():
            print(f"  {k}: {v}")


def get_submission(s, submission_id):
    """
    GET /api/admin/submission/{id} — полный отчёт по ОДНОЙ посылке. ВАЖНО:
    путь БЕЗ contest/{id}/ — эндпоинт адресуется голым числовым id посылки,
    contestId не нужен (он есть внутри ответа, submissionReport.contestId, —
    только для справки). Ключи ответа: submissionReport, compileLog,
    verdict, preliminaryScore, finalScore, tests, postProcessorMessage, ...
    submissionReport.sourceCode — исходный код НАПРЯМУЮ строкой (для
    текстовых решений). Для файловых/zip-ответов (fileSettings.answerType=
    FILE — как у нашей задачи) это поле, скорее всего, пусто — тогда нужен
    get_submission_source_file ниже.
    """
    r = s.get(f"{BASE}/api/admin/submission/{submission_id}")
    r.raise_for_status()
    return r.json()


def get_submission_source_file(s, submission_id):
    """
    GET /api/admin/submission/{id}/source-file — presigned-ссылка на РЕАЛЬНО
    загруженный файл посылки (оригинальное имя/content-type/размер),
    {"url":..., "contentType":..., "size":...}. Работает и для текстовых
    решений, и для файловых/zip-ответов — надёжнее, чем sourceCode, когда
    нужен именно исходный файл, а не пересобранный текст. Ссылка живёт
    недолго (~20 минут наблюдалось) — использовать сразу после получения,
    не кэшировать.
    """
    r = s.get(f"{BASE}/api/admin/submission/{submission_id}/source-file")
    r.raise_for_status()
    return r.json()


def print_submission(s, submission_id):
    data = get_submission(s, submission_id)
    rep = data.get("submissionReport") or {}
    print(f"=== Посылка #{submission_id} ===")
    print(f"  Контест:    {rep.get('contestName')} (id={rep.get('contestId')})")
    print(f"  Задача:     {rep.get('problemAlias')} {rep.get('problemName')}  ({rep.get('problemId')})")
    print(f"  Участник:   {rep.get('participantName')} (id={rep.get('participantId')})")
    print(f"  Компилятор: {rep.get('compilerName')} ({rep.get('compilerId')})")
    print(f"  Файл:       {rep.get('fileName')}  (sourceKind={rep.get('sourceKind')})")
    print(f"  Вердикт:    {data.get('verdict')}   Статус: {rep.get('status')}")
    print(f"  Балл:       предв.={data.get('preliminaryScore')}  итог.={data.get('finalScore')}")
    if data.get("compileLog"):
        print(f"  compileLog (первые 500 симв.):\n{data['compileLog'][:500]}")
    if rep.get("sourceCode"):
        print(f"  sourceCode (первые 500 симв., полностью — см. download-submission):"
              f"\n{rep['sourceCode'][:500]}")


def download_submission(s, submission_id, out_file=None):
    """
    Скачивает РЕАЛЬНЫЙ загруженный файл посылки (байты как есть — работает
    и для текстовых решений, и для zip/файловых ответов) через
    get_submission_source_file (presigned S3-ссылка). out_file — куда
    сохранить, по умолчанию — оригинальное имя файла из отчёта посылки.
    """
    rep = get_submission(s, submission_id).get("submissionReport") or {}
    info = get_submission_source_file(s, submission_id)
    url = info.get("url")
    if not url:
        print(f"Не нашёл presigned-ссылку в ответе /source-file: {info}")
        return None
    resp = requests.get(url, timeout=60)
    resp.raise_for_status()
    filename = out_file or rep.get("fileName") or f"submission_{submission_id}.bin"
    with open(filename, "wb") as f:
        f.write(resp.content)
    print(f"OK: посылка #{submission_id} -> {filename} "
          f"({len(resp.content)} б, тип={info.get('contentType')})")
    return filename


def submit_solution(s, contest_id, problem_id_plain, local_file, compiler_id):
    """
    POST /api/admin/contest/{id}/submission/submit — кнопка "Отправить
    решение" на странице посылок контеста. Заливка файла — тот же
    S3-механизм, что и у файлов задачи (upload-file -> S3 -> ссылка по s3Id).

    ВАЖНО (подтверждено реверс-инжинирингом, не догадка): в теле запроса НЕТ
    поля participantId/asUser — эта кнопка ВСЕГДА шлёт посылку от имени самого
    залогиненного админа как участника, а не "за другого человека". На
    практике (протестировано 2026-07-25) для владельца контеста (permission=
    OWNER) это работает даже на только что созданном контесте без явной
    регистрации участника — сервер, похоже, сам подставляет владельца как
    участника. Не проверено для НЕ-владельцев (участник/наблюдатель) — там
    отдельная регистрация ещё может понадобиться.
    """
    filename = os.path.basename(local_file)
    content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

    r = s.get(f"{BASE}/api/admin/upload-file", params={"contentType": content_type, "fileName": filename})
    if DEBUG:
        print(f"=== GET upload-file: status={r.status_code} ===\n{r.text[:500]}")
    r.raise_for_status()
    upload_url, fields, s3_id = parse_upload_target(r.json())

    with open(local_file, "rb") as f:
        put_resp = requests.post(upload_url, data=fields, files={"file": (filename, f, content_type)})
    if DEBUG:
        print(f"=== S3 upload: status={put_resp.status_code} ===\n{put_resp.text[:500]}")
    put_resp.raise_for_status()

    body = {"problemId": problem_id_plain, "compilerId": compiler_id, "fileName": filename, "s3Id": s3_id}
    resp = s.post(f"{BASE}/api/admin/contest/{contest_id}/submission/submit", json=body)
    if DEBUG:
        print(f"=== submit: status={resp.status_code} ===\n{resp.text[:500]}")
    resp.raise_for_status()
    sub = resp.json()
    print(f"OK: посылка отправлена, id={sub.get('id')}")
    print(f"    https://admin.contest.yandex.ru/contests/{contest_id}/submissions")
    return sub


# ============================== CLI ==========================================


_CONTEST_SETTINGS_CMDS = {"contest-settings", "contest-get", "contest-set"}
_CONTEST_PROBLEMSET_CMDS = {"contest-problems", "contest-add-problem", "contest-remove-problem"}
_CONTEST_SUBMISSION_CMDS = {"submissions", "submission-stat", "submit", "rejudge"}
_CONTEST_CMDS = _CONTEST_SETTINGS_CMDS | _CONTEST_PROBLEMSET_CMDS | _CONTEST_SUBMISSION_CMDS
_SUBMISSION_CMDS = {"submission-get", "submission-json", "download-submission"}


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]

    # ---- команды без ссылки на задачу/контест первым аргументом ----
    if cmd == "create-contest":
        if len(sys.argv) < 3:
            print("Нужно: create-contest <название> [--raw]")
            print("  по умолчанию сразу ставятся наши настройки: 31 день, повторные посылки")
            print("  разрешены, SCORING-монитор по лучшей посылке, генерация монитора включена;")
            print("  --raw — оставить настройки площадки как есть")
            sys.exit(1)
        s = session(referer_path="/contests")
        create_contest(s, sys.argv[2], standard="--raw" not in sys.argv)
        return

    if cmd == "contest-standard-settings":
        if len(sys.argv) < 3:
            print("Нужно: contest-standard-settings <contest_id>")
            print("  привести существующий контест к нашим умолчаниям")
            sys.exit(1)
        cid = sys.argv[2]
        apply_standard_contest_settings(session(referer_path=f"/contests/{cid}/settings"), cid)
        return

    if cmd == "create-problem":
        if len(sys.argv) < 3:
            print("Нужно: create-problem <название>")
            sys.exit(1)
        s = session(referer_path="/problems")
        create_problem(s, sys.argv[2])
        return

    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    target = sys.argv[2]
    args = sys.argv[3:]

    # ---- команды над КОНТЕСТОМ (числовой ID, отдельные эндпоинты) ----
    if cmd in _CONTEST_CMDS:
        contest_id = parse_contest_id(target)
        if cmd in _CONTEST_SUBMISSION_CMDS:
            referer_path = f"/contests/{contest_id}/submissions"
        elif cmd in _CONTEST_PROBLEMSET_CMDS:
            referer_path = f"/contests/{contest_id}/problemset"
        else:
            referer_path = f"/contests/{contest_id}/settings"
        s = session(referer_path=referer_path)

        if cmd == "contest-settings":
            print_contest_settings(s, contest_id)
        elif cmd == "contest-get":
            if not args:
                print("Нужно: contest-get <contest_ref> <путь.через.точку>")
                sys.exit(1)
            get_contest_field(s, contest_id, args[0])
        elif cmd == "contest-set":
            if len(args) < 2:
                print("Нужно: contest-set <contest_ref> <путь.через.точку> <значение>")
                sys.exit(1)
            set_contest_field(s, contest_id, args[0], args[1])
        elif cmd == "contest-problems":
            print_contest_problems(s, contest_id)
        elif cmd == "contest-add-problem":
            if not args:
                print("Нужно: contest-add-problem <contest_ref> <problem_ref> [letter]")
                sys.exit(1)
            problem_id_plain = resolve_problem_id_plain(args[0])
            letter = args[1] if len(args) > 1 else None
            contest_add_problem(s, contest_id, problem_id_plain, letter)
        elif cmd == "contest-remove-problem":
            if not args:
                print("Нужно: contest-remove-problem <contest_ref> <problem_ref>")
                sys.exit(1)
            problem_id_plain = resolve_problem_id_plain(args[0])
            contest_remove_problem(s, contest_id, problem_id_plain)
        elif cmd == "submissions":
            problem_ref, participant_id, raw_filter, limit, offset = None, None, None, 20, 0
            i = 0
            while i < len(args):
                if args[i] == "--problem" and i + 1 < len(args):
                    problem_ref = args[i + 1]; i += 2
                elif args[i] == "--participant" and i + 1 < len(args):
                    participant_id = args[i + 1]; i += 2
                elif args[i] == "--filter" and i + 1 < len(args):
                    raw_filter = args[i + 1]; i += 2
                elif args[i] == "--limit" and i + 1 < len(args):
                    # --limit all — забрать все страницы, а не первые 20
                    value = args[i + 1]
                    limit = None if value in ("all", "все") else int(value)
                    i += 2
                elif args[i] == "--offset" and i + 1 < len(args):
                    offset = int(args[i + 1]); i += 2
                elif args[i] == "--all":
                    limit = None; i += 1
                else:
                    i += 1
            problem_id_plain = resolve_problem_id_plain(problem_ref) if problem_ref else None
            print_submissions(s, contest_id, problem_id_plain, participant_id,
                              raw_filter, limit, offset)
        elif cmd == "rejudge":
            if not args:
                print("Нужно: rejudge <contest_ref> <id посылки> [<id> ...]")
                sys.exit(2)
            rejudge_submissions(s, contest_id, args)
        elif cmd == "submission-stat":
            print_submission_stat(s, contest_id)
        elif cmd == "submit":
            if len(args) < 3:
                print("Нужно: submit <contest_ref> <problem_ref> <local_file> <compiler_id>")
                sys.exit(1)
            problem_id_plain = resolve_problem_id_plain(args[0])
            local_file, compiler_id = args[1], args[2]
            submit_solution(s, contest_id, problem_id_plain, local_file, compiler_id)
        return

    # ---- команды над ОДНОЙ ПОСЫЛКОЙ (голый numeric id, без привязки к
    # контесту в пути — GET /api/admin/submission/{id}[/source-file]) ----
    if cmd in _SUBMISSION_CMDS:
        submission_id = parse_submission_id(target)
        s = session(referer_path=f"/submissions/{submission_id}")
        if cmd == "submission-get":
            print_submission(s, submission_id)
        elif cmd == "submission-json":
            print(json.dumps(get_submission(s, submission_id), ensure_ascii=False, indent=2))
        elif cmd == "download-submission":
            out_file = args[0] if args else None
            download_submission(s, submission_id, out_file)
        return

    # ---- остальное — старое поведение, всё про ОДНУ ЗАДАЧУ ----
    problem_url = target
    problem_id_enc = parse_problem_id(problem_url)

    # См. комментарий в session(): PATCH общих настроек задачи требует
    # Referer с той страницы, с которой это редактируется в вебе, иначе 403.
    _STATEMENT_CMDS = {"statement-list", "statement-add-locale", "statement-get",
                        "statement-set", "statement-set-all", "upload-statement"}
    _SETTINGS_CMDS = {"settings", "compilers", "checker-compile", "checker-files",
                       "compile-files", "runtime-files", "postproc-files", "postproc-env",
                       "get", "set", "set-name", "checker-scoring", "max-score",
                       "visibility", "submission-limits", "check-files", "clone-problem"}
    _TESTSET_CMDS = {"testset-get", "testset-set-pattern"}
    if cmd in _STATEMENT_CMDS:
        page = "statements"
    elif cmd in _TESTSET_CMDS:
        page = "tests"
    elif cmd in _SETTINGS_CMDS:
        page = "settings"
    else:
        page = "files"
    s = session(problem_id_enc, page=page)

    if cmd == "clone-problem":
        clone_problem(s, problem_id_enc)

    elif cmd == "upload":
        local_file, target_path = args
        upload_one_file(s, problem_id_enc, local_file, target_path)

    elif cmd == "upload-folder":
        local_folder = args[0]
        target_prefix = args[1] if len(args) > 1 else ""
        upload_folder(s, problem_id_enc, local_folder, target_prefix)

    elif cmd == "upload-zip-folder":
        local_folder, target_parent_path = args
        upload_zip_folder(s, problem_id_enc, local_folder, target_parent_path)

    elif cmd == "download":
        out_dir = args[0] if args else os.path.join(os.getcwd(), "downloaded_problem")
        download_all(s, problem_id_enc, out_dir)

    elif cmd == "list":
        tree = list_files(s, problem_id_enc)
        files = sorted(flatten_tree(tree))
        print(f"Файлов в дереве: {len(files)}")
        for path, size, ctype in files:
            print(f"  {path}  ({size}b, {ctype})")

    elif cmd == "delete":
        path_in_problem = args[0]
        delete_file(s, problem_id_enc, path_in_problem)

    elif cmd == "clear":
        confirm = "--yes" in args
        patterns = [a for a in args if a != "--yes"]
        clear_all(s, problem_id_enc, patterns=patterns, confirm=confirm)

    elif cmd == "settings":
        print_settings(s, problem_id_enc)

    elif cmd == "compilers":
        query = args[0] if args else None
        for c in list_compilers(s, query):
            print(f"{c['id']:28s} {c['name']:35s} [{c.get('lang')}]")

    elif cmd == "checker-compile":
        if len(args) < 2:
            print("Нужно: checker-compile <problem_url> <source_path> <compiler_id> [checker_type]")
            sys.exit(1)
        source_path = args[0]
        compiler_id = args[1]
        checker_type = args[2] if len(args) > 2 else "TESTLIB_EXITCODE_CHECKER"
        compile_checker(s, problem_id_enc, source_path, compiler_id, checker_type)

    elif cmd in ("checker-files", "compile-files", "runtime-files", "postproc-files"):
        if len(args) < 2:
            print(f"Нужно: {cmd} <problem_url> add|remove <path> | {cmd} <problem_url> upload <local_file> [target_path]")
            sys.exit(1)
        action = args[0]
        if action == "upload":
            local_path = args[1]
            target_path = args[2] if len(args) > 2 else None
            upload_and_register_file(s, problem_id_enc, cmd, local_path, target_path)
        else:
            path = args[1]
            modify_file_list(s, problem_id_enc, cmd, action, path)

    elif cmd == "check-files":
        if args:
            check_file_list_refs(s, problem_id_enc, args[0])
        else:
            for key in ("checker-files", "compile-files", "runtime-files", "postproc-files"):
                check_file_list_refs(s, problem_id_enc, key)
                print()

    elif cmd == "postproc-env":
        if not args:
            print("Нужно: postproc-env <problem_url> <compiler_id|none>")
            sys.exit(1)
        set_postproc_env(s, problem_id_enc, args[0])

    elif cmd == "testset-get":
        index = args[0] if args else "0"
        print_testset(s, problem_id_enc, index)

    elif cmd == "testset-set-pattern":
        if len(args) < 3:
            print("Нужно: testset-set-pattern <problem_url> <index> <input_pattern> <output_pattern>")
            sys.exit(1)
        index, input_pattern, output_pattern = args[0], args[1], args[2]
        set_testset_patterns(s, problem_id_enc, index, input_pattern, output_pattern)

    elif cmd == "get":
        if not args:
            print("Нужно: get <problem_url> <путь.через.точку>")
            sys.exit(1)
        get_field(s, problem_id_enc, args[0])

    elif cmd == "set":
        if len(args) < 2:
            print("Нужно: set <problem_url> <путь.через.точку> <значение>")
            sys.exit(1)
        set_field(s, problem_id_enc, args[0], args[1])

    elif cmd == "set-name":
        if not args:
            print("Нужно: set-name <problem_url> <название> [locale]")
            sys.exit(1)
        name = args[0]
        locale = args[1] if len(args) > 1 else "ru"
        set_name(s, problem_id_enc, name, locale)

    elif cmd == "checker-scoring":
        if not args or args[0] not in ("on", "off"):
            print("Нужно: checker-scoring <problem_url> on|off")
            sys.exit(1)
        set_checker_scoring(s, problem_id_enc, args[0] == "on")

    elif cmd == "max-score":
        if not args:
            print("Нужно: max-score <problem_url> <число>")
            sys.exit(1)
        set_max_score(s, problem_id_enc, args[0])

    elif cmd == "visibility":
        if len(args) < 2 or args[0] not in _VISIBILITY_FIELDS or args[1] not in ("on", "off"):
            print("Нужно: visibility <problem_url> samples|limits|io on|off")
            sys.exit(1)
        set_visibility(s, problem_id_enc, args[0], args[1] == "on")

    elif cmd == "submission-limits":
        max_source_size = None
        allow_huge = None
        i = 0
        while i < len(args):
            if args[i] == "--max-source-size" and i + 1 < len(args):
                max_source_size = args[i + 1]
                i += 2
            elif args[i] == "--allow-huge" and i + 1 < len(args):
                allow_huge = args[i + 1] == "on"
                i += 2
            else:
                i += 1
        if max_source_size is None and allow_huge is None:
            print("Нужно хотя бы один из флагов: --max-source-size <байт> / --allow-huge on|off")
            sys.exit(1)
        set_submission_limits(s, problem_id_enc, max_source_size, allow_huge)

    elif cmd == "statement-list":
        statement_list(s, problem_id_enc)

    elif cmd == "statement-add-locale":
        if not args:
            print("Нужно: statement-add-locale <problem_url> <locale> [format]")
            sys.exit(1)
        locale = args[0]
        fmt = args[1] if len(args) > 1 else "MARKDOWN"
        statement_add_locale(s, problem_id_enc, locale, fmt)

    elif cmd == "statement-get":
        if len(args) < 2:
            print("Нужно: statement-get <problem_url> <locale> <section> [out_file]")
            sys.exit(1)
        locale, section = args[0], args[1]
        if section not in _STATEMENT_SECTIONS:
            print(f"section должен быть одним из: {', '.join(_STATEMENT_SECTIONS)}")
            sys.exit(1)
        out_file = args[2] if len(args) > 2 else None
        statement_get_section(s, problem_id_enc, locale, section, out_file)

    elif cmd == "statement-set":
        if len(args) < 3:
            print("Нужно: statement-set <problem_url> <locale> <section> <local_file>")
            sys.exit(1)
        locale, section, local_file = args[0], args[1], args[2]
        if section not in _STATEMENT_SECTIONS:
            print(f"section должен быть одним из: {', '.join(_STATEMENT_SECTIONS)}")
            sys.exit(1)
        statement_set_section(s, problem_id_enc, locale, section, local_file)

    elif cmd == "statement-set-all":
        if len(args) < 2:
            print("Нужно: statement-set-all <problem_url> <locale> <local_folder>")
            sys.exit(1)
        locale, local_folder = args[0], args[1]
        statement_set_all(s, problem_id_enc, locale, local_folder)

    elif cmd == "upload-statement":
        local_file = args[0] if len(args) > 0 else "statements/problem.md"
        locale = args[1] if len(args) > 1 else "ru"
        section = args[2] if len(args) > 2 else "legend"
        upload_statement(s, problem_id_enc, local_file, locale, section)

    else:
        print(f"Неизвестная команда: {cmd}\n")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
