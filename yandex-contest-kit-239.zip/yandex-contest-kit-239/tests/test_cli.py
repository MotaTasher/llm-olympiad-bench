"""
Поведение точки входа: коды возврата, форма вывода, разбор ввода.

Сети нет — клиент подменяется. Проверяем контракт, на который завязан агент:
структурная ошибка в stderr, ненулевой код при мёртвой сессии.
"""

import json

import pytest

from contest_kit import auth, errors
from contest_kit.cli import main as cli

CURL = "curl 'x' -b 'Session_id=A; sessionid2=B; yandex_login=SomeUser'"

ALIVE = {"alive": True, "reason": None, "profile": "default", "source": "s",
         "login": "SomeUser", "has_csrf": True, "cookie_fingerprint": "abc123",
         "missing_cookies": [], "probe_status": 200}
DEAD = dict(ALIVE, alive=False, reason="площадка вернула страницу логина")


@pytest.fixture
def offline(tmp_path, monkeypatch):
    """Изолируем конфиг, лог и сеть."""
    monkeypatch.setattr(auth, "CONFIG_DIR", tmp_path / "config")
    monkeypatch.setattr(auth, "AUTH_FILE", tmp_path / "config" / "auth.json")
    monkeypatch.setattr(auth, "_cookie_from_browser", lambda: None)
    for var in (auth.ENV_COOKIE, auth.ENV_CSRF, auth.ENV_PROFILE):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("CONTEST_KIT_NO_LOG", "1")

    class FakeClient:
        instances = []
        status_value = ALIVE

        def __init__(self, creds):
            self.creds = creds
            FakeClient.instances.append(self)

        def refresh_csrf(self, referer="/problems"):
            return "csrf-token"

        def status(self):
            return dict(FakeClient.status_value)

    FakeClient.instances = []
    FakeClient.status_value = ALIVE
    monkeypatch.setattr(cli, "Client", FakeClient)
    return FakeClient


def test_login_from_curl_on_stdin(offline, monkeypatch, capsys):
    monkeypatch.setattr("sys.stdin", _Stdin(CURL))
    assert cli.main(["auth", "login"]) == 0
    out = capsys.readouterr().out
    assert "Сессия: жива" in out
    assert "SomeUser" in out


def test_login_saves_profile_with_csrf(offline, monkeypatch):
    monkeypatch.setattr("sys.stdin", _Stdin(CURL))
    cli.main(["auth", "login"])
    creds = auth.resolve()
    assert creds.cookie.startswith("Session_id=A")
    assert creds.csrf == "csrf-token"


def test_login_into_named_profile(offline, monkeypatch):
    monkeypatch.setattr("sys.stdin", _Stdin(CURL))
    cli.main(["--profile", "bot", "auth", "login"])
    assert auth.resolve("bot").cookie.startswith("Session_id=A")


def test_login_from_curl_file(offline, tmp_path):
    path = tmp_path / "copied.curl"
    path.write_text(CURL, encoding="utf-8")
    assert cli.main(["auth", "login", "--from-curl", str(path)]) == 0


def test_login_rejects_cookie_without_session_fields(offline, monkeypatch, capsys):
    """Частая ошибка: скопирован запрос не к той странице, куки сессии в нём нет.
    Сказать об этом надо до похода в сеть."""
    monkeypatch.setattr("sys.stdin", _Stdin("curl 'x' -b 'yandexuid=1'"))
    assert cli.main(["auth", "login"]) == 1
    err = capsys.readouterr().err
    assert "Session_id" in err
    assert "sessionid2" in err


def test_login_without_any_cookie_explains_what_to_copy(offline, monkeypatch, capsys):
    monkeypatch.setattr("sys.stdin", _Stdin("curl 'https://example.com'"))
    assert cli.main(["auth", "login"]) == 1
    assert "curl" in capsys.readouterr().err


def test_dead_session_exits_nonzero(offline, capsys):
    """Агент должен различать «проверил, всё хорошо» и «работать нельзя»
    по коду возврата, а не по тексту."""
    offline.status_value = DEAD
    auth.save_credentials(auth.Credentials(cookie="Session_id=A; sessionid2=B"))
    assert cli.main(["auth", "status"]) == 1
    out = capsys.readouterr().out
    assert "НЕ РАБОТАЕТ" in out
    assert "страницу логина" in out


def test_status_alive_exits_zero(offline):
    auth.save_credentials(auth.Credentials(cookie="Session_id=A; sessionid2=B"))
    assert cli.main(["auth", "status"]) == 0


def test_missing_credentials_is_structured_error(offline, capsys):
    assert cli.main(["--json", "auth", "status"]) == 1
    payload = json.loads(capsys.readouterr().err)["error"]
    assert payload["code"] == "AUTH_MISSING"
    assert payload["next_command"] == "contest auth login --browser"
    assert payload["hint"]


def test_json_output_is_parsable(offline):
    auth.save_credentials(auth.Credentials(cookie="Session_id=A; sessionid2=B"))
    assert cli.main(["--json", "auth", "status"]) == 0


def test_refresh_updates_stored_csrf(offline):
    auth.save_credentials(auth.Credentials(cookie="Session_id=A; sessionid2=B"))
    assert cli.main(["auth", "refresh"]) == 0
    assert auth.resolve().csrf == "csrf-token"


def test_cookie_and_from_curl_are_mutually_exclusive(offline):
    with pytest.raises(SystemExit) as e:
        cli.main(["auth", "login", "--cookie", "x", "--from-curl", "y"])
    assert e.value.code == 2


def test_group_is_required(offline):
    with pytest.raises(SystemExit) as e:
        cli.main([])
    assert e.value.code == 2


def test_errors_go_to_stderr_not_stdout(offline, capsys):
    cli.main(["auth", "status"])
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "AUTH_MISSING" in captured.err


class _Stdin:
    def __init__(self, text):
        self.text = text

    def read(self):
        return self.text

    def isatty(self):
        return False


# --- CSRF: откуда берётся и что будет, если не взялся ------------------------

CURL_WITH_CSRF = CURL + " -H 'x-csrf-token: from-curl'"


def test_login_takes_csrf_from_curl_without_asking_the_site(offline, monkeypatch):
    """В 'Copy as cURL' токен уже есть — лишний GET не нужен, и не важно,
    где площадка сегодня его держит на странице."""
    monkeypatch.setattr("sys.stdin", _Stdin(CURL_WITH_CSRF))
    called = []
    offline.refresh_csrf = lambda self, referer="/problems": called.append(1) or "fresh"
    assert cli.main(["auth", "login"]) == 0
    assert auth.resolve().csrf == "from-curl"
    assert called == []


def test_login_keeps_cookie_when_csrf_fetch_fails(offline, monkeypatch, capsys):
    """Кука сохраняется ДО похода за CSRF: раньше падение здесь теряло
    валидную куку, и auth status показывал старый отпечаток."""
    monkeypatch.setattr("sys.stdin", _Stdin(CURL))

    def boom(self, referer="/problems"):
        raise errors.make("CSRF_MISSING", "На странице нет secretkey")

    offline.refresh_csrf = boom
    assert cli.main(["auth", "login"]) == 1
    assert "CSRF_MISSING" in capsys.readouterr().err
    creds = auth.resolve()
    assert creds.cookie.startswith("Session_id=A")
    assert creds.csrf is None


def test_login_via_browser_saves_what_browser_returned(offline, monkeypatch):
    """--browser: куки и CSRF приходят из Playwright, через stdin ничего не идёт."""
    monkeypatch.setattr("sys.stdin", _Stdin(""))
    seen = {}

    def fake_browser_login(url, headless, notify):
        seen.update(url=url, headless=headless)
        return "Session_id=B1; sessionid2=B2; yandex_login=Teacher", "csrf-from-page"

    monkeypatch.setattr(auth, "browser_login", fake_browser_login)
    assert cli.main(["auth", "login", "--browser"]) == 0
    creds = auth.resolve()
    assert creds.cookie.startswith("Session_id=B1")
    assert creds.csrf == "csrf-from-page"
    assert creds.login == "Teacher"
    assert seen == {"url": auth.ADMIN_URL, "headless": False}


def test_browser_and_from_curl_are_mutually_exclusive(offline):
    with pytest.raises(SystemExit):
        cli.main(["auth", "login", "--browser", "--from-curl", "-"])
