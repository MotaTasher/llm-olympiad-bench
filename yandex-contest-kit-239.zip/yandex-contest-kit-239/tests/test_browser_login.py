"""
`contest auth login --browser` против локального сайта-заглушки: настоящий
Chrome через Playwright, но без сети и без Яндекса. Пропускается, если нет
playwright или браузера. Маркер `browser`: `pytest -m browser`.
"""

import http.server
import threading

import pytest

pw = pytest.importorskip("playwright.sync_api")

from contest_kit import auth  # noqa: E402

PAGE = (b'<html><head><title>Admin</title></head><body>'
        b'<script>window.__CONFIG__={"secretkey":"u-test-csrf"}</script>ok</body></html>')


class _FakeAdmin(http.server.BaseHTTPRequestHandler):
    """Первый же ответ ставит обязательные куки — как если бы человек уже вошёл."""

    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        for c in ("Session_id=SID", "sessionid2=SID2", "yandex_login=teacher"):
            self.send_header("Set-Cookie", c + "; Path=/")
        self.end_headers()
        self.wfile.write(PAGE)

    def log_message(self, *a):
        pass


@pytest.fixture
def fake_admin():
    srv = http.server.HTTPServer(("127.0.0.1", 0), _FakeAdmin)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_port}/problems"
    srv.shutdown()


@pytest.mark.browser
def test_browser_login_collects_cookies_and_csrf(fake_admin, tmp_path):
    try:
        cookie, csrf = auth.browser_login(
            url=fake_admin, profile_dir=tmp_path / "profile", timeout=60, headless=True,
        )
    except Exception as e:  # нет Chrome/Chromium на машине — не ошибка кода
        if "Executable doesn't exist" in str(e) or "browserType.launch" in str(e):
            pytest.skip(f"браузера нет: {e}")
        raise
    assert auth.Credentials(cookie=cookie).missing_cookies() == []
    assert auth.login_from_cookie(cookie) == "teacher"
    assert csrf == "u-test-csrf"
