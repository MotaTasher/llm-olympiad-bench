"""
Политика обращения с архивами.

Площадка разворачивает любой залитый архив и сам архив не сохраняет; распознаёт
по содержимому, а не по имени или Content-Type; распаковка не рекурсивная.
Отсюда всё поведение ниже.
"""

import os
import zipfile

import pytest

from contest_kit import archives, errors


@pytest.fixture
def zip_file(tmp_path):
    path = tmp_path / "kit.zip"
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("score.py", "x")
        z.writestr("tests/public", "y")
        z.writestr("tests/public.a", "z")
    return str(path)


@pytest.mark.parametrize("name,expected", [
    ("data.zip", True),
    ("DATA.ZIP", True),
    ("path/to/train_data.zip", True),
    ("dump.tar.gz", True),
    ("dump.tgz", True),
    ("dump.7z", True),
    ("score.py", False),
    ("archive.zip.txt", False),
    ("tests/public", False),
])
def test_is_archive(name, expected):
    """Список форматов широкий: сервер смотрит внутрь файла, поэтому .tar.gz
    разворачивается ровно так же, как .zip."""
    assert archives.is_archive(name) is expected


def test_plain_file_needs_no_intent():
    assert archives.decide("score.py") == archives.PLAIN


def test_archive_without_intent_is_refused():
    """Молча не угадываем: развернувшийся архив обратно не собрать."""
    with pytest.raises(errors.ContestError) as e:
        archives.decide("train_data.zip")
    assert e.value.code == "ARCHIVE_AMBIGUOUS"
    assert "unpack" in e.value.hint and "keep" in e.value.hint


@pytest.mark.parametrize("intent", [archives.UNPACK, archives.KEEP])
def test_archive_with_explicit_intent(intent):
    assert archives.decide("kit.zip", intent) == intent


def test_unknown_intent_is_rejected():
    with pytest.raises(errors.ContestError) as e:
        archives.decide("kit.zip", "maybe")
    assert e.value.code == "BAD_REF"


def test_members_lists_files_without_directories(zip_file):
    assert archives.members(zip_file) == ["score.py", "tests/public", "tests/public.a"]


def test_expected_paths_land_next_to_the_archive(zip_file):
    assert archives.expected_after_unpack(zip_file, "kit.zip") == [
        "score.py", "tests/public", "tests/public.a",
    ]
    assert archives.expected_after_unpack(zip_file, "upload/kit.zip") == [
        "upload/score.py", "upload/tests/public", "upload/tests/public.a",
    ]


# --- сохранение архива через внешний архив ---------------------------------


def test_wrap_puts_file_under_target_name(tmp_path, zip_file):
    """Имя внешнего архива не важно — важно имя файла внутри него: именно оно
    станет именем в дереве после распаковки."""
    work = tmp_path / "work"
    work.mkdir()
    outer = archives.wrap_to_survive(zip_file, "statements/data/train.zip", str(work))
    assert archives.members(outer) == ["train.zip"]


def test_wrap_survives_because_unpacking_is_not_recursive(tmp_path, zip_file):
    """Внешний архив развернётся, внутренний останется файлом — на этом и
    держится способ залить архив целым."""
    work = tmp_path / "work"
    work.mkdir()
    outer = archives.wrap_to_survive(zip_file, "statements/data.zip", str(work))
    landed = archives.expected_after_unpack(outer, archives.outer_target_for("statements/data.zip"))
    assert landed == ["statements/data.zip"]


def test_wrap_does_not_recompress(tmp_path, zip_file):
    work = tmp_path / "work"
    work.mkdir()
    outer = archives.wrap_to_survive(zip_file, "data.zip", str(work))
    with zipfile.ZipFile(outer) as z:
        assert z.infolist()[0].compress_type == zipfile.ZIP_STORED


@pytest.mark.parametrize("target,expected", [
    ("statements/data/train.zip", "statements/data/outer.zip"),
    ("data.zip", "outer.zip"),
])
def test_outer_target_stays_in_the_same_folder(target, expected):
    assert archives.outer_target_for(target) == expected


# --- сборка архива из списка файлов ----------------------------------------


def test_pack_files_takes_only_listed_files(tmp_path):
    """Собираем из отобранного списка, а не из папки: иначе .DS_Store и
    __pycache__ развернутся прямо в дерево задачи."""
    from contest_kit import tree as tree_mod

    (tmp_path / "kit").mkdir()
    (tmp_path / "kit" / "score.py").write_text("x")
    (tmp_path / "kit" / ".DS_Store").write_text("junk")
    files = tree_mod.scan_local(tmp_path / "kit")
    out = archives.pack_files(files, str(tmp_path / "payload.zip"))
    assert archives.members(out) == ["score.py"]


def test_pack_files_strips_prefix(tmp_path):
    from contest_kit import tree as tree_mod

    (tmp_path / "kit").mkdir()
    (tmp_path / "kit" / "score.py").write_text("x")
    files = tree_mod.scan_local(tmp_path / "kit", prefix="upload")
    out = archives.pack_files(files, str(tmp_path / "p.zip"), strip=len("upload") + 1)
    assert archives.members(out) == ["score.py"]


# --- сверка результата -----------------------------------------------------


def test_verify_unpack_success(zip_file):
    expected = archives.expected_after_unpack(zip_file, "kit.zip")
    report = archives.verify(archives.UNPACK, "kit.zip", expected, expected)
    assert report["ok"] and report["unpacked"]
    assert report["missing"] == []


def test_verify_unpack_detects_nothing_happened(zip_file):
    expected = archives.expected_after_unpack(zip_file, "kit.zip")
    report = archives.verify(archives.UNPACK, "kit.zip", expected, ["kit.zip"])
    assert not report["ok"]
    assert not report["unpacked"]
    assert report["target_present"]


def test_verify_unpack_detects_partial(zip_file):
    expected = archives.expected_after_unpack(zip_file, "kit.zip")
    report = archives.verify(archives.UNPACK, "kit.zip", expected, expected[:1])
    assert not report["ok"]
    assert report["unpacked"]
    assert report["missing"] == expected[1:]


def test_verify_keep_success():
    report = archives.verify(archives.KEEP, "statements/data.zip", ["statements/data.zip"],
                             ["statements/data.zip", "legend.md"])
    assert report["ok"]
    assert not report["unpacked"]


def test_verify_keep_detects_unwanted_unpacking():
    """Вложение к условию развернулось — ссылка в тексте условия сломана."""
    report = archives.verify(archives.KEEP, "statements/data.zip", ["statements/data.zip"],
                             ["statements/train.csv", "statements/test.csv"])
    assert not report["ok"]
    assert report["unpacked"]
    assert report["missing"] == ["statements/data.zip"]
