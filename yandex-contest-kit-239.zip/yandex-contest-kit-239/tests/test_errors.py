import pytest

from contest_kit import errors


def test_make_pulls_hint_from_registry():
    e = errors.make("SESSION_EXPIRED", "кука протухла")
    assert e.hint and "логина" in e.hint
    assert e.next_command == "contest auth login --browser"


def test_make_allows_overriding_next_command():
    e = errors.make("GHOST_FILE", "нет файла", next_command="contest files upload x")
    assert e.next_command == "contest files upload x"


def test_known_codes_have_actionable_hints():
    """Каждый код, кроме сырого HTTP_ERROR, обязан объяснять причину: агент
    чинится по hint, а не по тексту сообщения."""
    for code, (hint, _next) in errors.HINTS.items():
        if code == "HTTP_ERROR":
            continue
        assert hint, f"у {code} нет подсказки"


def test_to_dict_is_machine_readable():
    e = errors.make("RESOURCE_LOCKED", "423", attempts=5)
    d = e.to_dict()["error"]
    assert d["code"] == "RESOURCE_LOCKED"
    assert d["message"] == "423"
    assert d["details"]["attempts"] == 5
    assert "hint" in d


def test_to_dict_omits_empty_fields():
    e = errors.ContestError(code="X", message="m")
    assert e.to_dict() == {"error": {"code": "X", "message": "m"}}


def test_render_is_multiline_and_starts_with_code():
    e = errors.make("SESSION_EXPIRED", "кука протухла")
    lines = e.render().splitlines()
    assert lines[0].startswith("[SESSION_EXPIRED]")
    assert any("дальше" in line for line in lines)


def test_specific_codes_get_catchable_classes():
    """Ретрай и ранний выход завязаны на тип, а не на строку кода."""
    assert isinstance(errors.make("RESOURCE_LOCKED", "x"), errors.ResourceLocked)
    assert isinstance(errors.make("SESSION_EXPIRED", "x"), errors.SessionExpired)
    assert isinstance(errors.make("NOT_FOUND", "x"), errors.ContestError)


def test_errors_are_raisable():
    with pytest.raises(errors.ContestError):
        raise errors.make("NOT_FOUND", "нет такой задачи")
