import json
import os
import stat

import pytest

from contest_kit import auth, errors

CURL = """
curl 'https://admin.contest.yandex.ru/api/admin/upload-file?contentType=text%2Fplain' \\
  -H 'accept: application/json, text/plain, */*' \\
  -b 'yandexuid=336; Session_id=3:1700000000.1.0:AAAA; sessionid2=3:1700000000.1.0:BBBB; yandex_login=SomeUser' \\
  -H 'referer: https://admin.contest.yandex.ru/problems/123456%2F2026_07_22%2FxY9zW8vU7t/files' \\
  -H 'user-agent: Mozilla/5.0'
"""


def test_cookie_from_curl_b_flag():
    cookie = auth.cookie_from_curl(CURL)
    assert "Session_id=3:1700000000.1.0:AAAA" in cookie
    assert "yandex_login=SomeUser" in cookie


@pytest.mark.parametrize("blob", [
    "curl 'x' --cookie 'Session_id=A; sessionid2=B'",
    'curl "x" -H "Cookie: Session_id=A; sessionid2=B"',
    "curl 'x' -H 'cookie: Session_id=A; sessionid2=B'",
])
def test_cookie_from_curl_other_forms(blob):
    assert auth.cookie_from_curl(blob) == "Session_id=A; sessionid2=B"


def test_cookie_from_curl_absent():
    assert auth.cookie_from_curl("curl 'https://example.com'") is None


def test_login_from_cookie():
    assert auth.login_from_cookie("a=1; yandex_login=SomeUser; b=2") == "SomeUser"
    assert auth.login_from_cookie("a=1") is None


@pytest.mark.parametrize("html", [
    '<meta name="secretkey" content="uf65ec4223679">',
    "<meta name='secretkey' content='uf65ec4223679'>",
    '<meta content="uf65ec4223679" name="secretkey">',
    '<head><meta charset="utf-8"><meta name="secretkey" content="uf65ec4223679"></head>',
])
def test_csrf_from_html(html):
    """CSRF отдельной ручкой не отдаётся, только этим тегом — разметка у
    площадки может поменяться, поэтому терпим оба порядка атрибутов."""
    assert auth.csrf_from_html(html) == "uf65ec4223679"


def test_csrf_from_html_absent():
    assert auth.csrf_from_html("<html><head></head></html>") is None


def test_missing_cookies_detected():
    creds = auth.Credentials(cookie="yandexuid=1; yandex_login=X")
    assert creds.missing_cookies() == ["Session_id", "sessionid2"]
    full = auth.Credentials(cookie="Session_id=A; sessionid2=B")
    assert full.missing_cookies() == []


def test_redact_hides_values_but_keeps_names():
    """Редактирование обязано пережить любой путь в лог: имена кук полезны для
    диагностики, значения не должны утечь никогда."""
    text = "Cookie: Session_id=3:1700000000.1.0:AAAA; sessionid2=3:BBBB; other=keepme"
    out = auth.redact(text)
    assert "3:1700000000.1.0:AAAA" not in out
    assert "3:BBBB" not in out
    assert "Session_id=<" in out
    assert "other=keepme" in out


def test_redact_does_not_eat_similar_names():
    assert "my_login=vasya" in auth.redact("my_login=vasya")


def test_cookie_fingerprint_is_stable_and_short():
    fp = auth.cookie_fingerprint("Session_id=A")
    assert fp == auth.cookie_fingerprint("Session_id=A")
    assert fp != auth.cookie_fingerprint("Session_id=B")
    assert len(fp) == 12


# --- разрешение учётных данных --------------------------------------------


@pytest.fixture
def isolated_config(tmp_path, monkeypatch):
    monkeypatch.setattr(auth, "CONFIG_DIR", tmp_path / "config")
    monkeypatch.setattr(auth, "AUTH_FILE", tmp_path / "config" / "auth.json")
    for var in (auth.ENV_COOKIE, auth.ENV_CSRF, auth.ENV_PROFILE):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setattr(auth, "_cookie_from_browser", lambda: None)
    return tmp_path


def test_resolve_prefers_env(isolated_config, monkeypatch):
    monkeypatch.setenv(auth.ENV_COOKIE, "Session_id=ENV; yandex_login=EnvUser")
    monkeypatch.setenv(auth.ENV_CSRF, "tok")
    creds = auth.resolve()
    assert creds.cookie.startswith("Session_id=ENV")
    assert creds.csrf == "tok"
    assert creds.login == "EnvUser"
    assert creds.source == f"${auth.ENV_COOKIE}"


def test_resolve_falls_back_to_config(isolated_config):
    auth.save_credentials(auth.Credentials(cookie="Session_id=FILE", csrf="t", profile="admin"))
    creds = auth.resolve()
    assert creds.cookie == "Session_id=FILE"
    assert creds.profile == "admin"


def test_resolve_named_profile(isolated_config):
    auth.save_credentials(auth.Credentials(cookie="Session_id=A", profile="admin"))
    auth.save_credentials(auth.Credentials(cookie="Session_id=B", profile="bot"))
    assert auth.resolve("bot").cookie == "Session_id=B"
    assert auth.resolve().cookie == "Session_id=A"  # default_profile не перетирается


def test_resolve_raises_with_hint_when_nothing_found(isolated_config):
    with pytest.raises(errors.ContestError) as e:
        auth.resolve()
    assert e.value.code == "AUTH_MISSING"
    assert e.value.next_command  # агенту сразу видно, чем чиниться


def test_saved_auth_file_is_not_world_readable(isolated_config):
    path = auth.save_credentials(auth.Credentials(cookie="Session_id=A", profile="admin"))
    mode = stat.S_IMODE(os.stat(path).st_mode)
    assert mode == 0o600
    assert stat.S_IMODE(os.stat(auth.CONFIG_DIR).st_mode) == 0o700


def test_saved_auth_file_is_valid_json(isolated_config):
    auth.save_credentials(auth.Credentials(cookie="Session_id=A", profile="admin"))
    with auth.AUTH_FILE.open(encoding="utf-8") as f:
        cfg = json.load(f)
    assert cfg["profiles"]["admin"]["cookie"] == "Session_id=A"


def test_csrf_from_html_page_config_json():
    """С 31.07.2026 тега <meta> нет: токен лежит в JSON конфигурации страницы.
    На этом однажды протухла запись (все POST/PATCH в 403 при живых GET)."""
    html = '<script>window.__CONFIG__={"user":{"login":"x"},"secretkey":"u3ef21afb95cc","lang":"ru"}</script>'
    assert auth.csrf_from_html(html) == "u3ef21afb95cc"


def test_csrf_from_html_prefers_meta_over_json():
    html = '<meta name="secretkey" content="from-meta"><script>{"secretkey":"from-json"}</script>'
    assert auth.csrf_from_html(html) == "from-meta"


@pytest.mark.parametrize("curl", [
    "curl 'x' -H 'x-csrf-token: u3ef21afb95cc' -b 'Session_id=A'",
    'curl "x" -H "X-CSRF-Token: u3ef21afb95cc" -b "Session_id=A"',
    "curl 'x' \\\n  -H 'accept: */*' \\\n  -H 'x-csrf-token: u3ef21afb95cc' \\\n  -b 'Session_id=A'",
])
def test_csrf_from_curl(curl):
    assert auth.csrf_from_curl(curl) == "u3ef21afb95cc"


def test_csrf_from_curl_absent():
    assert auth.csrf_from_curl("curl 'x' -b 'Session_id=A'") is None
