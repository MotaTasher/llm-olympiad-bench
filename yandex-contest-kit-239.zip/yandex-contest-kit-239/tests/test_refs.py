import pytest

from contest_kit import errors, refs

ENC = "123456%2F2026_07_24%2FaB1cD2eF3g"
PLAIN = "123456/2026_07_24/aB1cD2eF3g"


@pytest.mark.parametrize("ref", [
    f"https://admin.contest.yandex.ru/problems/{ENC}/settings",
    f"https://admin.contest.yandex.ru/problems/{ENC}/files",
    f"https://admin.contest.yandex.ru/problems/{ENC}/statements",
    f"https://admin.contest.yandex.ru/problems/{ENC}/",
    f"https://admin.contest.yandex.ru/problems/{ENC}",
    f"https://admin.contest.yandex.ru/problems/{ENC}/settings?tab=1",
])
def test_problem_id_from_any_page(ref):
    """Любая страница задачи — ID достаётся одинаково. Ссылка без хвоста и с
    query тоже: в истории вызовов обе формы встречаются и обе ломались."""
    assert refs.problem_id_encoded(ref) == ENC
    assert refs.problem_id_plain(ref) == PLAIN


@pytest.mark.parametrize("ref", [ENC, PLAIN, f"  {PLAIN} "])
def test_problem_id_from_bare_id(ref):
    assert refs.problem_id_plain(ref) == PLAIN


def test_problem_id_encoded_is_idempotent():
    assert refs.problem_id_encoded(refs.problem_id_encoded(ENC)) == ENC


def test_lowercase_percent_encoding():
    assert refs.problem_id_plain("123456%2f2026_07_24%2faB1cD2eF3g") == PLAIN


def test_problem_id_bad_ref():
    with pytest.raises(errors.ContestError) as e:
        refs.parse_problem_id("https://admin.contest.yandex.ru/contests/10000/settings")
    assert e.value.code == "BAD_REF"


@pytest.mark.parametrize("ref,expected", [
    ("10000", "10000"),
    ("  10000 ", "10000"),
    ("https://admin.contest.yandex.ru/contests/10000/settings", "10000"),
    ("https://admin.contest.yandex.ru/contests/10000/submissions", "10000"),
    ("https://admin.contest.yandex.ru/contest/10000", "10000"),
])
def test_contest_id(ref, expected):
    assert refs.parse_contest_id(ref) == expected


def test_contest_id_bad_ref():
    with pytest.raises(errors.ContestError) as e:
        refs.parse_contest_id("не ссылка")
    assert e.value.code == "BAD_REF"


@pytest.mark.parametrize("ref,expected", [
    ("200000002", "200000002"),
    ("https://admin.contest.yandex.ru/submissions/200000002", "200000002"),
])
def test_submission_id(ref, expected):
    assert refs.parse_submission_id(ref) == expected


def test_file_path_encoding_uses_pipe():
    """Путь файла внутри задачи кодируется через %7C, а не %2F — перепутать
    эти две кодировки легко, а диагностика у площадки нулевая."""
    assert refs.encode_file_path("tests/public.a") == "tests%7Cpublic.a"
    assert refs.encode_file_path("checkers/checker.cpp") == "checkers%7Cchecker.cpp"
    assert refs.encode_file_path("score.py") == "score.py"


def test_urls_built_from_any_form():
    assert refs.problem_url(PLAIN, "files").endswith(f"/problems/{ENC}/files")
    assert refs.contest_url("10000").endswith("/contests/10000/settings")
