import pytest

from contest_kit import errors, jsonpath

PROBLEM = {
    "name": "Пример задачи",
    "shortName": "sample-problem",
    "metaInfo": {"maxScore": 100},
    "sectionVisibility": {"showSamples": True, "showLimits": False},
    "checkerSettings": {"details": {"scoring": True}},
    "statements": [
        {"locale": "ru", "details": {"legend": "текст"}},
        {"locale": "en", "details": {"legend": "text"}},
    ],
    "testSets": [{"inputPattern": "tests/public"}],
}


@pytest.mark.parametrize("path,expected", [
    ("name", "Пример задачи"),
    ("metaInfo.maxScore", 100),
    ("sectionVisibility.showSamples", True),
    ("checkerSettings.details.scoring", True),
    ("statements.1.locale", "en"),
    ("statements.0.details.legend", "текст"),
    ("testSets.0.inputPattern", "tests/public"),
])
def test_get_path(path, expected):
    assert jsonpath.get_path(PROBLEM, path) == expected


def test_get_path_missing_reports_where_it_broke():
    """Ошибка должна говорить, на каком сегменте оборвалось и что там было —
    иначе агент чинится перебором."""
    with pytest.raises(errors.ContestError) as e:
        jsonpath.get_path(PROBLEM, "metaInfo.maxscore")
    assert e.value.code == "BAD_REF"
    assert "maxscore" in e.value.message
    assert "maxScore" in e.value.details["available"]


def test_get_path_index_out_of_range():
    with pytest.raises(errors.ContestError) as e:
        jsonpath.get_path(PROBLEM, "statements.9.locale")
    assert "9" in e.value.message


def test_set_path_nested():
    obj = {"metaInfo": {"maxScore": 100}}
    jsonpath.set_path(obj, "metaInfo.maxScore", 50)
    assert obj["metaInfo"]["maxScore"] == 50


def test_set_path_in_array():
    obj = {"statements": [{"details": {"legend": "a"}}]}
    jsonpath.set_path(obj, "statements.0.details.legend", "b")
    assert obj["statements"][0]["details"]["legend"] == "b"


def test_set_path_top_level():
    obj = {"name": "x"}
    jsonpath.set_path(obj, "name", "y")
    assert obj["name"] == "y"


@pytest.mark.parametrize("raw,expected", [
    ("100", 100),
    ("true", True),
    ("false", False),
    ("null", None),
    ('"chess"', "chess"),
    ("[1, 2]", [1, 2]),
    ('{"a": 1}', {"a": 1}),
    ("sample-problem", "sample-problem"),
    ("Пример задачи", "Пример задачи"),
    ("2026_07_24", "2026_07_24"),
])
def test_coerce_value(raw, expected):
    assert jsonpath.coerce_value(raw) == expected


def test_top_level_key():
    """PATCH шлётся по верхнему ключу — от этого зависит, не словим ли мы 403
    на соседнем непатчабельном поле."""
    assert jsonpath.top_level_key("checkerSettings.details.scoring") == "checkerSettings"
    assert jsonpath.top_level_key("name") == "name"
