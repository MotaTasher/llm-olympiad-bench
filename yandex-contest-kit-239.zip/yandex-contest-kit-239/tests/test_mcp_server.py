"""
MCP-сервер: то, что он обязан держать сам, независимо от CLI под ним.

Сети нет — `_run` подменяется. Отдельно один тест поднимает сервер по stdio
настоящим клиентом: проверяет, что инструменты и ресурсы объявляются.
"""

import asyncio
import subprocess
import sys

import pytest

pytest.importorskip("mcp")

from contest_kit import mcp_server as m  # noqa: E402


@pytest.fixture
def calls(monkeypatch):
    """Подменяем запуск CLI: запоминаем аргументы, отдаём заготовленные ответы."""
    class Log(list):
        answers = {}

    log = Log()
    answers = log.answers = {}

    def fake_run(args, timeout=900, cwd=None):
        log.append(list(args))
        key = args[0]
        value = answers.get(key, "OK: fake")
        if callable(value):
            return value(args)
        return value

    monkeypatch.setattr(m, "_run", fake_run)
    monkeypatch.setattr(m.time, "sleep", lambda s: None)
    return log


def test_upload_folder_is_sequential_and_keeps_structure(calls, tmp_path):
    (tmp_path / "checkers").mkdir()
    (tmp_path / "checkers" / "checker.cpp").write_text("int main(){}")
    (tmp_path / "score.py").write_text("print(1)")
    (tmp_path / ".DS_Store").write_bytes(b"\x00")          # мусор macOS
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "__pycache__" / "x.pyc").write_bytes(b"\x00")

    out = m.upload_folder("https://admin.contest.yandex.ru/problems/1%2F2%2F3/settings", str(tmp_path))

    uploads = [c for c in calls if c[0] == "upload"]
    assert [c[3] for c in uploads] == ["checkers/checker.cpp", "score.py"]
    assert "Залито 2 из 2" in out


def test_upload_folder_retries_then_reports_failure(calls, tmp_path):
    (tmp_path / "a.txt").write_text("a")
    (tmp_path / "b.txt").write_text("b")
    attempts = {"a.txt": 0}

    def flaky(args):
        target = args[3]
        if target == "a.txt":
            attempts["a.txt"] += 1
            return "OK: a" if attempts["a.txt"] == 3 else "[exit 1]\n423 Locked"
        return "[exit 1]\n500 boom"

    calls.answers["upload"] = flaky
    out = m.upload_folder("url", str(tmp_path))
    assert attempts["a.txt"] == 3                       # два отказа, третья попытка удалась
    assert sum(1 for c in calls if c[3:] == ["b.txt"]) == m.UPLOAD_ATTEMPTS
    assert "Залито 1 из 2" in out and "НЕ ЗАЛИТО: b.txt" in out


def test_upload_folder_with_prefix(calls, tmp_path):
    (tmp_path / "public").write_text("id\n1\n")
    m.upload_folder("url", str(tmp_path), target_prefix="tests/")
    assert calls[0][3] == "tests/public"


def test_clear_is_refused_in_passthrough(calls):
    out = m.contest_cli(["clear", "url", "--yes"])
    assert "отказ" in out
    assert calls == []


def test_stage_files_validates_stage_and_action(calls):
    assert "ошибка" in m.stage_files("url", "magic-files", "add", "x")
    assert "ошибка" in m.stage_files("url", "compile-files", "toggle", "x")
    assert calls == []
    m.stage_files("url", "compile-files", "add", "score.py")
    assert calls[-1] == ["compile-files", "url", "add", "score.py"]


def test_run_redacts_cookie_values(monkeypatch):
    """Даже если CLI напечатает куку (отладка, трейсбек) — наружу она не уйдёт."""

    def fake_subprocess_run(cmd, **kw):
        return subprocess.CompletedProcess(cmd, 1, stdout="Cookie: Session_id=3:secret.value; yandexuid=42\n", stderr="")

    monkeypatch.setattr(m.subprocess, "run", fake_subprocess_run)
    out = m._run(["settings", "url"])
    assert "secret.value" not in out
    assert out.startswith("[exit 1]")


def test_problem_refs_parsed_from_contest_problems_output():
    text = (
        "Задач в контесте 12345: 2\n"
        "  A: Предсказание спроса  (123456/2026_09_01/aB1cD2eF3g)\n"
        "  B2: Поиск аномалий  (123456/2026_09_02/zY9xW8vU7t)\n"
    )
    assert m._problem_refs(text) == [
        ("A", "123456/2026_09_01/aB1cD2eF3g"),
        ("B2", "123456/2026_09_02/zY9xW8vU7t"),
    ]


def test_recon_reads_every_problem(calls):
    calls.answers["contest-problems"] = "Задач: 1\n  A: X  (1/2026_01_01/abc)\n"
    out = m.recon("12345")
    cmds = [c[0] for c in calls]
    assert cmds[:3] == ["contest-settings", "contest-problems", "submission-stat"]
    assert "settings" in cmds and "statement-list" in cmds and "testset-get" in cmds
    assert "list" not in cmds                            # дерево — только по with_files
    assert "problems/1%2F2026_01_01%2Fabc/settings" in out


def test_kit_new_copies_template_and_refuses_nonempty(tmp_path):
    dest = tmp_path / "task"
    out = m.kit_new(str(dest), "Проба")
    assert (dest / "final" / "score.py").exists()
    assert (dest / "simulate.sh").exists()
    assert "Проба" in out
    assert "не пустая" in m.kit_new(str(dest))


def test_server_speaks_mcp_over_stdio():
    """Настоящий клиент MCP: инструменты и ресурсы объявлены, справка читается."""
    from mcp.client.session import ClientSession
    from mcp.client.stdio import StdioServerParameters, stdio_client

    async def go():
        params = StdioServerParameters(command=sys.executable, args=["-m", "contest_kit.mcp_server"])
        async with stdio_client(params) as (r, w):
            async with ClientSession(r, w) as s:
                await s.initialize()
                tools = {t.name for t in (await s.list_tools()).tools}
                uris = {str(x.uri) for x in (await s.list_resources()).resources}
                doc = await s.read_resource("contest://help/cli")
                return tools, uris, doc.contents[0].text

    tools, uris, cli_help = asyncio.run(go())
    for must in ("auth_status", "upload_folder", "statement_set_all", "checker_compile",
                 "testset_set_pattern", "submit", "submission_get", "recon", "contest_cli"):
        assert must in tools
    assert "contest://help/protocol" in uris and "contest://help/cli" in uris
    assert "upload <problem_url>" in cli_help
