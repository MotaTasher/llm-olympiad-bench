import os

from contest_kit import tree

# Ответ площадки на GET /api/admin/problem/{id}/file, урезанный до формы.
REMOTE = {
    "items": [
        {"name": "score.py", "size": 1200, "contentType": {"type": "text/x-python"}},
        {"name": "Makefile", "size": 300, "contentType": {"type": "text/plain"}},
        {
            "name": "tests",
            "directory": True,
            "items": [
                {"name": "public", "size": 5000, "contentType": {"type": "text/csv"}},
                {"name": "public.a", "size": 400, "contentType": {"type": "text/plain"}},
            ],
        },
        {
            "name": "checkers",
            "directory": True,
            "items": [
                {"name": "checker.cpp", "size": 2100, "contentType": {"type": "text/plain"}},
            ],
        },
    ]
}


def test_flatten_keeps_nested_paths():
    paths = [f.path for f in tree.flatten(REMOTE)]
    assert paths == [
        "score.py", "Makefile",
        "tests/public", "tests/public.a",
        "checkers/checker.cpp",
    ]


def test_flatten_reads_size_and_type():
    by_path = {f.path: f for f in tree.flatten(REMOTE)}
    assert by_path["tests/public"].size == 5000
    assert by_path["score.py"].content_type == "text/x-python"


def test_flatten_empty_tree():
    assert tree.flatten({"items": []}) == []
    assert tree.flatten({}) == []


def test_flatten_null_items():
    """У пустой задачи items приезжает как null, а не как []."""
    assert tree.flatten({"items": None}) == []


def _make_kit(root):
    (root / "tests").mkdir()
    (root / "__pycache__").mkdir()
    (root / "score.py").write_text("x" * 1200)
    (root / "Makefile").write_text("y" * 300)
    (root / "tests" / "public").write_text("z" * 5000)
    (root / ".DS_Store").write_text("junk")
    (root / "__pycache__" / "score.cpython-313.pyc").write_text("junk")
    return root


def test_scan_local_excludes_junk_by_default(tmp_path):
    paths = [f.path for f in tree.scan_local(_make_kit(tmp_path))]
    assert paths == ["Makefile", "score.py", "tests/public"]


def test_scan_local_with_prefix(tmp_path):
    paths = [f.path for f in tree.scan_local(_make_kit(tmp_path), prefix="kit")]
    assert paths == ["kit/Makefile", "kit/score.py", "kit/tests/public"]


def test_scan_local_records_disk_path(tmp_path):
    files = tree.scan_local(_make_kit(tmp_path))
    for f in files:
        assert os.path.isfile(f.local_path)


def test_diff_skips_files_with_matching_size(tmp_path):
    """Идемпотентность: повторный apply не должен перезаливать неизменившееся —
    иначе на каждой задаче ловим 423 на ровном месте."""
    local = tree.scan_local(_make_kit(tmp_path))
    remote = tree.flatten(REMOTE)
    to_upload, unchanged, extra = tree.diff(local, remote)
    assert [f.path for f in unchanged] == ["Makefile", "score.py", "tests/public"]
    assert to_upload == []
    assert sorted(f.path for f in extra) == ["checkers/checker.cpp", "tests/public.a"]


def test_diff_uploads_changed_size(tmp_path):
    root = _make_kit(tmp_path)
    (root / "score.py").write_text("x" * 999)
    to_upload, unchanged, _ = tree.diff(tree.scan_local(root), tree.flatten(REMOTE))
    assert [f.path for f in to_upload] == ["score.py"]
    assert [f.path for f in unchanged] == ["Makefile", "tests/public"]


def test_diff_uploads_missing_file(tmp_path):
    root = _make_kit(tmp_path)
    (root / "new.txt").write_text("hello")
    to_upload, _, _ = tree.diff(tree.scan_local(root), tree.flatten(REMOTE))
    assert [f.path for f in to_upload] == ["new.txt"]
