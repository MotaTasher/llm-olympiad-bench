"""
Слой заливки. Сеть подменена заглушкой, которая ведёт себя как площадка:
принимает файл в S3, а при регистрации разворачивает архив в дерево —
нерекурсивно, как это делает Контест.

Проверяется не «ушёл ли запрос», а что в итоге оказалось в дереве задачи.
"""

import io
import zipfile

import pytest

from contest_kit import errors
from contest_kit.api import files as api_files

PROBLEM = "123456/2026_07_24/aB1cD2eF3g"


class FakeS3:
    """Запоминает байты последней загрузки — они нужны заглушке площадки."""

    def __init__(self):
        self.last = None
        self.uploads = 0

    def post(self, url, data=None, files=None):
        _name, fobj, _ctype = files["file"]
        self.last = fobj.read()
        self.uploads += 1
        return _Resp()


class FakeClient:
    """
    Дерево файлов задачи + поведение распаковки.

    unpacks=False моделирует случай, когда площадка архив НЕ развернула, —
    на нём проверяется откат на поштучную заливку.
    """

    def __init__(self, s3, unpacks=True):
        self.s3 = s3
        self.unpacks = unpacks
        self.tree = {}
        self.calls = []
        self.registered = []

    def json(self, method, path, *, referer, **kwargs):
        self.calls.append((method, path))
        if path.endswith("/file"):
            return self._tree_response()
        if path == "/api/admin/upload-file":
            return {"url": "https://s3.example/upload", "fields": {"key": "k"}, "key": "k"}
        raise AssertionError(f"неожиданный json-запрос: {path}")

    def request(self, method, path, *, referer, serialize=False, **kwargs):
        self.calls.append((method, path))
        if method == "POST" and path.endswith("/files"):
            self._register(kwargs["json"]["path"])
        elif method == "DELETE":
            self.tree.pop(path.split("/file/")[-1].replace("%7C", "/"), None)
        return _Resp()

    def _register(self, target):
        self.registered.append(target)
        blob = self.s3.last
        if self.unpacks and blob and zipfile.is_zipfile(io.BytesIO(blob)):
            parent = target.rsplit("/", 1)[0] if "/" in target else ""
            with zipfile.ZipFile(io.BytesIO(blob)) as z:
                for info in z.infolist():
                    if info.is_dir():
                        continue
                    # Нерекурсивно: вложенный архив кладётся файлом как есть.
                    name = info.filename
                    self.tree[f"{parent}/{name}" if parent else name] = info.file_size
        else:
            self.tree[target] = len(blob or b"")

    def _tree_response(self):
        root = {"items": []}
        for path in sorted(self.tree):
            node, parts = root, path.split("/")
            for part in parts[:-1]:
                found = next(
                    (i for i in node["items"] if i["name"] == part and i.get("directory")), None
                )
                if found is None:
                    found = {"name": part, "directory": True, "items": []}
                    node["items"].append(found)
                node = found
            node["items"].append(
                {"name": parts[-1], "size": self.tree[path], "contentType": {"type": "t"}}
            )
        return root


class _Resp:
    status_code = 200
    text = ""
    content = b""


@pytest.fixture
def s3(monkeypatch):
    fake = FakeS3()
    monkeypatch.setattr(api_files.requests, "post", fake.post)
    return fake


@pytest.fixture
def client(s3):
    return FakeClient(s3)


@pytest.fixture
def stubborn_client(s3):
    """Площадка, которая архивы не разворачивает."""
    return FakeClient(s3, unpacks=False)


@pytest.fixture
def kit(tmp_path):
    (tmp_path / "tests").mkdir()
    (tmp_path / "score.py").write_text("x")
    (tmp_path / "Makefile").write_text("y")
    (tmp_path / "run.sh").write_text("z")
    (tmp_path / "tests" / "public").write_text("a")
    (tmp_path / "tests" / "public.a").write_text("b")
    (tmp_path / ".DS_Store").write_text("junk")
    return tmp_path


def _zip(dirpath, name="kit.zip", members=("a.txt", "sub/b.txt")):
    path = dirpath / name
    with zipfile.ZipFile(path, "w") as z:
        for m in members:
            z.writestr(m, "data")
    return path


# --- одиночная заливка -----------------------------------------------------


def test_plain_file_uploads_without_extra_tree_request(client, kit):
    result = api_files.upload_file(client, PROBLEM, str(kit / "score.py"), "score.py")
    assert client.registered == ["score.py"]
    assert result["verified"] is False
    assert not any(p.endswith("/file") for _m, p in client.calls)


def test_missing_local_file_fails_before_network(client, kit):
    with pytest.raises(errors.ContestError) as e:
        api_files.upload_file(client, PROBLEM, str(kit / "nope.py"), "nope.py")
    assert e.value.code == "LOCAL_FILE_MISSING"
    assert client.calls == []


def test_archive_without_intent_is_refused_before_network(client, tmp_path):
    """Ошибка до сети: залитый архив уже не вернёшь в исходное состояние."""
    with pytest.raises(errors.ContestError) as e:
        api_files.upload_file(client, PROBLEM, str(_zip(tmp_path)), "kit.zip")
    assert e.value.code == "ARCHIVE_AMBIGUOUS"
    assert client.calls == []


def test_unpack_lands_contents_in_the_tree(client, tmp_path):
    report = api_files.upload_file(
        client, PROBLEM, str(_zip(tmp_path)), "kit.zip", archive="unpack"
    )
    assert report["ok"] and report["unpacked"]
    assert sorted(client.tree) == ["a.txt", "sub/b.txt"]
    assert "kit.zip" not in client.tree


def test_unpack_into_subfolder(client, tmp_path):
    api_files.upload_file(
        client, PROBLEM, str(_zip(tmp_path)), "upload/kit.zip", archive="unpack"
    )
    assert sorted(client.tree) == ["upload/a.txt", "upload/sub/b.txt"]


def test_unpack_that_did_not_happen_is_an_error(stubborn_client, tmp_path):
    with pytest.raises(errors.ContestError) as e:
        api_files.upload_file(
            stubborn_client, PROBLEM, str(_zip(tmp_path)), "kit.zip", archive="unpack"
        )
    assert e.value.code == "ARCHIVE_UNEXPECTED"
    assert "остался файлом" in e.value.message


def test_keep_survives_thanks_to_outer_archive(client, tmp_path):
    """Главный приём: внешний архив разворачивается, внутренний остаётся файлом
    и его можно дать ссылкой в условии."""
    report = api_files.upload_file(
        client, PROBLEM, str(_zip(tmp_path, "train_data.zip")),
        "statements/data/train_data.zip", archive="keep",
    )
    assert report["ok"]
    assert list(client.tree) == ["statements/data/train_data.zip"]
    assert client.registered == ["statements/data/outer.zip"]


def test_keep_does_not_leave_the_wrapper_behind(client, tmp_path):
    api_files.upload_file(
        client, PROBLEM, str(_zip(tmp_path)), "statements/data.zip", archive="keep"
    )
    assert not any(p.endswith("outer.zip") for p in client.tree)


def test_keep_renames_to_target_name(client, tmp_path):
    """В дереве появляется имя из целевого пути, а не имя локального файла."""
    api_files.upload_file(
        client, PROBLEM, str(_zip(tmp_path, "local_name.zip")),
        "statements/pretty_name.zip", archive="keep",
    )
    assert list(client.tree) == ["statements/pretty_name.zip"]


# --- заливка папки ---------------------------------------------------------


def test_folder_auto_prefers_single_archive(client, kit):
    """Пять файлов — пять запросов под локом против одного. Ради этого всё и
    затевалось."""
    result = api_files.upload_folder(client, PROBLEM, str(kit))
    assert result["mode"] == "zip"
    assert result["count"] == 5
    assert client.s3.uploads == 1


def test_folder_zip_excludes_junk(client, kit):
    api_files.upload_folder(client, PROBLEM, str(kit))
    assert ".DS_Store" not in client.tree
    assert sorted(client.tree) == [
        "Makefile", "run.sh", "score.py", "tests/public", "tests/public.a",
    ]


def test_folder_zip_does_not_leave_transport_archive(client, kit):
    api_files.upload_folder(client, PROBLEM, str(kit))
    assert "payload.zip" not in client.tree


def test_folder_zip_falls_back_when_nothing_unpacked(stubborn_client, kit):
    """Если распаковки не случилось, папка всё равно должна оказаться залитой."""
    result = api_files.upload_folder(stubborn_client, PROBLEM, str(kit), mode="zip")
    assert result["mode"] == "files"
    assert sorted(stubborn_client.tree) == [
        "Makefile", "run.sh", "score.py", "tests/public", "tests/public.a",
    ]


def test_folder_with_inner_archive_uses_fast_path(client, kit):
    """Вложенный архив — довод ЗА общий zip, а не против: распаковка не
    рекурсивная, поэтому он доедет до дерева целым. Поштучно его развернуло бы."""
    _zip(kit, "statements_data.zip")
    result = api_files.upload_folder(client, PROBLEM, str(kit))
    assert result["mode"] == "zip"
    assert "statements_data.zip" in client.tree


def test_small_folder_goes_file_by_file(client, tmp_path):
    (tmp_path / "a.txt").write_text("1")
    (tmp_path / "b.txt").write_text("2")
    result = api_files.upload_folder(client, PROBLEM, str(tmp_path))
    assert result["mode"] == "files"
    assert result["count"] == 2


def test_file_by_file_keeps_archives_intact(client, tmp_path):
    """Поштучный режим тоже не должен разворачивать архив — иначе папка с
    данными к условию приедет в дерево россыпью."""
    (tmp_path / "legend.md").write_text("текст")
    _zip(tmp_path, "data.zip")
    api_files.upload_folder(client, PROBLEM, str(tmp_path), mode="files")
    assert sorted(client.tree) == ["data.zip", "legend.md"]


def test_folder_with_prefix_lands_under_it(client, kit):
    api_files.upload_folder(client, PROBLEM, str(kit), prefix="kit", mode="zip")
    assert "kit/score.py" in client.tree
    assert "kit/tests/public" in client.tree


def test_empty_folder_is_noop(client, tmp_path):
    result = api_files.upload_folder(client, PROBLEM, str(tmp_path))
    assert result["count"] == 0
    assert client.calls == []


def test_unknown_mode_is_rejected(client, kit):
    with pytest.raises(errors.ContestError) as e:
        api_files.upload_folder(client, PROBLEM, str(kit), mode="turbo")
    assert e.value.code == "BAD_REF"


def test_list_and_delete(client):
    client.tree = {"score.py": 1, "tests/public": 1}
    assert sorted(api_files.list_paths(client, PROBLEM)) == ["score.py", "tests/public"]
    api_files.delete_file(client, PROBLEM, "tests/public")
    assert "tests/public" not in client.tree
