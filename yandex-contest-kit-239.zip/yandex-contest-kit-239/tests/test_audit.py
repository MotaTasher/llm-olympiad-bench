import json

import pytest

from contest_kit import audit, errors


@pytest.fixture
def log(tmp_path, monkeypatch):
    monkeypatch.setattr(audit, "STATE_DIR", tmp_path / "state")
    monkeypatch.setattr(audit, "LOG_FILE", tmp_path / "state" / "commands.jsonl")
    monkeypatch.delenv("CONTEST_KIT_NO_LOG", raising=False)
    return audit.LOG_FILE


def read(log):
    return [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]


def test_record_writes_one_line_per_run(log):
    audit.Record(["files", "list"]).finish(0)
    audit.Record(["files", "upload"]).finish(0)
    assert len(read(log)) == 2


def test_record_captures_shape_of_run(log):
    rec = audit.Record(["problem", "apply"])
    rec.note(problem="123456/2026_07_24/aB1cD2eF3g")
    rec.http_call(retried_locked=2, bytes_up=1024)
    rec.http_call()
    rec.finish(0)
    entry = read(log)[0]
    assert entry["argv"] == ["problem", "apply"]
    assert entry["problem"].endswith("aB1cD2eF3g")
    assert entry["http"] == {"calls": 2, "retries_423": 2, "bytes_up": 1024}
    assert entry["exit"] == 0
    assert "dur_ms" in entry


def test_record_stores_error_code(log):
    audit.Record(["files", "upload"]).finish(1, errors.make("RESOURCE_LOCKED", "423"))
    entry = read(log)[0]
    assert entry["exit"] == 1
    assert entry["error"]["code"] == "RESOURCE_LOCKED"


def test_secrets_never_reach_the_log(log):
    """Лог уедет в обезличенном виде наружу — значения кук в нём недопустимы
    ни в argv, ни в тексте ошибки."""
    rec = audit.Record(["auth", "login", "--cookie", "Session_id=3:FAKEVALUE"])
    rec.finish(1, errors.make("SESSION_EXPIRED", "падало с Session_id=3:FAKEVALUE"))
    raw = log.read_text(encoding="utf-8")
    assert "3:FAKEVALUE" not in raw
    assert "<скрыто>" in raw


def test_scrub_argv_masks_value_after_secret_flag():
    assert audit.scrub_argv(["auth", "--csrf", "abc", "x"]) == ["auth", "--csrf", "<скрыто>", "x"]


def test_scrub_argv_redacts_inline_cookies():
    out = audit.scrub_argv(["--header", "Cookie: Session_id=3:AAA"])
    assert "3:AAA" not in out[1]


def test_opt_out_by_env(log, monkeypatch):
    monkeypatch.setenv("CONTEST_KIT_NO_LOG", "1")
    audit.Record(["files", "list"]).finish(0)
    assert not log.exists()


def test_log_failure_does_not_break_command(tmp_path, monkeypatch):
    """Лог — побочный эффект: если писать некуда, команда обязана продолжить
    работу, а не упасть."""
    monkeypatch.setattr(audit, "STATE_DIR", tmp_path / "state")
    monkeypatch.setattr(audit, "LOG_FILE", tmp_path / "state" / "commands.jsonl")
    (tmp_path / "state").write_text("это файл, а не каталог")
    audit.Record(["files", "list"]).finish(0)  # не должно бросить
