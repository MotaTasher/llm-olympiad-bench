"""
Классификация ответов площадки. Сети нет — ответы подставляются заглушкой.

Именно здесь закреплены грабли, из-за которых раньше терялось время:
HTML-логин под статусом 200, 423 на параллельных файловых операциях,
403 из-за неправильного Referer.
"""

import pytest

from contest_kit import auth, errors, http

LOGIN_HTML = "<html><head><title>Log in</title></head><body></body></html>"


class FakeResponse:
    def __init__(self, status=200, body="{}", ctype="application/json", referer=None):
        self.status_code = status
        self.text = body
        self.content = body.encode()
        self.headers = {"Content-Type": ctype}
        self.request = type("Req", (), {"headers": {"Referer": referer}})()

    def json(self):
        import json
        return json.loads(self.text)


@pytest.fixture
def client(monkeypatch):
    creds = auth.Credentials(cookie="Session_id=A; sessionid2=B", csrf="tok", profile="test")
    c = http.Client(creds)
    monkeypatch.setattr(http.time, "sleep", lambda _s: None)
    return c


def respond_with(client, monkeypatch, *responses):
    """Подсунуть клиенту заранее заданную последовательность ответов."""
    seq = list(responses)
    calls = []

    def fake_request(method, url, **kwargs):
        calls.append((method, url))
        return seq.pop(0) if len(seq) > 1 else seq[0]

    monkeypatch.setattr(client.s, "request", fake_request)
    return calls


def test_login_page_under_200_is_session_expired(client, monkeypatch):
    """Площадка отдаёт страницу логина СО СТАТУСОМ 200 — без явной проверки
    это уезжает наверх как «ответ не JSON» в случайном месте."""
    respond_with(client, monkeypatch, FakeResponse(200, LOGIN_HTML, "text/html"))
    with pytest.raises(errors.SessionExpired) as e:
        client.request("GET", "/api/admin/compilers", referer="/problems")
    assert e.value.code == "SESSION_EXPIRED"
    assert e.value.next_command


def test_locked_is_retried_then_succeeds(client, monkeypatch):
    calls = respond_with(
        client, monkeypatch,
        FakeResponse(423, "locked", "text/plain"),
        FakeResponse(423, "locked", "text/plain"),
        FakeResponse(200, '{"ok": true}'),
    )
    resp = client.request("POST", "/api/admin/problems/x/files", referer="/problems/x/files")
    assert resp.status_code == 200
    assert len(calls) == 3


def test_locked_gives_up_with_actionable_error(client, monkeypatch):
    respond_with(client, monkeypatch, FakeResponse(423, "locked", "text/plain"))
    with pytest.raises(errors.ResourceLocked) as e:
        client.request("POST", "/api/admin/problems/x/files", referer="/problems/x/files")
    assert e.value.details["attempts"] == http.LOCKED_ATTEMPTS
    assert "последовательно" in e.value.hint


def test_403_on_patch_points_at_referer(client, monkeypatch):
    """Самая дорогая по времени ошибка: PATCH настроек с Referer со страницы
    файлов молча падает 403, хотя заливка с тем же Referer работает."""
    respond_with(client, monkeypatch,
                 FakeResponse(403, "forbidden", "text/plain", referer="/problems/x/files"))
    with pytest.raises(errors.ContestError) as e:
        client.request("PATCH", "/api/admin/problem/x", referer="/problems/x/files")
    assert e.value.code == "REFERER_REQUIRED"
    assert e.value.details["referer"] == "/problems/x/files"


def test_400_on_patch_flags_unpatchable_field(client, monkeypatch):
    respond_with(client, monkeypatch, FakeResponse(400, "bad request", "text/plain"))
    with pytest.raises(errors.ContestError) as e:
        client.request("PATCH", "/api/admin/problem/x", referer="/problems/x/settings")
    assert e.value.code == "FIELD_NOT_PATCHABLE"


def test_404_is_not_found(client, monkeypatch):
    respond_with(client, monkeypatch, FakeResponse(404, "nope", "text/plain"))
    with pytest.raises(errors.ContestError) as e:
        client.request("GET", "/api/admin/problem/x", referer="/problems/x/settings")
    assert e.value.code == "NOT_FOUND"


def test_error_body_is_redacted(client, monkeypatch):
    respond_with(client, monkeypatch,
                 FakeResponse(500, "fail Session_id=3:FAKEVALUE;", "text/plain"))
    with pytest.raises(errors.ContestError) as e:
        client.request("GET", "/api/admin/problem/x", referer="/problems/x/settings")
    assert "3:FAKEVALUE" not in str(e.value.details)
    assert "Session_id=<" in e.value.details["body"]


def test_referer_header_is_absolute(client, monkeypatch):
    sent = {}

    def fake_request(method, url, headers=None, **kwargs):
        sent.update(headers or {})
        return FakeResponse(200)

    monkeypatch.setattr(client.s, "request", fake_request)
    client.request("GET", "/api/admin/problem/x", referer="/problems/x/settings")
    assert sent["Referer"] == "https://admin.contest.yandex.ru/problems/x/settings"


def test_csrf_header_set_from_credentials(client):
    assert client.s.headers["x-csrf-token"] == "tok"


def test_client_without_csrf_omits_header():
    c = http.Client(auth.Credentials(cookie="Session_id=A"))
    assert "x-csrf-token" not in c.s.headers


def test_json_helper_returns_none_on_empty_body(client, monkeypatch):
    respond_with(client, monkeypatch, FakeResponse(204, "", "application/json"))
    assert client.json("DELETE", "/api/admin/problem/x/file/y", referer="/problems/x/files") is None


def test_json_helper_explains_non_json(client, monkeypatch):
    respond_with(client, monkeypatch, FakeResponse(200, "<html>oops</html>", "text/html"))
    with pytest.raises(errors.ContestError) as e:
        client.json("GET", "/api/admin/problem/x", referer="/problems/x/settings")
    assert e.value.code == "HTTP_ERROR"


def test_looks_like_login_page_ignores_json():
    assert not http.looks_like_login_page(FakeResponse(200, '{"a":1}'))
    assert http.looks_like_login_page(FakeResponse(200, LOGIN_HTML, "text/html"))
