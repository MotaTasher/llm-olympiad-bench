import time

import pytest

from contest_kit import cache

COMPILERS = [{"id": "python3_13"}, {"id": "gcc14_cpp23"}]


@pytest.fixture
def cache_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(cache, "CACHE_DIR", tmp_path / "cache")
    return tmp_path


def test_put_then_get(cache_dir):
    cache.put(cache.COMPILERS, COMPILERS)
    assert cache.get(cache.COMPILERS, cache.COMPILERS_TTL) == COMPILERS


def test_get_missing_returns_none(cache_dir):
    assert cache.get(cache.COMPILERS, cache.COMPILERS_TTL) is None


def test_expired_entry_is_ignored(cache_dir, monkeypatch):
    """Правило: список компиляторов перезапрашиваем, если с последнего успеха
    прошли сутки."""
    cache.put(cache.COMPILERS, COMPILERS)
    later = time.time() + cache.COMPILERS_TTL + 1
    monkeypatch.setattr(cache.time, "time", lambda: later)
    assert cache.get(cache.COMPILERS, cache.COMPILERS_TTL) is None


def test_fresh_entry_survives_just_under_ttl(cache_dir, monkeypatch):
    cache.put(cache.COMPILERS, COMPILERS)
    later = time.time() + cache.COMPILERS_TTL - 60
    monkeypatch.setattr(cache.time, "time", lambda: later)
    assert cache.get(cache.COMPILERS, cache.COMPILERS_TTL) == COMPILERS


def test_invalidate_drops_entry(cache_dir):
    cache.put(cache.COMPILERS, COMPILERS)
    cache.invalidate(cache.COMPILERS)
    assert cache.get(cache.COMPILERS, cache.COMPILERS_TTL) is None


def test_invalidate_missing_is_noop(cache_dir):
    cache.invalidate(cache.COMPILERS)  # не должно бросить


def test_corrupted_cache_is_treated_as_empty(cache_dir):
    cache.put(cache.COMPILERS, COMPILERS)
    (cache.CACHE_DIR / "compilers.json").write_text("{битый json")
    assert cache.get(cache.COMPILERS, cache.COMPILERS_TTL) is None


def test_age_reports_seconds(cache_dir):
    cache.put(cache.COMPILERS, COMPILERS)
    assert 0 <= cache.age(cache.COMPILERS) < 5
    assert cache.age("nonexistent") is None
