# TODO: название задачи

- Контест: **TODO: название** (id `TODO`) — <https://admin.contest.yandex.ru/contests/TODO/settings>
- Задача: `TODO/problem/id` — <https://admin.contest.yandex.ru/problems/TODO/settings>
- Буква в контесте: TODO
- Короткое имя: `todo-short-name`
- Тип: `PROBLEM_WITH_CHECKER`, максимальный балл: 100
- Посылка: zip (`submission.csv` + `.ipynb`), компилятор `python-lyceum`
- Материалы: `final/` — то, что залито в задачу, `raw/` — генератор и авторские
  решения, `subm/` — эталонные посылки.

## Метрика

TODO: формула, что считается Public, что Private, чем измеряется.

## Авторские результаты

| Решение | Public | Private |
|---|---:|---:|
| baseline | — | — |
| solution | — | — |
