#!/bin/bash
# Локальный прогон всех четырёх стадий Яндекс.Контеста на одном zip-архиве
# посылки, ровно так, как их запускает площадка:
#
#   1) compile : compile-files + посылка -> make build (bash doit.sh)
#   2) runtime : runtime-files + артефакты компиляции -> make run (score.py)
#   3) checker : эмуляция checkers/checker.cpp (testlib, quitp) — читает первую
#                строку answers.json; строка на "$" -> WA с этим текстом,
#                иначе балл = число из "public"
#   4) postproc: postprocessor.py со stdin = {"tests":[{"message": <текст чекера>}]}
#
# Чекер эмулируется на python: настоящий checkers/checker — это ELF-бинарник
# под Linux, собранный на площадке из checker.cpp (gcc14_cpp23), локально он
# не запускается. Логика повторена построчно, см. final/checkers/checker.cpp.
#
# Использование: ./simulate.sh subm/submission_score_050.zip
set -u

ROOT="$(cd "$(dirname "$0")" && pwd)"
KIT="$ROOT/final"
SUB="${1:?укажи zip с посылкой}"
[ -f "$SUB" ] || { echo "нет файла посылки: $SUB" >&2; exit 1; }
SUB="$(cd "$(dirname "$SUB")" && pwd)/$(basename "$SUB")"
PY="${PY:-python3}"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# ---------- 1. compile ----------
mkdir -p "$WORK/compile"
cp "$KIT/Makefile" "$KIT/doit.sh" "$KIT/run.sh" "$KIT/score.py" "$KIT/ytest.csv" "$WORK/compile/"
cp "$SUB" "$WORK/compile/$(basename "$SUB")"
echo "=== compile stage ==="
( cd "$WORK/compile" && filename="$(basename "$SUB")" make build )
echo "  exit=$?"

# ---------- 2. runtime ----------
mkdir -p "$WORK/run"
cp "$KIT/Makefile" "$KIT/run.sh" "$KIT/score.py" "$KIT/ytest.csv" "$WORK/run/"
for f in data.csv archive_error.txt; do
    [ -f "$WORK/compile/$f" ] && cp "$WORK/compile/$f" "$WORK/run/"
done
cp "$KIT/tests/public" "$WORK/run/test.csv"   # fileSettings.inputFileName = test.csv
echo "=== runtime stage ==="
( cd "$WORK/run" && make run )
echo "  exit=$?"

# ---------- 3. checker (эмуляция testlib-чекера) ----------
echo "=== checker stage ==="
"$PY" - "$WORK/run/answers.json" <<'PY'
import sys

path = sys.argv[1]
try:
    with open(path, encoding="utf-8", errors="replace") as f:
        line = f.readline().strip()
except OSError as e:
    print("FAIL: не смог прочитать выходной файл: {}".format(e))
    raise SystemExit(3)

if not line:
    print("FAIL: Checker output is empty")
    raise SystemExit(3)

if line.startswith("$"):
    print("WA: {}".format(line))
    print("  БАЛЛ ЗА ПОСЫЛКУ: 0")
    raise SystemExit(0)

key = line.find('"public"')
colon = line.find(":", key) if key != -1 else -1
if colon == -1:
    print("FAIL: Could not parse 'public' score from: {}".format(line))
    raise SystemExit(3)

number = ""
for ch in line[colon + 1:].lstrip():
    if ch.isdigit() or ch in ".-+eE":
        number += ch
    else:
        break
try:
    points = float(number)
except ValueError:
    print("FAIL: Could not parse 'public' score from: {}".format(line))
    raise SystemExit(3)

print("OK: {}".format(line))
print("  БАЛЛ ЗА ПОСЫЛКУ: {:.2f}".format(points))
PY

# ---------- 4. postprocessor ----------
echo "=== postprocess stage ==="
MESSAGE="$(head -n 1 "$WORK/run/answers.json" 2>/dev/null || echo '')"
"$PY" - "$MESSAGE" <<'PY' > "$WORK/postproc_in.json"
import json, sys
print(json.dumps({"tests": [{"message": sys.argv[1], "verdict": "OK", "score": 0}]}))
PY
"$PY" "$KIT/postprocessor.py" < "$WORK/postproc_in.json"
echo "  exit=$?"
