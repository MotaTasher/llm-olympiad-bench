// Общий чекер задач с CSV-посылкой: один и тот же файл во всех датасетных
// задачах. От задачи не зависит — править не надо.
// TESTLIB_EXITCODE_CHECKER: quitp() — надёжный, документированный способ
// выставить дробный балл через testlib, в отличие от парсинга stdout в
// EJUDGE_EXITCODE_CHECKER (площадка берёт оттуда ПЕРВЫЙ ТОКЕН — на этом
// уже горели: вердикт OK, баллов 0).
// Логика не зависит от задачи: просто вытаскивает число "public" из первой
// строки выходного файла решения (answers.json = {"public":X,"private":Y}).
#include "testlib.h"
#include <sstream>
#include <string>
#include <cctype>

using namespace std;

double extractPublicScore(const string &token, bool &ok) {
    ok = false;
    size_t keyPos = token.find("\"public\"");
    if (keyPos == string::npos) return 0.0;
        size_t colonPos = token.find(':', keyPos);
    if (colonPos == string::npos) return 0.0;
        size_t pos = colonPos + 1;
    while (pos < token.size() && token[pos] == ' ') pos++;
        size_t start = pos;
    while (pos < token.size() && (isdigit((unsigned char) token[pos]) || token[pos] == '.' || token[pos] == '-' || token[pos] == '+' || token[pos] == 'e' || token[pos] == 'E')) pos++;
    if (pos == start) return 0.0;
        string numStr = token.substr(start, pos - start);
    try {
        double value = stod(numStr);
        ok = true;
        return value;
    } catch (...) {
        return 0.0;
    }
}

int main(int argc, char *argv[]) {
    setName("scored checker");
    registerTestlibCmd(argc, argv);
    if (ouf.eof()) {
        quitf(_fail, "Checker output is empty");
    }
    string token = ouf.readLine();
    if (token.empty()) {
        quitf(_fail, "Checker output is empty");
    }
    if (token[0] == '$') {
        quitf(_wa, "%s", token.c_str());
    }
    bool parsed = false;
    double publicScore = extractPublicScore(token, parsed);
    if (!parsed) {
        quitf(_fail, "Could not parse 'public' score from: %s", token.c_str());
    }
    quitp(publicScore, "%s", token.c_str());
}
