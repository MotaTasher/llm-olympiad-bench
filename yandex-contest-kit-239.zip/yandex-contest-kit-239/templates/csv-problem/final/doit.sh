#!/bin/bash
# Build-стадия. Выполняется ОДИН РАЗ на посылку (не на каждый тест) —
# скопирована из работающей датасетной задачи, от задачи не зависит.
# Распаковывает присланный участником zip (submission.csv + .ipynb),
# валидирует состав архива и кладёт предсказания в фиксированное место
# data.csv, которое дальше читает run.sh -> score.py на этапе запуска.
#
# Zip посылки ищется двумя способами (первый, который сработает):
#   1) переменная окружения $filename (так делает компилятор на этой площадке
#      для файловых посылок);
#   2) единственный *.zip в текущей директории (fallback, именно так это
#      работает в живых задачах).
#
# При любой проблеме с архивом НЕ падаем (exit 0), а пишем текст ошибки в
# archive_error.txt — score.py прочитает его на этапе запуска и вернёт
# участнику осмысленный вердикт вместо Compilation Error.

set -e

rm -f data.csv archive_error.txt

fail_archive() {
    echo "$1" > archive_error.txt
    echo "doit.sh: $1" >&2
    rm -f data.csv
    exit 0
}

ZIP_FILE=""
if [ -n "${filename:-}" ] && [ -f "${filename}" ]; then
    ZIP_FILE="${filename}"
else
    ZIP_FILE=$(ls *.zip 2>/dev/null | head -n1)
fi

if [ -z "$ZIP_FILE" ]; then
    fail_archive "Не найден zip-архив посылки"
fi

python3 - "$ZIP_FILE" data.csv <<'PY' || fail_archive "Внутренняя ошибка обработки архива"
import json
import os
import shutil
import sys
import zipfile

zip_path, out_path = sys.argv[1], sys.argv[2]


def fail(message):
    with open("archive_error.txt", "w", encoding="utf-8") as f:
        f.write(message + "\n")
    sys.stderr.write(message + "\n")
    if os.path.exists(out_path):
        os.remove(out_path)
    # 0 — чтобы стадия компиляции не упала с Compilation Error: осмысленный
    # вердикт участник получит от score.py на этапе запуска.
    raise SystemExit(0)


if not zipfile.is_zipfile(zip_path):
    fail("Посылка не является корректным .zip-архивом")

with zipfile.ZipFile(zip_path) as zf:
    # Имена и расположение файлов внутри архива не важны — ищем по
    # расширению в любом месте архива (так обещано в условии), пропуская
    # только служебный мусор macOS.
    csv_files, ipynb_files = [], []
    for name in zf.namelist():
        norm = name.replace("\\", "/")
        if norm.endswith("/") or norm.startswith("__MACOSX/"):
            continue
        if os.path.basename(norm).startswith("._"):
            continue
        low = norm.lower()
        if low.endswith(".csv"):
            csv_files.append(norm)
        elif low.endswith(".ipynb"):
            ipynb_files.append(norm)

    if len(csv_files) != 1:
        fail("В архиве должен быть ровно один .csv, найдено {}".format(len(csv_files)))
    if len(ipynb_files) != 1:
        fail("В архиве должен быть ровно один .ipynb, найдено {}".format(len(ipynb_files)))

    try:
        nb = json.loads(zf.read(ipynb_files[0]))
    except Exception as e:
        fail("Файл {} не является корректным JSON-ноутбуком: {}".format(ipynb_files[0], e))
    if "cells" not in nb:
        fail("Файл {} не похож на ноутбук (нет ключа 'cells')".format(ipynb_files[0]))

    with zf.open(csv_files[0]) as src, open(out_path, "wb") as dst:
        shutil.copyfileobj(src, dst)

print("doit.sh: CSV={} IPYNB={}".format(csv_files[0], ipynb_files[0]))
PY

if [ ! -f data.csv ]; then
    # python-часть уже записала archive_error.txt с человекочитаемой причиной
    exit 0
fi

echo "doit.sh: OK, data.csv готов ($(wc -l < data.csv) строк)"
