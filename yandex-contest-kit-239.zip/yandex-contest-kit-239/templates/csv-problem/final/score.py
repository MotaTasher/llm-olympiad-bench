# -*- coding: utf-8 -*-
"""
Шаблон скоринга задачи с CSV-посылкой. Механика — как в рабочих датасетных
задачах; специфика
задачи собрана в блоке НАСТРОЙКИ и в функции metric().

Вызывается ОДИН РАЗ на этапе времени запуска (run.sh -> python3 ./score.py),
без аргументов, без stdin/stdout решения. Читает:
  - ytest.csv (скрытые ответы, залит как compile/runtime-file):
    колонки <ID_COLUMN>,<TARGET_COLUMN>,Usage (Usage = Public/Private)
  - data.csv (посылка участника, распакована из zip на этапе doit.sh):
    колонки <ID_COLUMN>,<TARGET_COLUMN>

Пишет answers.json = {"public": <0-100>, "private": <0-100>} — это «выходной
файл» решения (fileSettings.outputFileName = answers.json). Чекер
(checkers/checker.cpp, testlib) читает первую строку и берёт "public" как балл
посылки; postprocessor.py достаёт оба числа в лидерборд.

Если посылка не проходит валидацию, в answers.json пишется строка вида
"$ <причина>" — чекер отдаёт её как WA с этим текстом. Падать с ненулевым
кодом нельзя: участник получит невнятный вердикт вместо объяснения.

Только стандартная библиотека: окружение запуска выбирает участник.
"""
import csv
import io
import json
import os
import sys

# ─── НАСТРОЙКИ: TODO под задачу ─────────────────────────────────────────────
ID_COLUMN = "id"
TARGET_COLUMN = "target"

SUBMISSION_HEADER = [ID_COLUMN, TARGET_COLUMN]
TARGET_HEADER = [ID_COLUMN, TARGET_COLUMN, "Usage"]

# Целевое значение: int для классификации, float для регрессии.
TARGET_TYPE = int
# Для классификации — допустимые метки; None = не проверять.
ALLOWED_LABELS = None          # например: {0, 1}

# Шкала баллов: метрика baseline -> 0, метрика авторского решения -> 100,
# между ними линейно (как в условии: X и Y). Оба значения берутся из
# настоящих решений на Public/Private (raw/run_baseline.py, run_solution.py),
# а не выдумываются. None/None = без шкалы, балл = 100 * metric().
SCALE_X = None                 # метрика baseline, например 0.24
SCALE_Y = None                 # метрика авторского решения, например 0.91
# ────────────────────────────────────────────────────────────────────────────

TARGET_PATH = "ytest.csv"
SUBMITTED_PATH = "data.csv"
OUTPUT_PATH = "answers.json"
ARCHIVE_ERROR_PATH = "archive_error.txt"


def metric(pairs):
    """
    TODO: метрика задачи.

    pairs — список (истинное значение, предсказанное значение) по строкам
    одной группы (отдельно Public, отдельно Private). Возвращать значение
    метрики (обычно в [0, 1]); балл = scale(metric(...)) — см. SCALE_X/SCALE_Y.

    Примеры:
      accuracy:  return sum(t == p for t, p in pairs) / float(len(pairs))
      R^2 c отсечкой снизу нулём:
          mean = sum(t for t, _ in pairs) / len(pairs)
          ss_res = sum((t - p) ** 2 for t, p in pairs)
          ss_tot = sum((t - mean) ** 2 for t, _ in pairs)
          return max(0.0, 1.0 - ss_res / ss_tot) if ss_tot else 0.0
    """
    raise NotImplementedError("допиши metric() под задачу")


def scale(value):
    """Метрика -> балл 0..100 по реперам X (baseline) и Y (авторское)."""
    if SCALE_X is None or SCALE_Y is None:
        return 100.0 * value
    if SCALE_Y == SCALE_X:
        return 100.0 if value >= SCALE_Y else 0.0
    frac = (value - SCALE_X) / (SCALE_Y - SCALE_X)
    return 100.0 * min(1.0, max(0.0, frac))


def write_result(public_score, private_score):
    result = {
        "public": round(float(public_score) + 1e-9, 2),
        "private": round(float(private_score) + 1e-9, 2),
    }
    with open(OUTPUT_PATH, "w", encoding="utf-8", newline="\n") as f:
        json.dump(result, f, ensure_ascii=False)
        f.write("\n")


def fail(message):
    """Отказ с человекочитаемой причиной. Код выхода 0 — вердикт ставит чекер."""
    with open(OUTPUT_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write("$ " + message + "\n")
    sys.stderr.write(message + "\n")
    sys.exit(0)


def parse_target(value, line_number):
    text = value.strip()
    if not text:
        fail("Строка {}: пустое значение {}".format(line_number, TARGET_COLUMN))
    try:
        number = TARGET_TYPE(text)
    except ValueError:
        fail("Строка {}: {} должен быть числом ({}), найдено {!r}".format(
            line_number, TARGET_COLUMN, TARGET_TYPE.__name__, text))
    if TARGET_TYPE is float and (number != number or number in (float("inf"), float("-inf"))):
        fail("Строка {}: {} должен быть конечным числом, найдено {!r}".format(
            line_number, TARGET_COLUMN, text))
    if ALLOWED_LABELS is not None and number not in ALLOWED_LABELS:
        fail("Строка {}: {} должен быть одним из {}, найдено {}".format(
            line_number, TARGET_COLUMN, sorted(ALLOWED_LABELS), number))
    return number


def read_predictions(path):
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except FileNotFoundError:
        fail("Не найден файл предсказаний: архив посылки не распакован, см. лог компиляции")
    except OSError as e:
        fail("Не смог прочитать файл предсказаний: {}".format(e))

    if not raw.strip():
        fail("Файл предсказаний пуст")

    reader = csv.reader(io.StringIO(raw.decode("utf-8-sig", errors="replace")))
    header = next(reader, None)
    if header is None:
        fail("Файл предсказаний пуст")
    header = [h.strip() for h in header]
    # Проверка формы — первое, на что смотреть при разборе жалоб: перепутанный
    # порядок колонок выглядит как «мусор в значениях», потому что дальше
    # колонки читаются позиционно.
    if header != SUBMISSION_HEADER:
        fail("Ожидались колонки {}, найдено {}".format(SUBMISSION_HEADER, header))

    preds = {}
    for i, row in enumerate(reader):
        line_number = i + 2
        if not row or (len(row) == 1 and not row[0].strip()):
            continue
        if len(row) != len(SUBMISSION_HEADER):
            fail("Строка {}: ожидалось {} колонки, найдено {}".format(
                line_number, len(SUBMISSION_HEADER), len(row)))
        row_id = row[0].strip()
        if not row_id:
            fail("Строка {}: пустой {}".format(line_number, ID_COLUMN))
        if row_id in preds:
            fail("Дубликат {}: {!r}".format(ID_COLUMN, row_id))
        preds[row_id] = parse_target(row[1], line_number)

    if not preds:
        fail("Файл предсказаний не содержит ни одной строки данных")
    return preds


def read_targets(path):
    try:
        f = open(path, newline="", encoding="utf-8-sig")
    except OSError as e:
        fail("Ошибка чтения файла с ответами: {}".format(e))

    truth, usage = {}, {}
    with f:
        reader = csv.DictReader(f)
        if reader.fieldnames != TARGET_HEADER:
            fail("ytest.csv должен содержать колонки {}, найдено {} (ошибка организатора)".format(
                TARGET_HEADER, reader.fieldnames))
        for row in reader:
            row_id = row[ID_COLUMN].strip()
            truth[row_id] = TARGET_TYPE(row[TARGET_COLUMN])
            usage[row_id] = row["Usage"].strip().title()

    if not truth:
        fail("ytest.csv пуст (ошибка организатора)")
    return truth, usage


def main():
    if os.path.exists(ARCHIVE_ERROR_PATH):
        with open(ARCHIVE_ERROR_PATH, "r", encoding="utf-8") as f:
            message = f.read().strip()
        fail(message or "Ошибка обработки архива посылки")

    preds = read_predictions(SUBMITTED_PATH)
    truth, usage = read_targets(TARGET_PATH)

    missing = [k for k in truth if k not in preds]
    if missing:
        fail("В предсказаниях не хватает {} значений {} из test.csv, например {!r}".format(
            len(missing), ID_COLUMN, missing[0]))

    extra = [k for k in preds if k not in truth]
    if extra:
        fail("В предсказаниях {} лишних {}, которых нет в test.csv, например {!r}".format(
            len(extra), ID_COLUMN, extra[0]))

    public_ids = [k for k in truth if usage[k] == "Public"]
    private_ids = [k for k in truth if usage[k] == "Private"]
    if not public_ids or not private_ids:
        fail("В ytest.csv нет Public- или Private-части (ошибка организатора)")

    public_score = metric([(truth[k], preds[k]) for k in public_ids])
    private_score = metric([(truth[k], preds[k]) for k in private_ids])

    sys.stderr.write("public: n={} score={:.4f}; private: n={} score={:.4f}\n".format(
        len(public_ids), public_score, len(private_ids), private_score))

    write_result(scale(public_score), scale(private_score))
    sys.exit(0)


if __name__ == "__main__":
    main()
