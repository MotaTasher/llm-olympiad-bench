#!/bin/sh
# Run-стадия, скопирована из работающей датасетной задачи. Решение не читает
# stdin и не пишет stdout (fileSettings: allowReadStdin=false,
# allowWriteStdout=false) — вместо этого score.py читает data.csv (собран в
# doit.sh на этапе компиляции) и ytest.csv (runtime-file), и пишет результат
# в answers.json (fileSettings.outputFileName), который дальше читает чекер.
set -eu

python3 ./score.py
