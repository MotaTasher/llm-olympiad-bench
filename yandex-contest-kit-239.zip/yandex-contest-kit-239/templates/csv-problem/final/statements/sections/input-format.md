К задаче прикреплены файлы:

- [train.csv](statements/data/train.csv) — обучающая выборка: TODO строк, колонки `id`, `feature_00` … `feature_NN`, `target`;
- [test.csv](statements/data/test.csv) — тестовая выборка: TODO строк, те же колонки без `target`;
- [baseline.ipynb](statements/baseline.ipynb) — ноутбук с базовым решением задачи;
- [sample_submission.csv](statements/data/sample_submission.csv) — пример решения, которое нужно отправить в тестирующую систему.

TODO: описание колонок, если оно не умещается в список выше.
