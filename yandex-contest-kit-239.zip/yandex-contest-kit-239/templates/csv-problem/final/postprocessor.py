#!/usr/bin/python3
"""
Постпроцессор, скопирован из работающей датасетной задачи; от задачи не зависит.
Получает из stdin JSON {"tests": [{"message": "...", ...}, ...]} — message
каждого теста это то, что checker.py напечатал в stdout ДО последней строки
с баллом. Наш checker.py кладёт туда json.dumps({"public":..,"private":..}),
так что просто вытаскиваем первую JSON-подстроку и печатаем её как есть —
это комментарий к посылке: участник видит обе цифры, а итог по приватной
части считается вне площадки по этим комментариям.
"""
import json
import sys
import traceback

try:
    payload = json.load(sys.stdin)
    tests = payload.get("tests", [])

    for test in tests:
        message = test.get("message")
        if not message:
            continue
        # На успехе сообщение чекера — это наш JSON. На отказе платформа
        # приклеивает к нему свой префикс: "wrong answer $ <причина>", поэтому
        # ищем "$" где угодно в строке, а не только в начале.
        idx_json = message.find("{")
        if idx_json != -1:
            print(message[idx_json:])
            break
        idx_reason = message.find("$")
        if idx_reason != -1:
            print(message[idx_reason:].strip())
            break
    else:
        print("""{"public": 0, "private": 0}""")

except Exception:
    print("""{"public": -1, "private": -1}""")
    traceback.print_exc(file=sys.stderr)
