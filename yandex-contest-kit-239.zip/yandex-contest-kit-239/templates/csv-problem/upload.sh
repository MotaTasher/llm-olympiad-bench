#!/bin/bash
# Заливка кита задачи в Яндекс.Контест и приведение её к профилю остальных
# задач этих дней (testlib-чекер + score.py).
#
# Файлы заливаются СТРОГО ПО ОДНОМУ с ретраями: параллельные операции с
# деревом файлов ловят 423 Locked (площадка блокирует задачу на время
# предыдущей операции), поэтому upload-folder / clear из CLI бесполезны.
#
# Использование:
#   ./upload.sh                 # почистить, залить кит и настройки
#   ./upload.sh --files-only    # только файлы, без правки настроек
set -uo pipefail

# ─── TODO: заполнить перед первым запуском ──────────────────────────────────
URL='https://admin.contest.yandex.ru/problems/TODO/settings'
NAME_RU='TODO: название задачи'
SHORT_NAME='todo-short-name'
# Файлы, оставшиеся от задачи-донора, если задача заведена клоном. Для задачи
# «с нуля» список можно оставить пустым.
LEGACY_FILES=(.DS_Store)
# ────────────────────────────────────────────────────────────────────────────

# `ycontest` появляется после `pip install -e .` в contest-kit (см. README кита).
# Если команды нет в PATH — задай CONTEST_KIT_CLI="/путь/к/.venv/bin/ycontest".
YC="${CONTEST_KIT_CLI:-ycontest}"
KIT="$(cd "$(dirname "$0")" && pwd)/final"

case "$URL" in *TODO*) echo "!! впиши URL задачи в шапку upload.sh" >&2; exit 1;; esac
command -v "$YC" >/dev/null || { echo "!! не найдена команда $YC: активируй .venv кита или задай CONTEST_KIT_CLI" >&2; exit 1; }

cli() { "$YC" "$@" 2>&1 | grep -v '^\[debug\]'; }

put() {   # put <локальный путь относительно final/> [путь в задаче]
    local src="$KIT/$1" dst="${2:-$1}"
    [ -f "$src" ] || { echo "!! нет файла $src"; return 1; }
    for attempt in 1 2 3 4 5; do
        out="$(cli upload "$URL" "$src" "$dst")"
        echo "$out"
        case "$out" in *"OK:"*) return 0;; esac
        echo "  (попытка $attempt не удалась, жду 4 с)"; sleep 4
    done
    echo "!! не смог залить $dst"; return 1
}

drop() {  # drop <путь в задаче> — файл донора, которого в этой задаче быть не должно
    for attempt in 1 2 3; do
        out="$(cli delete "$URL" "$1")"
        echo "$out"
        case "$out" in *"DELETED"*|*"404"*) return 0;; esac
        echo "  (попытка $attempt не удалась, жду 4 с)"; sleep 4
    done
    return 1
}

echo "===== 1. Чистка наследия клона"
for f in "${LEGACY_FILES[@]}"; do drop "$f"; done

echo "===== 2. Файлы кита"
put ytest.csv
put score.py
put Makefile
put doit.sh
put run.sh
put postprocessor.py
put checkers/checker.cpp
put statements/data/test.csv
put statements/data/sample_submission.csv
# TODO: раскомментировать, если у задачи есть размеченный train
# put statements/data/train.csv
for t in public public.a private private.a all all.a; do put "tests/$t"; done

if [ "${1:-}" = "--files-only" ]; then exit 0; fi

echo "===== 3. Условие по секциям (statements/sections/*.md, одним запросом)"
cli statement-set-all "$URL" ru "$KIT/statements/sections"

# Секции, которых в папке нет, чистим явно: у клонированной задачи там
# остаётся текст донора, он отрендерится в конце условия.
EMPTY="$(mktemp)"; : > "$EMPTY"
for sec in legend input-format output-format scoring notes interaction; do
    [ -f "$KIT/statements/sections/$sec.md" ] && continue
    cli statement-set "$URL" ru "$sec" "$EMPTY"
    sleep 1
done
rm -f "$EMPTY"

echo "===== 4. Чекер: testlib, как в остальных задачах"
cli checker-compile "$URL" checkers/checker.cpp gcc14_cpp23 TESTLIB_EXITCODE_CHECKER
cli checker-scoring "$URL" on

echo "===== 5. Набор тестов"
cli testset-set-pattern "$URL" 0 tests/public tests/public.a

echo "===== 6. Списки файлов по стадиям"
for f in doit.sh run.sh score.py Makefile ytest.csv; do cli compile-files  "$URL" add "$f"; done
for f in score.py ytest.csv;                        do cli runtime-files "$URL" add "$f"; done
cli postproc-files "$URL" add postprocessor.py
cli postproc-env   "$URL" python3_13

echo "===== 7. Названия"
cli set-name "$URL" "$NAME_RU"
cli set "$URL" shortName "\"$SHORT_NAME\""

echo "===== 8. Сверка"
cli check-files "$URL"
cli list "${URL%settings}files"
cli settings    "$URL"
