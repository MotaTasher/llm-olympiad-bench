# -*- coding: utf-8 -*-
"""
Скелет генератора данных задачи.

Что делает:
  1. синтезирует датасет (TODO — единственная часть, которую надо писать);
  2. режет его на Public/Private со стратификацией;
  3. раскладывает файлы ровно туда, где их ждут остальные скрипты:

     ../final/statements/data/test.csv              — раздатка участнику
     ../final/statements/data/sample_submission.csv — шаблон посылки
     ../final/ytest.csv                             — скрытые ответы + Usage
     ../final/tests/{public,private,all}[.a]        — наборы тестов площадки
     private/ytest.csv                              — копия ответов рядом с генератором

Запуск:
    python generator.py --seed 20260729
"""
import argparse
import os

import numpy as np
import pandas as pd

ID_COLUMN = "id"
TARGET_COLUMN = "target"
PUBLIC_FRACTION = 0.4

HERE = os.path.dirname(os.path.abspath(__file__))
FINAL = os.path.join(HERE, "..", "final")
DATA = os.path.join(FINAL, "statements", "data")
TESTS = os.path.join(FINAL, "tests")
PRIVATE = os.path.join(HERE, "private")


def make_dataset(rng):
    """
    TODO: сгенерировать датасет.

    Возвращает DataFrame с колонками:
      ID_COLUMN      — непрозрачный идентификатор строки (не несёт сигнала!),
      feature_*      — признаки,
      TARGET_COLUMN  — истинный ответ,
      "stratum"      — по чему стратифицировать Public/Private
                       (обычно сам таргет или пара таргетов).

    Идентификатор делать случайным: любой порядковый номер или зависимость от
    таргета — это утечка, участники её найдут.
    """
    raise NotImplementedError("допиши make_dataset() под задачу")


def split_public_private(df, rng):
    """Стратифицированное разбиение: каждый страт представлен в обеих частях."""
    usage = pd.Series("Private", index=df.index)
    for _, group in df.groupby("stratum", sort=False):
        indices = rng.permutation(group.index.to_numpy())
        n_public = max(1, int(round(len(indices) * PUBLIC_FRACTION)))
        n_public = min(n_public, len(indices) - 1) if len(indices) > 1 else len(indices)
        usage.loc[indices[:n_public]] = "Public"
    return usage


def write_testset(path, ids, values=None):
    """Файл набора тестов: без расширения, шапка + строки."""
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        if values is None:
            f.write(ID_COLUMN + "\n")
            for row_id in ids:
                f.write("{}\n".format(row_id))
        else:
            f.write("{},{}\n".format(ID_COLUMN, TARGET_COLUMN))
            for row_id, value in zip(ids, values):
                f.write("{},{}\n".format(row_id, value))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=20260729)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    df = make_dataset(rng).reset_index(drop=True)
    df["Usage"] = split_public_private(df, rng)

    for directory in (DATA, TESTS, PRIVATE):
        os.makedirs(directory, exist_ok=True)

    feature_columns = [c for c in df.columns
                       if c not in (ID_COLUMN, TARGET_COLUMN, "Usage", "stratum")]

    # Раздатка: признаки без ответов, порядок строк перемешан, чтобы Public и
    # Private не лежали блоками.
    public_view = df.sample(frac=1.0, random_state=args.seed).reset_index(drop=True)
    public_view[[ID_COLUMN] + feature_columns].to_csv(
        os.path.join(DATA, "test.csv"), index=False)

    sample = public_view[[ID_COLUMN]].copy()
    sample[TARGET_COLUMN] = df[TARGET_COLUMN].iloc[0]   # константа-заглушка
    sample.to_csv(os.path.join(DATA, "sample_submission.csv"), index=False)

    # Ответы организатора.
    answers = df[[ID_COLUMN, TARGET_COLUMN, "Usage"]]
    answers.to_csv(os.path.join(FINAL, "ytest.csv"), index=False)
    answers.to_csv(os.path.join(PRIVATE, "ytest.csv"), index=False)

    # Наборы тестов площадки.
    for name, subset in (("public", df[df["Usage"] == "Public"]),
                         ("private", df[df["Usage"] == "Private"]),
                         ("all", df)):
        write_testset(os.path.join(TESTS, name), subset[ID_COLUMN])
        write_testset(os.path.join(TESTS, name + ".a"),
                      subset[ID_COLUMN], subset[TARGET_COLUMN])

    print("строк: всего {}, public {}, private {}".format(
        len(df), int((df["Usage"] == "Public").sum()),
        int((df["Usage"] == "Private").sum())))
    print("признаков:", len(feature_columns))


if __name__ == "__main__":
    main()
