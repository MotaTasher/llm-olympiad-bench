# Посылки

Две разные вещи в одной папке:

- `submission_score_*.zip` — **эталонные** посылки, собранные локально: 0 / 33 /
  66 / 100 % от максимума. На них гоняется `../simulate.sh` перед заливкой и
  ими же проверяется задача боем после заливки. Ожидаемые баллы — в
  `expected_scores.csv`;
- `sent/` — посылки, скачанные с площадки (`download-submission`), плюс
  `submissions.csv` (id, время, вердикт, балл, компилятор, имя файла).

## Собрать эталонную посылку

Архив — ровно один `.csv` и ровно один `.ipynb`, имена внутри не важны:

```bash
zip -j submission_score_100.zip ../raw/solution_submission.csv ../raw/solution.ipynb
```

Посылка на 0 баллов делается из `sample_submission.csv` — она же проверяет, что
вырожденный ответ действительно не набирает очков.

## Проверить

```bash
../simulate.sh submission_score_100.zip     # локально, все четыре стадии
ycontest submit <contest_id> <problem_ref> submission_score_100.zip python-lyceum
```
