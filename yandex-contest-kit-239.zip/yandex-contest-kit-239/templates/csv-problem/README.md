# Шаблон задачи с CSV-посылкой

Скелет по образцу рабочих датасетных задач. Файлы конвейера скопированы
**как есть** из работающей задачи и от задачи не зависят — менять надо только
помеченное `TODO`.

## Что где

| Файл | Правится? | Что это |
|---|---|---|
| `final/Makefile`, `final/doit.sh`, `final/run.sh` | нет | стадии компиляции и запуска: распаковка zip → `data.csv` → `score.py` |
| `final/postprocessor.py` | нет | достаёт `{"public":..,"private":..}` из сообщения чекера в лидерборд |
| `final/checkers/checker.cpp` | нет | testlib-чекер: берёт `public` из первой строки `answers.json` |
| `final/score.py` | **да** | валидация посылки и метрика — вся специфика задачи здесь |
| `final/ytest.csv` | **да** | скрытые ответы + колонка `Usage` (Public/Private). Кладётся из `raw/private/` |
| `final/statements/sections/*.md` | **да** | условие по секциям площадки: `legend`, `input-format`, `output-format`, `scoring` — формулировки уже в нужном виде, заполнить `TODO` (см. `docs/STATEMENTS.md`) |
| `final/statements/data/` | **да** | раздатка участнику: `test.csv`, `sample_submission.csv`, при наличии `train.csv` |
| `final/tests/` | **да** | `public`, `public.a`, `private`, `private.a`, `all`, `all.a` — см. `tests/README.md` |
| `upload.sh` | **да** (шапка) | заливка кита и настроек, строго по одному файлу с ретраями |
| `simulate.sh` | нет | локальный прогон всех четырёх стадий на zip-посылке |
| `raw/` | **да** | генератор, авторские решения, аудит — то, что на площадку не едет |
| `subm/` | **да** | эталонные посылки на 0 / 33 / 66 / 100 % и скачанные с площадки |

## Чек-лист

1. **Завести задачу на площадке.** Либо клоном рабочей задачи (тогда лишние файлы
   клона удалит секция «чистка» в `upload.sh`), либо с нуля:

   ```bash
   ycontest create-problem "Название задачи"      # ycontest — из .venv кита
   ```

   Полученный id вписать в `PROBLEM.md` и в `upload.sh` (`URL=`).

2. **Привязать к контесту** буквой:

   ```bash
   ycontest contest-add-problem <contest_id> <problem_ref> A
   ```

3. **Данные.** Генератор в `raw/generator.py` пишет открытую часть
   (`test.csv`, `sample_submission.csv`, при наличии `train.csv`) и приватную
   (`raw/private/ytest.csv`). Разложить: открытое — в `final/statements/data/`,
   `ytest.csv` — в `final/`, наборы тестов — в `final/tests/`.

4. **Метрика.** Дописать `metric()` и валидацию в `final/score.py` (все `TODO`).

5. **Условие.** Заполнить `TODO` в `final/statements/sections/*.md`; `upload.sh`
   заливает все секции одним запросом и чистит те, которых в папке нет (иначе
   торчит наследство клона). «По лучшей/последней посылке» в `scoring.md` —
   как в настройке контеста. Реперы `X`/`Y` — те же, что `SCALE_X`/`SCALE_Y` в
   `score.py`.

6. **Проверить локально** на эталонных посылках:

   ```bash
   ./simulate.sh subm/submission_score_100.zip   # должно дать ~100
   ./simulate.sh subm/submission_score_000.zip   # должно дать 0
   ```

   `simulate.sh` повторяет все четыре стадии площадки побайтово, включая
   эмуляцию testlib-чекера. Это единственный надёжный способ поймать
   «участник ошибся» против «чекер врёт».

7. **Залить:** `./upload.sh` (файлы + настройки) или `./upload.sh --files-only`.

8. **Проверить боем:** послать эталонный zip через `submit` и сверить балл.

   ```bash
   ycontest submit <contest_id> <problem_ref> subm/submission_score_100.zip python-lyceum
   ycontest submission-get <id>
   ```

## Грабли

- Заливать файлы **строго по одному** с ретраями: параллельные операции ловят
  423 Locked. `upload-folder` / `clear` на этом ломаются — в `upload.sh` уже
  сделано правильно.
- Чекер — `TESTLIB_EXITCODE_CHECKER` + `quitp()`. `EJUDGE_EXITCODE_CHECKER`
  берёт из stdout первый токен и молча ставит 0 баллов при вердикте OK.
- Текст ошибки упавшей посылки лежит в `postProcessorMessage` полного JSON
  (`submission-get` в кратком выводе его не печатает).
- Сообщению чекера верить буквально нельзя: `score.py` читает колонки
  позиционно, и перепутанный участником порядок колонок выглядит как «дробные
  значения в label». Проверять форму ответа: порядок и число колонок, `id`,
  число строк.
